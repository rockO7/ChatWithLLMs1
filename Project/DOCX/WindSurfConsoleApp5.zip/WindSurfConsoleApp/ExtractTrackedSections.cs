using System;
using HtmlAgilityPack;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Threading.Tasks;

public static class ExtractTrackedSections
{
    public static async Task ExtractTrackedChangeSectionsFromCleanedFileAsync(string cleanedInputPath, string outputPath)
    {
        var doc = new HtmlDocument();
        using (var stream = File.OpenRead(cleanedInputPath))
        {
            doc.Load(stream);
        }

        // Build new HTML document with just content that has tracked changes
        var newDoc = new HtmlDocument();
        newDoc.LoadHtml("<html><head></head><body></body></html>");
        var body = newDoc.DocumentNode.SelectSingleNode("//body");

        // Find all divs with tracked changes
        var divs = doc.DocumentNode.SelectNodes("//body/div");
        if (divs == null)
        {
            Console.WriteLine("No divs found.");
            return;
        }

        var divsWithTrackedChanges = new List<HtmlNode>();
        foreach (var div in divs)
        {
            if (div.SelectSingleNode(".//ins") != null || div.SelectSingleNode(".//del") != null)
            {
                divsWithTrackedChanges.Add(div);
            }
        }

        var divsWithHeadings = new Dictionary<HtmlNode, bool>();
        foreach (var div in divsWithTrackedChanges)
        {
            bool hasHeading = div.SelectNodes(".//b[@class='custom-bold-heading']") != null;
            divsWithHeadings[div] = hasHeading;
        }

        // Now build the new document with divs
        foreach (var div in divsWithTrackedChanges)
        {
            // Add the div
            var divClone = HtmlNode.CreateNode(div.OuterHtml);
            body.AppendChild(divClone);
        }

        using (var stream = File.Create(outputPath))
        {
            newDoc.Save(stream);
            await stream.FlushAsync().ConfigureAwait(false);
        }
        Console.WriteLine($"Extracted tracked changes sections to: {outputPath}");
    }

    /// <summary>
    /// Extracts specific div elements from a given HTML file based on content rules
    /// (potential Table of Contents or presence of tracked changes) and saves them
    /// into a new HTML file.
    /// </summary>
    /// <remarks>
    /// This method identifies potential Table of Contents (TOC) sections in the first few divs
    /// and filters them to keep only valid links pointing to existing anchors within the document
    /// or paragraphs containing "table of contents".
    /// For subsequent divs, it keeps only those containing HTML <ins> or <del> tags,
    /// which typically represent tracked changes.
    /// The extracted divs are placed in a new HTML document, separated by horizontal rules.
    /// Requires the HtmlAgilityPack library.
    /// </remarks>
    /// <param name="cleanedInputPath">The file path to the input HTML document to process.</param>
    /// <param name="outputPath">The file path where the resulting HTML document with extracted divs will be saved.</param>
    public static void ExtractTrackedChangeDivsFromCleanedFile(string cleanedInputPath, string outputPath)
    {
        // Initialize HtmlAgilityPack document object
        var doc = new HtmlDocument();
        // Load the HTML content from the specified input file path
        doc.Load(cleanedInputPath);

        // Select all <div> elements that are direct children of the <body> tag
        var divs = doc.DocumentNode.SelectNodes("//body/div");

        // Basic check: If there are no divs or too few (less than 3), processing might not be meaningful.
        // The logic implicitly requires at least one potential TOC div and potentially other content divs.
        if (divs == null || divs.Count <= 2)
        {
            Console.WriteLine($"Not enough divs found in {cleanedInputPath} to perform meaningful extraction (found {divs?.Count ?? 0}). Skipping.");
            return; // Exit the method if not enough divs are found
        }

        // --- Pre-processing: Find all named anchors in the entire document ---
        // This is done once upfront for efficiency during TOC link validation.
        var anchorNames = new HashSet<string>( // Using HashSet for fast O(1) lookups
            doc.DocumentNode.SelectNodes("//a[@name]") // Select all <a> tags with a 'name' attribute anywhere
                ?.Select(a => a.GetAttributeValue("name", "")) // Extract the value of the 'name' attribute
                .Where(n => !string.IsNullOrEmpty(n)) // Filter out any empty or null names
                ?? new List<string>() // If SelectNodes returns null, use an empty list to avoid NullReferenceException
        );
        Console.WriteLine($"Found {anchorNames.Count} unique named anchors in the document.");

        // --- Main Processing Loop: Iterate through divs and select candidates ---
        var trackedDivs = new List<HtmlNode>(); // List to store the divs that meet the criteria
        int maxTocDivs = Math.Min(4, divs.Count); // Consider only the first few (up to 4) divs as potential TOCs

        for (int i = 0; i < divs.Count; i++)
        {
            var div = divs[i]; // Current div being processed

            // --- Part 1: Handle Potential Table of Contents (First `maxTocDivs` divs) ---
            if (i < maxTocDivs)
            {
                // Assume this div *might* be part of a Table of Contents.
                // Filter its content rigorously.

                // Select all <p> elements within the current div
                var ps = div.SelectNodes(".//p")?.ToList() ?? new List<HtmlNode>(); // Use .ToList() to allow removal while iterating copy

                // Iterate through each paragraph tag found
                foreach (var p in ps)
                {
                    // Find the first <a> tag with an 'href' attribute within the paragraph
                    var a = p.SelectSingleNode(".//a[@href]");
                    if (a != null) // If an anchor tag exists...
                    {
                        var href = a.GetAttributeValue("href", ""); // Get the href value
                        // Check if the link is an internal anchor link (starts with '#')
                        if (href.StartsWith("#"))
                        {
                            var anchor = href.Substring(1); // Extract the anchor name (remove '#')
                            // Check if this anchor name exists in our pre-calculated set of valid anchor names
                            if (!anchorNames.Contains(anchor))
                            {
                                // If the anchor target doesn't exist in the document, remove the entire <p> tag
                                p.Remove();
                            }
                            // else: The link is valid, keep the <p> tag
                        }
                        else
                        {
                            // If the link exists but doesn't start with '#', it's not a valid TOC entry for our purpose. Remove the <p>.
                            p.Remove();
                        }
                    }
                    // If no <a> tag exists in the <p>, check if it's a potential TOC heading
                    else if (!p.InnerText.ToLowerInvariant().Contains("table of contents"))
                    {
                        // If it's not a link and doesn't contain "table of contents" (case-insensitive),
                        // remove this <p> tag as it's not a valid TOC entry or heading.
                        p.Remove();
                    }
                    // else: Paragraph contains "table of contents", keep it as a potential heading.
                }

                // After filtering paragraphs, check if any <p> elements remain in the div
                if (div.SelectNodes(".//p")?.Any() ?? false)
                {
                    // If valid <p> tags (TOC entries/headings) remain, we want to keep this div,
                    // but ONLY with its filtered <p> tags. Remove all other direct child nodes.
                    foreach (var node in div.ChildNodes.ToList()) // Iterate over a copy for safe removal
                    {
                        // Remove any child node that is NOT a <p> tag
                        if (node.Name != "p")
                        {
                            node.Remove();
                        }
                    }
                    // Add the cleaned-up div (containing only valid <p>s) to our list of divs to keep
                    trackedDivs.Add(div);
                }
                // else: No valid <p> tags remained after filtering, so discard this potential TOC div entirely.
            }
            // --- Part 2: Handle Content Divs (After the potential TOC section) ---
            else // For divs beyond the initial `maxTocDivs`
            {
                // Check if the div contains tracked changes (<ins> or <del> tags) anywhere within it
                bool hasIns = div.SelectSingleNode(".//ins") != null;
                bool hasDel = div.SelectSingleNode(".//del") != null;

                if (hasIns || hasDel)
                {
                    // If the div contains either an <ins> or <del> tag, keep the entire div as is.
                    trackedDivs.Add(div);
                }
                // else: The div has no tracked changes, discard it.
            }
        }

        // --- Build the New HTML Document ---
        var newDoc = new HtmlDocument(); // Create a new empty HTML document object
        // Create basic HTML structure
        var html = HtmlNode.CreateNode("<html></html>");
        var head = HtmlNode.CreateNode("<head><title>Extracted Tracked Changes</title></head>"); // Added a basic title
        var body = HtmlNode.CreateNode("<body></body>");

        // Assemble the basic structure
        newDoc.DocumentNode.AppendChild(html);
        html.AppendChild(head);
        html.AppendChild(body);

        // --- Populate the New Document Body ---
        bool first = true; // Flag to avoid adding a separator before the very first div
        foreach (var div in trackedDivs)
        {
            // --- Optional: Additional check/filter for divs that look like TOCs before adding ---
            // This seems somewhat redundant with the initial TOC filtering, but might act as a
            // safeguard or apply slightly different logic based on link count.
            var tocLinks = div.SelectNodes(".//a[@href]");
            // Heuristic: If a div has more than 2 links, assume it's a TOC and re-validate links.
            // This could potentially filter out divs that passed the initial TOC check but had few links,
            // or re-filter divs that were kept for <ins>/<del> but also happen to have many links.
            if (tocLinks != null && tocLinks.Count > 2)
            {
                var ps = div.SelectNodes(".//p")?.ToList() ?? new List<HtmlNode>();
                foreach (var p in ps)
                {
                    var a = p.SelectSingleNode(".//a[@href]");
                    if (a != null)
                    {
                        var href = a.GetAttributeValue("href", "");
                        if (href.StartsWith("#"))
                        {
                            var anchor = href.Substring(1);
                            // Re-check against the master list of anchor names
                            if (!anchorNames.Contains(anchor))
                            {
                                p.Remove(); // Remove paragraph if its anchor link is invalid
                            }
                        }
                        // Note: Unlike the first pass, this check doesn't explicitly remove <p> if href doesn't start with #
                        // or if there's no <a> tag. It primarily focuses on validating existing #-links.
                    }
                }
                // If this second filtering pass removed all remaining <p> tags, skip adding this div.
                if (!(div.SelectNodes(".//p")?.Any() ?? false))
                {
                    //Console.WriteLine("Skipping div that looked like TOC but had no valid remaining P tags after second pass.");
                    continue; // Skip to the next div in trackedDivs
                }
            }


            // Add a horizontal rule as a separator *before* adding the div (except for the first one)
            if (!first)
            {
                // Create an <hr> tag with some basic styling for visibility
                var hr = HtmlNode.CreateNode("<hr style=\"border:none; border-top:2px solid #888; margin:32px 0;\">");
                body.AppendChild(hr); // Add the separator to the body
            }
            first = false; // Ensure subsequent divs get a separator

            // Import the selected div (with its potentially modified content) into the new document.
            // Create a new node from the OuterHtml to avoid issues with node ownership between documents.
            var importedDiv = HtmlNode.CreateNode(div.OuterHtml);
            body.AppendChild(importedDiv); // Add the div to the body
        }

        // --- Save the New Document ---
        try
        {
            newDoc.Save(outputPath); // Save the constructed HTML document to the specified file path
            Console.WriteLine($"Successfully extracted tracked changes and relevant divs to: {outputPath}");
        }
        catch (Exception ex)
        {
            // Basic error handling for save operation
            Console.WriteLine($"Error saving the output file to {outputPath}: {ex.Message}");
        }
    }

}
