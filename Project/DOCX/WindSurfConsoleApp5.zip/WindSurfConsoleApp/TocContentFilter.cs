using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using HtmlAgilityPack;

namespace WindSurfConsoleApp
{
    public static class TocContentFilter
    {
        /// <summary>
        /// Removes any nodes within the TableofContents div that do not contain an <a href> link.
        /// </summary>
        public static async Task FilterTocLinksOnlyAsync(string filePath)
        {
            var doc = new HtmlDocument();
            try
            {
                using (var stream = File.OpenRead(filePath))
                {
                    doc.Load(stream);
                }
            }
            catch (Exception)
            {
                return; // File not found or invalid
            }

            var tocDiv = doc.DocumentNode.SelectSingleNode("//div[@class='TableofContents']");
            if (tocDiv != null)
            {
                // Clone list to avoid issues while removing
                foreach (var node in tocDiv.ChildNodes.ToList())
                {
                    if (node.SelectSingleNode(".//a[@href]") == null)
                    {
                        node.Remove();
                    }
                }
            }

            using (var stream = File.Create(filePath))
            {
                doc.Save(stream);
                await stream.FlushAsync().ConfigureAwait(false);
            }
        }
    }
}
