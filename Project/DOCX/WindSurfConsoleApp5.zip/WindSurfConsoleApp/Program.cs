/*
DETAILED WORKFLOW EXPLANATION FOR THIS PROGRAM
-------------------------------------------------
This C# program processes HTML files to extract and highlight tracked changes, bold headings, and clean up Table of Contents (TOC) sections. Here is a step-by-step explanation of what each major operation does, why it is called, what input it expects, and what output it produces.

1. HtmlFileCleaner.CleanAllHtmlFilesAsync()
   - What: Cleans all HTML files in the 'HtmlFiles' directory and writes cleaned versions to 'HtmlFiles/Cleaned'.
   - Why: Removes unnecessary tags (like <style>), header/footer divs, and applies consistent styles to tracked changes and tables. Prepares files for further processing.
   - Input: All .html files in 'HtmlFiles' directory.
   - Output: Cleaned .html files in 'HtmlFiles/Cleaned'.

2. HeadingBolder.BoldHeadingsForTocAnchorsAsync(cleanedInputPath)
   - What: Bolds headings in the HTML that correspond to TOC anchors (e.g., <a name="_Toc..."></a>).
   - Why: Visually highlights headings that are referenced in the Table of Contents, making navigation easier.
   - Input: Cleaned HTML file path (e.g., 'HtmlFiles/Cleaned/CTC.html').
   - Output: The same file, but with relevant headings wrapped in <b class="custom-bold-heading"> tags.

3. ExtractTrackedSections.ExtractTrackedChangeDivsFromCleanedFile(cleanedInputPath, trackedOutputPath)
   - What: Extracts <div> blocks from the cleaned HTML that are either TOC candidates or contain tracked changes (<ins> or <del> tags).
   - Why: Isolates only the sections of the document that have tracked changes or are part of the TOC for further analysis.
   - Input: Cleaned HTML file and output path for tracked changes only file.
   - Output: New HTML file with only the relevant <div> blocks.

4. ExtractTrackedSections.ExtractTrackedChangeSectionsFromCleanedFileAsync(cleanedInputPath, trackedOutputPath)
   - What: Extracts all <div> sections from the cleaned HTML that contain tracked changes.
   - Why: Focuses only on content that has been edited (tracked changes), ignoring unchanged content.
   - Input: Cleaned HTML file and output path for tracked changes only file.
   - Output: New HTML file with only tracked changes sections.

5. ExtractTrackedDivs.ExtractTrackedChangeSectionsBetweenHeadingsAsync(trackedOutputPath, outputPath)
   - What: Further splits the tracked changes file into sections that are grouped between headings (typically <b> tags with class 'custom-bold-heading').
   - Why: Organizes tracked changes by logical document sections for easier review and comparison.
   - Input: Tracked changes only HTML file and output path for the sectioned file.
   - Output: New HTML file with tracked changes grouped by headings.

6. TOCPruner.PruneTocInTrackedFileAsync(outputPath)
   - What: Cleans up the Table of Contents in the tracked changes file by removing empty or irrelevant TOC sections.
   - Why: Ensures the final output is clean, with only meaningful TOC entries, and no empty or broken links.
   - Input: The sectioned tracked changes HTML file.
   - Output: The same file, but with pruned TOC sections.

Helper: RemoveDivTagsFromFileAsync(filePath)
   - What: Removes all <div> and </div> tags from a file.
   - Why: Used (if called) to flatten the document structure for final output or compatibility.
   - Input: Path to any HTML file.
   - Output: The same file, but with all <div> tags removed.

OVERALL PIPELINE:
1. Clean all HTMLs (removes noise, applies styles).
2. Bold TOC headings for clarity.
3. Extract only tracked/TOC <div>s for focused review.
4. Extract only tracked change sections for change analysis.
5. Split content between headings for section-based diffing.
6. Prune TOC for a clean, navigable output.

This workflow ensures that the final HTML outputs are clean, well-organized, and focused on tracked changes, with clear navigation and minimal clutter.
*/

using System;
using System.IO;
using WindSurfConsoleApp;

class Program
{
    static async Task Main(string[] args)
    {
        // try
        // {
        //     Console.WriteLine("Started");
        //     var cleaner = new HtmlFileCleaner(); 
        //     await cleaner.CleanAllHtmlFilesAsync(); 
        // }
        // catch (Exception exCleaner)
        // {
        //     Console.WriteLine("Failed");

        //     Console.WriteLine($"*** FATAL ERROR during CleanAllHtmlFilesAsync section: {exCleaner.ToString()} ***"); 
        //     return; 
        // }

        // string cleanedInputPath = "HtmlFiles/Cleaned/CTC.html";
        // string cleanedInputPath1 = "HtmlFiles/Cleaned/CLTIC.html";
        // string cleanedInputPath2 = "HtmlFiles/Cleaned/TTC.html";

        // string trackedOutputPath = "HtmlFiles/Cleaned/CTC_TrackedChangesOnly1.html";
        // string trackedOutputPath1 = "HtmlFiles/Cleaned/CLTIC_TrackedChangesOnly1.html";
        // string trackedOutputPath2 = "HtmlFiles/Cleaned/TTC_TrackedChangesOnly1.html";

        // string SectionChangeOutputPath = "HtmlFiles/Cleaned/CTC_TrackedChangesOnly_SectionChange.html";
        // string SectionChangeOutputPath1 = "HtmlFiles/Cleaned/CLTIC_TrackedChangesOnly_SectionChange.html";
        // string SectionChangeOutputPath2 = "HtmlFiles/Cleaned/TTC_TrackedChangesOnly_SectionChange.html";

        string outputPath = "HtmlFiles/Cleaned/CTC_TrackedChangesOnly_BetweenHeadings1.html";
        string outputPath1 = "HtmlFiles/Cleaned/CLTIC_TrackedChangesOnly_BetweenHeadings1.html";
        string outputPath2 = "HtmlFiles/Cleaned/TTC_TrackedChangesOnly_BetweenHeadings1.html";

        string mergedOutputPath = "HtmlFiles/Merged/MergedDocument.html";

        try
        {
            Console.WriteLine("Starting document merge process...");
            
            // Define input files and their document names
            string[] inputFiles = new string[] 
            {
                Path.GetFullPath(outputPath),
                Path.GetFullPath(outputPath1),
                Path.GetFullPath(outputPath2)
            };
            
            string[] documentNames = new string[] 
            {
                "CTC",
                "CLTIC",
                "TTC"
            };
            
            // Ensure the output directory exists
            string mergedDir = Path.GetDirectoryName(Path.GetFullPath(mergedOutputPath));
            if (!Directory.Exists(mergedDir))
            {
                Directory.CreateDirectory(mergedDir);
            }
            
            // Create and run the document merger
            var merger = new DocumentMerger(Path.GetFullPath(mergedOutputPath));
            await merger.MergeDocumentsAsync(inputFiles, documentNames);
            
            Console.WriteLine("Document merge completed successfully!");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"*** ERROR during document merge: {ex} ***");
        }

        // await RemoveDivTagsFromFileAsync(cleanedInputPath).ConfigureAwait(false);
        // await RemoveDivTagsFromFileAsync(cleanedInputPath1).ConfigureAwait(false);
        // await RemoveDivTagsFromFileAsync(cleanedInputPath2).ConfigureAwait(false);
                
        // await HeadingBolder.BoldHeadingsForTocAnchorsAsync(cleanedInputPath,trackedOutputPath);
        // await HeadingBolder.BoldHeadingsForTocAnchorsAsync(cleanedInputPath1,trackedOutputPath1);
        // await HeadingBolder.BoldHeadingsForTocAnchorsAsync(cleanedInputPath2,trackedOutputPath2);

        // await TocContentFilter.FilterTocLinksOnlyAsync(trackedOutputPath);
        // await TocContentFilter.FilterTocLinksOnlyAsync(trackedOutputPath1);
        // await TocContentFilter.FilterTocLinksOnlyAsync(trackedOutputPath2);

        // await ExtractTrackedSections.ExtractTrackedChangeSectionsFromCleanedFileAsync(trackedOutputPath, SectionChangeOutputPath);
        // await ExtractTrackedSections.ExtractTrackedChangeSectionsFromCleanedFileAsync(trackedOutputPath1, SectionChangeOutputPath1);
        // await ExtractTrackedSections.ExtractTrackedChangeSectionsFromCleanedFileAsync(trackedOutputPath2, SectionChangeOutputPath2);

        // await ExtractTrackedDivs.ExtractTrackedChangeSectionsBetweenHeadingsAsync(SectionChangeOutputPath, outputPath);
        // await ExtractTrackedDivs.ExtractTrackedChangeSectionsBetweenHeadingsAsync(SectionChangeOutputPath1, outputPath1);
        // await ExtractTrackedDivs.ExtractTrackedChangeSectionsBetweenHeadingsAsync(SectionChangeOutputPath2, outputPath2);

        // await TOCPruner.PruneTocInTrackedFileAsync(outputPath);
        // await TOCPruner.PruneTocInTrackedFileAsync(outputPath1);
        // await TOCPruner.PruneTocInTrackedFileAsync(outputPath2);
    }

    static async Task RemoveDivTagsFromFileAsync(string filePath)
    {
        try
        {
            if (!File.Exists(filePath))
            {
                return; 
            }
            string content = await File.ReadAllTextAsync(filePath);
            content = content.Replace("<div>", string.Empty).Replace("</div>", string.Empty);
            await File.WriteAllTextAsync(filePath, content);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"*** ERROR in RemoveDivTagsFromFileAsync for {filePath}: {ex.Message}"); 
        }
    }
}
