using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml;
using HtmlAgilityPack;

namespace WindSurfConsoleApp
{
    public class DocumentMerger
    {
        private readonly string _outputPath;
        private readonly Dictionary<string, List<DocumentSection>> _sectionsByHeading;
        
        public DocumentMerger(string outputPath)
        {
            _outputPath = outputPath;
            _sectionsByHeading = new Dictionary<string, List<DocumentSection>>(StringComparer.OrdinalIgnoreCase);
        }

        public async Task MergeDocumentsAsync(string[] inputPaths, string[] documentNames)
        {
            if (inputPaths.Length != documentNames.Length)
            {
                throw new ArgumentException("The number of input paths must match the number of document names.");
            }

            // Parse all documents and group sections by heading
            for (int i = 0; i < inputPaths.Length; i++)
            {
                await ParseDocumentAsync(inputPaths[i], documentNames[i]);
            }
            // Consolidate unique sections by numeric prefix into existing groups
            ConsolidateSections();

            // Write the merged document
            await WriteMergedDocumentAsync();
        }

        private async Task ParseDocumentAsync(string filePath, string documentName)
        {
            Console.WriteLine($"Parsing document: {documentName} from {filePath}");
            string html = await File.ReadAllTextAsync(filePath);
            var doc = new HtmlDocument();
            doc.LoadHtml(html);

            // Select all custom-section divs
            var allSections = doc.DocumentNode.SelectNodes("//div[@class='custom-section']")?
                .Cast<HtmlNode>()
                .ToList() ?? new List<HtmlNode>();
            // Filter out Table of Contents wrappers and keep only those with a bold heading
            var sectionNodes = allSections
                .Where(n => n.SelectSingleNode(".//div[contains(@class,'TableofContents')]") == null
                            && n.SelectSingleNode(".//b[contains(@class,'custom-bold-heading')]") != null)
                .ToList();
            if (!sectionNodes.Any())
            {
                Console.WriteLine($"Warning: No content sections found in {documentName}");
                return;
            }

            foreach (var sectionNode in sectionNodes)
            {
                // Extract heading text: combine all custom-bold-heading elements for this section
                var boldNodes = sectionNode.SelectNodes(".//b[contains(@class,'custom-bold-heading')]")
                                    ?.Cast<HtmlNode>().ToList()
                                    ?? new List<HtmlNode>();
                if (!boldNodes.Any())
                {
                    Console.WriteLine("Warning: Section without bold heading, skipping");
                    continue;
                }
                var headingParts = boldNodes.Select(b =>
                {
                    var copy = b.CloneNode(true);
                    var dels = copy.SelectNodes(".//del")?.ToList();
                    if (dels != null)
                        foreach (var d in dels) d.Remove();
                    return Regex.Replace(copy.InnerText, @"\s+", " ").Trim();
                }).ToList();
                string headingText = string.Join(" ", headingParts).Trim();

                // Group by numeric prefix first (e.g. "5.1 ..."), else normalize and match
                var numMatch = Regex.Match(headingText, @"^\d+(?:\.\d+)*");
                string groupKey;
                if (numMatch.Success)
                {
                    string prefix = numMatch.Value;
                    var keyByPrefix = _sectionsByHeading.Keys.FirstOrDefault(k => k.StartsWith(prefix, StringComparison.OrdinalIgnoreCase));
                    groupKey = keyByPrefix ?? headingText;
                }
                else
                {
                    // Normalize heading to ignore spaces, punctuation, and case
                    Func<string, string> NormalizeKey = s => Regex.Replace(s.ToLowerInvariant(), @"[\s\W]+", "");
                    string normalizedHeading = NormalizeKey(headingText);
                    var existingKey = _sectionsByHeading.Keys.FirstOrDefault(k => NormalizeKey(k) == normalizedHeading);
                    groupKey = existingKey ?? headingText;
                }

                // Create a section object with the full HTML content
                var section = new DocumentSection
                {
                    DocumentName = documentName,
                    HeadingText = headingText,
                    HtmlContent = sectionNode.OuterHtml
                };

                // Add to dictionary, creating a new list if needed
                if (!_sectionsByHeading.ContainsKey(groupKey))
                    _sectionsByHeading[groupKey] = new List<DocumentSection>();
                _sectionsByHeading[groupKey].Add(section);
            }
        }

        private async Task WriteMergedDocumentAsync()
        {
            var mergedHtml = new StringBuilder();
            
            // Start with HTML doctype and opening tags
            mergedHtml.AppendLine("<!DOCTYPE html>");
            mergedHtml.AppendLine("<html>");
            mergedHtml.AppendLine("<head>");
            mergedHtml.AppendLine("    <meta charset=\"UTF-8\">");
            mergedHtml.AppendLine("    <title>Merged Document</title>");
            mergedHtml.AppendLine("    <style>");
            mergedHtml.AppendLine("        h2 { font-weight: bold; font-size: 24px; margin: 20px 0; }");
            mergedHtml.AppendLine("        details { margin: 10px 0; }");
            mergedHtml.AppendLine("        summary { font-weight: bold; font-size: 18px; cursor: pointer; background-color: #f0f0f0; padding: 5px; }");
            mergedHtml.AppendLine("        .section-divider { margin: 30px 0; border: 1px solid #000; }");
            mergedHtml.AppendLine("    </style>");
            mergedHtml.AppendLine("</head>");
            mergedHtml.AppendLine("<body>");
            
            // Iterate headings in insertion order
            foreach (var kvp in _sectionsByHeading)
            {
                string heading = kvp.Key;
                var sections = kvp.Value;

                // Main heading
                mergedHtml.AppendLine($"<h2>{heading}</h2>");

                // Sections per document
                foreach (var section in sections)
                {
                    mergedHtml.AppendLine("<details>");
                    mergedHtml.AppendLine($"  <summary>{section.DocumentName}</summary>");
                    mergedHtml.AppendLine(section.HtmlContent);
                    mergedHtml.AppendLine("</details>");
                }

                // Divider between headings
                mergedHtml.AppendLine("<hr class=\"section-divider\" />");
            }
            
            // Close the HTML document
            mergedHtml.AppendLine("</body>");
            mergedHtml.AppendLine("</html>");
            
            // Ensure directory exists
            string directory = Path.GetDirectoryName(_outputPath);
            if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
            {
                Directory.CreateDirectory(directory);
            }
            
            // Write to file
            await File.WriteAllTextAsync(_outputPath, mergedHtml.ToString());
            Console.WriteLine($"Merged document written to: {_outputPath}");
        }

        // Helper: Levenshtein distance for fuzzy matching
        private static int LevenshteinDistance(string s, string t)
        {
            if (string.IsNullOrEmpty(s)) return t?.Length ?? 0;
            if (string.IsNullOrEmpty(t)) return s.Length;
            int n = s.Length, m = t.Length;
            var d = new int[n+1, m+1];
            for (int i = 0; i <= n; i++) d[i,0] = i;
            for (int j = 0; j <= m; j++) d[0,j] = j;
            for (int i = 1; i <= n; i++)
            {
                for (int j = 1; j <= m; j++)
                {
                    int cost = s[i-1] == t[j-1] ? 0 : 1;
                    d[i,j] = Math.Min(Math.Min(d[i-1,j] + 1, d[i,j-1] + 1), d[i-1,j-1] + cost);
                }
            }
            return d[n,m];
        }

        private static double ComputeSimilarity(string s, string t)
        {
            s = s ?? "";
            t = t ?? "";
            if (s.Length == 0 && t.Length == 0) return 1.0;
            int dist = LevenshteinDistance(s, t);
            int maxLen = Math.Max(s.Length, t.Length);
            return 1.0 - (double)dist / maxLen;
        }

        // Merge unique sections robustly
        private void ConsolidateSections()
        {
            // similarity thresholds
            const double thresholdExact = 0.0;     // exact match for normalized suffix
            const double thresholdFuzzy1 = 0.8;     // stage1 fuzzy
            const double thresholdFuzzy2 = thresholdFuzzy1;  // stage2 fuzzy same as stage1
            
            // Stage1: Numeric prefix grouping for unique singleton sections (major prefix)
            var keys = _sectionsByHeading.Keys.ToList();
            foreach (var key in keys)
            {
                if (!_sectionsByHeading.ContainsKey(key)) continue;
                var list = _sectionsByHeading[key];
                if (list.Count != 1) continue;
                var matchMajor = Regex.Match(key, @"^(\d+)");
                if (!matchMajor.Success) continue;
                string major = matchMajor.Groups[1].Value;
                // compute suffix and normalized suffix
                string suffixKey = Regex.Replace(key, @"^[\d\.]+\s*", "");
                string normSuffixKey = Regex.Replace(suffixKey.ToLowerInvariant(), @"[\s\W]+", "");
                // try exact match among same major prefix
                var exact = _sectionsByHeading.Keys.FirstOrDefault(cand =>
                    !cand.Equals(key, StringComparison.OrdinalIgnoreCase)
                    && Regex.Match(cand, @"^(\d+)").Groups[1].Value == major
                    && Regex.Replace(Regex.Replace(cand, @"^[\d\.]+\s*", "").ToLowerInvariant(), @"[\s\W]+", "") == normSuffixKey);
                if (exact != null)
                {
                    _sectionsByHeading[exact].Add(list[0]);
                    _sectionsByHeading.Remove(key);
                    continue;
                }
                // fuzzy match among same major prefix
                double bestScore = 0.0; string bestCandidate = null;
                foreach (var cand in _sectionsByHeading.Keys)
                {
                    if (cand.Equals(key, StringComparison.OrdinalIgnoreCase)) continue;
                    var matchCand = Regex.Match(cand, @"^(\d+)");
                    if (!matchCand.Success || matchCand.Groups[1].Value != major) continue;
                    string sufCand = Regex.Replace(cand, @"^[\d\.]+\s*", "");
                    double sim = ComputeSimilarity(normSuffixKey, Regex.Replace(sufCand.ToLowerInvariant(), @"[\s\W]+", ""));
                    if (sim > bestScore)
                    {
                        bestScore = sim;
                        bestCandidate = cand;
                    }
                }
                if (bestScore >= thresholdFuzzy1 && bestCandidate != null)
                {
                    _sectionsByHeading[bestCandidate].Add(list[0]);
                    _sectionsByHeading.Remove(key);
                }
            }

            // Stage2: Fuzzy header similarity for remaining unique singleton sections
            var normalize = new Func<string, string>(s => Regex.Replace(s.ToLowerInvariant(), @"[\s\W]+", ""));
            var keys2 = _sectionsByHeading.Keys.ToList();
            foreach (var key2 in keys2)
            {
                if (!_sectionsByHeading.ContainsKey(key2)) continue;
                var list2 = _sectionsByHeading[key2];
                if (list2.Count == 1)
                {
                    // normalized suffix for key2
                    string suffix2 = Regex.Replace(key2, @"^[\d\.]+\s*", "");
                    string normSuffix2 = normalize(suffix2);
                    // exact grouping on normalized suffix
                    var exact2 = _sectionsByHeading.Keys
                                  .FirstOrDefault(k => !k.Equals(key2, StringComparison.OrdinalIgnoreCase)
                                                    && normalize(Regex.Replace(k, @"^[\d\.]+\s*", "")) == normSuffix2);
                    if (exact2 != null)
                    {
                        _sectionsByHeading[exact2].Add(list2[0]);
                        _sectionsByHeading.Remove(key2);
                        continue;
                    }
                    double bestScore2 = 0.0; string bestKey2 = null;
                    foreach (var k in _sectionsByHeading.Keys)
                    {
                        if (k.Equals(key2, StringComparison.OrdinalIgnoreCase)) continue;
                        string suffixK = Regex.Replace(k, @"^[\d\.]+\s*", "");
                        string normSuffixK = normalize(suffixK);
                        double sim = ComputeSimilarity(normSuffix2, normSuffixK);
                        if (sim > bestScore2)
                        {
                            bestScore2 = sim;
                            bestKey2 = k;
                        }
                    }
                    if (bestScore2 >= thresholdFuzzy2 && bestKey2 != null)
                    {
                        _sectionsByHeading[bestKey2].Add(list2[0]);
                        _sectionsByHeading.Remove(key2);
                    }
                }
            }

            // Stage3: Content-based fuzzy grouping for remaining singleton sections
            var contentNormalize = new Func<string, string>(html =>
            {
                var tmpDoc = new HtmlDocument();
                tmpDoc.LoadHtml(html);
                var text = tmpDoc.DocumentNode.InnerText;
                return Regex.Replace(text.ToLowerInvariant(), @"[\s\W]+", " ").Trim();
            });
            // Find all groups with a single section
            var singleKeys = _sectionsByHeading.Where(kvp => kvp.Value.Count == 1)
                                             .Select(kvp => kvp.Key)
                                             .ToList();
            foreach (var singleKey in singleKeys)
            {
                if (!_sectionsByHeading.ContainsKey(singleKey)) continue;
                var section = _sectionsByHeading[singleKey][0];
                var normContent = contentNormalize(section.HtmlContent);
                double bestScoreC = 0; string bestGroup = null;
                foreach (var kvp in _sectionsByHeading)
                {
                    if (kvp.Key.Equals(singleKey, StringComparison.OrdinalIgnoreCase)) continue;
                    // only compare to groups with more than one section
                    if (kvp.Value.Count < 2) continue;
                    foreach (var other in kvp.Value)
                    {
                        var normOther = contentNormalize(other.HtmlContent);
                        var sim = ComputeSimilarity(normContent, normOther);
                        if (sim > bestScoreC)
                        {
                            bestScoreC = sim;
                            bestGroup = kvp.Key;
                        }
                    }
                }
                // merge if content similarity above thresholdFuzzy1
                if (bestScoreC >= thresholdFuzzy1 && bestGroup != null)
                {
                    _sectionsByHeading[bestGroup].Add(section);
                    _sectionsByHeading.Remove(singleKey);
                }
            }
        }
    }

    public class DocumentSection
    {
        public string DocumentName { get; set; }
        public string HeadingText { get; set; }
        public string HtmlContent { get; set; }
    }
}
