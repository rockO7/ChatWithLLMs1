﻿using Microsoft.Extensions.Hosting;
using ModelContextProtocol.Server;
using System.ComponentModel;

//client:

//// See https://aka.ms/new-console-template for more information
//using ModelContextProtocol.Client;
//using System.Collections.Generic;

////var serverPath = Path.GetFullPath("../McpServer/bin/Debug/net8.0/McpServer.exe").Replace("/", "\\");
//var serverPath = @"C:\Users\Deepak\Desktop\Other\MCP-1\McpClient\McpServer\bin\Debug\net8.0\McpServer.exe";
//Console.WriteLine($"Server path: {serverPath}");

//var clientTransport = new StdioClientTransport(new StdioClientTransportOptions
//{
//    Name = "CSharpServer",
//    Command = serverPath,
//    Arguments = Array.Empty<string>(),
//});

//var client = await McpClientFactory.CreateAsync(clientTransport);

//// Print the list of tools available from the server.
//foreach (var tool in await client.ListToolsAsync())
//{
//    Console.WriteLine($"{tool.Name} ({tool.Description})");
//}

//// Execute a tool (this would normally be driven by LLM tool invocations).
//var result = await client.CallToolAsync(
//    "Echo",
//    new Dictionary<string, object?>() { ["message"] = "Hello MCP!" },
//    cancellationToken: CancellationToken.None);


//// echo always returns one and only one text content object
//Console.WriteLine(result.Content.First(c => c.Type == "text").Text);





//Server:


//using Microsoft.Extensions.DependencyInjection;
//using Microsoft.Extensions.Hosting;
//using Microsoft.Extensions.Logging;
//using ModelContextProtocol.Server;
//using System.ComponentModel;

//var builder = Host.CreateApplicationBuilder(args);
//builder.Logging.AddConsole(consoleLogOptions =>
//{
//    // Configure all logs to go to stderr
//    consoleLogOptions.LogToStandardErrorThreshold = LogLevel.Trace;
//});
//builder.Services
//    .AddMcpServer()
//    .WithStdioServerTransport()
//    .WithToolsFromAssembly();
//await builder.Build().RunAsync();

//[McpServerToolType]
//public static class EchoTool
//{
//    [McpServerTool, Description("Echoes the message back to the client.")]
//    public static string Echo(string message) => $"hello {message}";
//}