using System;
using System.IO;
using HtmlAgilityPack;
using System.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;

public static class HeadingBolder
{
    public static async Task BoldHeadingsForTocAnchorsAsync(string inputPath, string outputPath)
    {
        var doc = new HtmlDocument();

        try
        {
            using (var stream = File.OpenRead(inputPath))
            {
                doc.Load(stream);
            }
        }
        catch (FileNotFoundException)
        {
            Console.WriteLine($"Warning: File not found, skipping heading bolding: {inputPath}");
            return;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error loading file for heading bolding '{inputPath}': {ex.Message}");
            return;
        }

        var tocAnchorIds = new HashSet<string>();

        // 1) Detect TOC links
        var potentialTocParas = doc.DocumentNode
                                   .SelectNodes("//body/p")
                                   ?.ToList() ?? new List<HtmlNode>();

        foreach (var p in potentialTocParas)
        {
            var a = p.SelectSingleNode(".//a[@href]");
            if (a != null)
            {
                 var href = a.GetAttributeValue("href", "");
                 if (!string.IsNullOrEmpty(href) && href.StartsWith("#"))
                 {
                     var anchorId = href.Substring(1);
                     if (!string.IsNullOrWhiteSpace(anchorId))
                     {
                          tocAnchorIds.Add(anchorId);
                     }
                 }
            }
        }

        if (!tocAnchorIds.Any())
        {
             return; // Exit silently if no TOC found
        }

        // 2) Actually bold the headings
        bool modified = false;
        var sectionStartNodes = new List<HtmlNode>(); // Keep track of nodes where sections start

        var nameAnchors = doc.DocumentNode.SelectNodes("//a[@name]");
        if (nameAnchors != null)
        {
            foreach (var anchor in nameAnchors)
            {
                var name = anchor.GetAttributeValue("name", "");

                if (string.IsNullOrEmpty(name) || !tocAnchorIds.Contains(name))
                {
                    continue;
                }

                HtmlNode headingContainer;
                // Prefer the parent if it's li or p, otherwise use the anchor's parent or the anchor itself
                if (anchor.ParentNode?.Name == "li")
                {
                    headingContainer = anchor.ParentNode;
                }
                else
                {
                    headingContainer = anchor.ParentNode ?? anchor;
                }

                if (headingContainer.Name is "p" or "li")
                {
                    // Check if already contains the custom bold class
                    if (headingContainer.SelectSingleNode(".//b[@class='custom-bold-heading']") == null)
                    {
                        headingContainer.InnerHtml =
                            "<hr style=\"border:1px solid black;margin:12px 0;\" />" +
                            $"<b class=\"custom-bold-heading\">{headingContainer.InnerHtml}</b>";

                        sectionStartNodes.Add(headingContainer); // Mark this node as a section start
                        modified = true;
                    }
                }
                // If container isn't p/li, bold the anchor itself if it has content
                // Check based on the anchor itself, assuming HR+B are added together
                else if (!string.IsNullOrWhiteSpace(anchor.InnerHtml) && anchor.SelectSingleNode(".//b[@class='custom-bold-heading']") == null)
                {
                    anchor.InnerHtml =
                        "<hr style=\"border:1px solid black;margin:12px 0;\" />" +
                        $"<b class=\"custom-bold-heading\">{anchor.InnerHtml.Trim()}</b>";

                    sectionStartNodes.Add(anchor); // Mark this node as a section start
                    modified = true;
                }
            }
        }

        // 3) Wrap everything from one HR to the next inside <div>
        if (sectionStartNodes.Any()) // Only wrap if we actually bolded something
        {
            WrapSections(doc, sectionStartNodes); // Pass the list of start nodes
        }

        // 4) Save to outputPath if anything changed
        if (modified)
        {
            try
            {
                // Ensure output directory exists
                var outputDir = Path.GetDirectoryName(outputPath);
                if (!string.IsNullOrEmpty(outputDir) && !Directory.Exists(outputDir))
                {
                    Directory.CreateDirectory(outputDir);
                }

                using (var stream = File.Create(outputPath))
                {
                    doc.Save(stream);
                    await stream.FlushAsync().ConfigureAwait(false);
                }
                 Console.WriteLine($"Created File {outputPath}"); // Keep user-facing confirmation
            }
             catch (Exception ex)
            {
                Console.WriteLine($"Error saving modified file '{outputPath}': {ex.Message}");
            }
        }
    }

    // -----------------------------------------------------------
    // Helper: groups siblings into <div> blocks
    // Uses the provided list of section start nodes to identify sections.
    // -----------------------------------------------------------
    private static void WrapSections(HtmlDocument doc, List<HtmlNode> sectionStartNodes, string wrapperClass = "custom-section")
    {
        var body = doc.DocumentNode.SelectSingleNode("//body");
        if (body == null)
        {
            return;
        }

        // Remove all div tags as per requirement
        var divs = body.SelectNodes(".//div");
        if (divs != null)
        {
            foreach (var div in divs.ToList())
            {
                foreach (var child in div.ChildNodes.ToList())
                {
                    div.ParentNode.InsertBefore(child.Clone(), div);
                }
                div.Remove();
            }
        }

        // Normalize section start nodes to direct children of body
        var sectionStartSet = new HashSet<HtmlNode>();
        foreach (var startNode in sectionStartNodes)
        {
            var current = startNode;
            while (current.ParentNode != null && current.ParentNode.Name != "body")
                current = current.ParentNode;
            sectionStartSet.Add(current);
        }

        var originalChildNodes = body.ChildNodes.ToList(); // Get original nodes BEFORE manipulation
        HtmlNode currentWrapper = null;

        body.RemoveAllChildren(); // Clear body to rebuild

        // Wrap pre-section nodes in TableofContents or section wrappers
        bool tocCreated = false;
        foreach (var node in originalChildNodes)
        {
            bool isSectionStart = sectionStartSet.Contains(node);

            if (isSectionStart)
            {
                currentWrapper = HtmlNode.CreateNode($"<div class=\"{wrapperClass}\"></div>");
                body.AppendChild(currentWrapper);
                tocCreated = true;
            }
            else if (!tocCreated)
            {
                currentWrapper = HtmlNode.CreateNode("<div class=\"TableofContents\"></div>");
                body.AppendChild(currentWrapper);
                tocCreated = true;
            }

            if (currentWrapper != null)
            {
                currentWrapper.AppendChild(node.Clone());
            }
            else
            {
                body.AppendChild(node.Clone());
            }
        }
    }


 // -----------------------------------------------------------
    // Helper: groups siblings into <div> blocks V3
    // Detects section start by looking *inside* nodes for the HR+B pattern.
    // -----------------------------------------------------------
    private static void WrapSections(HtmlDocument doc, string wrapperClass = "custom-section") // Removed sectionStartNodes parameter
    {
        var body = doc.DocumentNode.SelectSingleNode("//body");
        if (body == null)
        {
            return;
        }

        var originalChildNodes = body.ChildNodes.ToList(); // Get nodes after bolding/hr insertion
        HtmlNode currentWrapper = null;

        body.RemoveAllChildren(); // Clear body to rebuild

        foreach (var node in originalChildNodes)
        {
            bool isSectionStart = false;
            // Check if this node OR any descendant contains the HR and B marker
            // Check specifically for p/li/a containing the pattern, as those were the elements modified.
            var headingMarkerNode = node.SelectSingleNode(".//*[self::p or self::li or self::a][.//hr and .//b[@class='custom-bold-heading']]");

            if (headingMarkerNode != null) {
                // More precise check: Find HR and B within the potential marker node
                var hr = headingMarkerNode.SelectSingleNode(".//hr");
                var b = headingMarkerNode.SelectSingleNode(".//b[@class='custom-bold-heading']");
                // Simple check: if both exist within the same p/li/a container, treat as start.
                // A stricter check might look at sibling order, but this is likely sufficient.
                if (hr != null && b != null) {
                     isSectionStart = true;
                }
            }


            if (isSectionStart)
            {
                // If this node contains a section start marker, create a new div wrapper
                currentWrapper = HtmlNode.CreateNode($"<div class=\"{wrapperClass}\"></div>");
                body.AppendChild(currentWrapper); // Add the wrapper to the body first
            }

            // If we have an active wrapper (meaning we are inside a section),
            // append the current node (cloned) into it.
            if (currentWrapper != null)
            {
                // Avoid adding empty text nodes between wrappers
                if (!(node.NodeType == HtmlNodeType.Text && string.IsNullOrWhiteSpace(node.InnerHtml)))
                {
                    currentWrapper.AppendChild(node.Clone());
                }
            }
            // Otherwise (content before the first section OR empty text node),
            // append directly (cloned) to the body
            else
            {
                 // Avoid adding empty text nodes at the top level unless it's genuinely intended
                if (!(node.NodeType == HtmlNodeType.Text && string.IsNullOrWhiteSpace(node.InnerHtml)))
                {
                   body.AppendChild(node.Clone());
                }
            }
        }
    }
}