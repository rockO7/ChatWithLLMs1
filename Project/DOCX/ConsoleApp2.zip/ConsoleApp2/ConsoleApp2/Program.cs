﻿// -----------------------------------------------------------------------------
// Program.cs – fast, lightweight version  (compile-tested)
//   dotnet add package HtmlAgilityPack
// -----------------------------------------------------------------------------
// > dotnet run -- input.html
// -----------------------------------------------------------------------------
using System;
using System.Buffers;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using HtmlAgilityPack;

namespace HtmlComparerFast
{
    internal static class Program
    {
        private const double SIM_THRESHOLD = 0.90;   // 90 %

        static void Main()
        {
            string inputPath = "MergedDocument.html";
            if (!File.Exists(inputPath))
            {
                Console.WriteLine($"❌ File not found: {inputPath}");
                return;
            }

            string htmlRaw = File.ReadAllText(inputPath);
            var sections = ParseSections(htmlRaw);

            var md = new StringBuilder();
            foreach (var headGroup in sections.GroupBy(s => s.Heading))
                BuildHeadingReport(headGroup.Key, headGroup.ToList(), md);

            string outPath = Path.ChangeExtension(inputPath, ".report.md");
            File.WriteAllText(outPath, md.ToString());
            Console.WriteLine($"✅  Report → {outPath}");
        }

        // ────────────────────────────────────────────────────────────────
        // SECTION CLASS
        // ────────────────────────────────────────────────────────────────
        private sealed class Section
        {
            public string Heading = "";
            public string UW = "";
            public string Text = "";                // full rendered
            public string Track = "";                // ADD/DEL only
            public HashSet<string> TokensFull = new();
            public HashSet<string> TokensTrack = new();
            public string Md5Full = "";
            public string Md5Track = "";
        }

        // ────────────────────────────────────────────────────────────────
        // 1.  PARSE & RENDER IN ONE SWEEP
        // ────────────────────────────────────────────────────────────────
        private static List<Section> ParseSections(string html)
        {
            var doc = new HtmlDocument();
            doc.LoadHtml(html);

            var secs = new List<Section>();
            var pool = ArrayPool<char>.Shared;

            foreach (var h2 in doc.DocumentNode.SelectNodes("//h2") ?? new HtmlNodeCollection(null))
            {
                string heading = CollapseWs(h2.InnerText);
                var node = h2.NextSibling;

                while (node != null && node.Name != "h2")
                {
                    if (node.Name.Equals("details", StringComparison.OrdinalIgnoreCase))
                    {
                        var sec = new Section { Heading = heading };
                        sec.UW = CollapseWs(node.SelectSingleNode("./summary")?.InnerText ?? "UNKNOWN");

                        BuildStrings(node, sec, pool);

                        sec.Md5Full = Md5(sec.Text);
                        sec.Md5Track = Md5(sec.Track);

                        secs.Add(sec);
                    }
                    node = node.NextSibling;
                }
            }
            return secs;
        }

        private enum Mode { Norm, Add, Del }

        private static void BuildStrings(HtmlNode root, Section s, ArrayPool<char> pool)
        {
            var full = new StringBuilder();
            var track = new StringBuilder();
            var buf = new StringBuilder();
            Mode mode = Mode.Norm;

            void Flush()
            {
                if (buf.Length == 0) return;

                if (mode == Mode.Norm)
                {
                    full.Append(buf).Append(' ');
                    TokeniseInto(buf.ToString(), s.TokensFull, pool);
                }
                else
                {
                    string tag = mode == Mode.Add ? "ADD" : "DEL";
                    string marker = $"[{tag} - {buf}] ";
                    full.Append(marker);
                    track.Append(marker);
                    TokeniseInto(buf.ToString(), s.TokensTrack, pool);
                }
                buf.Clear();
            }

            void Add(Mode m, string txt)
            {
                if (string.IsNullOrWhiteSpace(txt)) return;
                if (m == mode)
                    buf.Append(' ').Append(txt);
                else
                {
                    Flush();
                    mode = m;
                    buf.Append(txt);
                }
            }

            // iterative DFS (no recursion)
            var st = new Stack<HtmlNode>();
            st.Push(root);

            while (st.Count > 0)
            {
                var n = st.Pop();

                switch (n.NodeType)
                {
                    case HtmlNodeType.Text:
                        Add(Mode.Norm, CollapseWs(n.InnerText));
                        break;

                    case HtmlNodeType.Element:
                        if (n.Name == "ins")
                            Add(Mode.Add, CollapseWs(n.InnerText));
                        else if (n.Name == "del")
                            Add(Mode.Del, CollapseWs(n.InnerText));
                        else if (n.Name.Equals("table", StringComparison.OrdinalIgnoreCase))
                        {
                            Flush();                       // flush current buffer first
                            string mdTable = ConvertTableToMarkdown(n);
                            full.AppendLine().AppendLine(mdTable).AppendLine();
                            track.AppendLine().AppendLine(mdTable).AppendLine();
                            mode = Mode.Norm;             // reset
                        }
                        else
                        {
                            for (int i = n.ChildNodes.Count - 1; i >= 0; i--)
                                st.Push(n.ChildNodes[i]);
                        }
                        break;
                }
            }
            Flush();

            s.Text = NormalizeText(full.ToString());
            s.Track = NormalizeText(track.ToString());

            // ensure full-text tokens exist
            if (s.TokensFull.Count == 0 && s.Text.Length > 0)
                TokeniseInto(s.Text, s.TokensFull, pool);
        }

        // ────────────────────────────────────────────────────────────────
        // 2.  HEADING-LEVEL REPORT
        // ────────────────────────────────────────────────────────────────
        private static void BuildHeadingReport(string heading, List<Section> secs, StringBuilder md)
        {
            md.AppendLine($"-------------------------------------------------\n## {heading}\n");

            // STEP-1 : full section comparison
            md.AppendLine("### 1. Complete Section Level Comparison");
            var fullBuckets = Cluster(secs, s => s.Md5Full, s => s.TokensFull);
            DumpBuckets(fullBuckets, pick: s => s.Text, md);

            // STEP-2 : track changes
            md.AppendLine("\n### 2. Ins and Del Content Comparison");
            foreach (var bucket in fullBuckets)
            {
                if (bucket.Count == 1)
                {
                    DumpTrack(bucket[0], unique: true, sameAcross: null, md);
                    continue;
                }

                var tBuckets = Cluster(bucket, s => s.Md5Track, s => s.TokensTrack);
                foreach (var b in tBuckets)
                    DumpTrack(
                        section: b[0],
                        unique: b.Count == 1,
                        sameAcross: b.Count > 1 ? string.Join(", ", b.Select(x => x.UW)) : null,
                        md: md);
            }
        }

        private static void DumpBuckets(List<List<Section>> buckets,
                                        Func<Section, string> pick,
                                        StringBuilder md)
        {
            foreach (var b in buckets)
            {
                string content = pick(b[0]);

                if (ContainsMarkdownTable(content))
                    md.AppendLine(content);
                else
                    md.Code(content);

                if (b.Count == 1)
                    md.AppendLine($"Unique to → {b[0].UW}\n");
                else
                    md.AppendLine($"Same across → {string.Join(", ", b.Select(x => x.UW))}\n");
            }
        }

        private static void DumpTrack(Section section, bool unique,
                                      string sameAcross, StringBuilder md)
        {
            if (string.IsNullOrWhiteSpace(section.Track)) return;

            if (ContainsMarkdownTable(section.Track))
                md.AppendLine(section.Track);
            else
                md.Code(section.Track);

            md.AppendLine(unique
                ? $"Unique to → {section.UW}\n"
                : $"Same across → {sameAcross}\n");
        }

        // ────────────────────────────────────────────────────────────────
        // 3.  FAST CLUSTERING  (Jaccard)
        // ────────────────────────────────────────────────────────────────
        private static List<List<Section>> Cluster(
            List<Section> items,
            Func<Section, string> md5Getter,
            Func<Section, HashSet<string>> tokenGetter)
        {
            var buckets = new List<List<Section>>();

            foreach (var s in items)
            {
                bool placed = false;

                // identical MD5? → first such bucket
                foreach (var b in buckets)
                    if (md5Getter(b[0]) == md5Getter(s))
                    { b.Add(s); placed = true; break; }

                if (placed) continue;

                foreach (var b in buckets)
                {
                    if (QuickReject(b[0].Text, s.Text)) continue;
                    if (Jaccard(tokenGetter(b[0]), tokenGetter(s)) >= SIM_THRESHOLD)
                    { b.Add(s); placed = true; break; }
                }

                if (!placed) buckets.Add(new List<Section> { s });
            }
            return buckets;
        }

        private static bool QuickReject(string a, string b)
        {
            int l1 = a.Length, l2 = b.Length;
            return Math.Abs(l1 - l2) / (double)Math.Max(l1, l2) > (1 - SIM_THRESHOLD);
        }

        private static double Jaccard(HashSet<string> A, HashSet<string> B)
        {
            int inter = 0;
            foreach (var w in A) if (B.Contains(w)) inter++;
            int union = A.Count + B.Count - inter;
            return union == 0 ? 1 : inter / (double)union;
        }

        // ────────────────────────────────────────────────────────────────
        // 4.  UTILITIES
        // ────────────────────────────────────────────────────────────────
        private static readonly Regex _rxWs = new(@"\s+", RegexOptions.Compiled);

        private static string CollapseWs(string s)
            => string.IsNullOrWhiteSpace(s) ? "" : _rxWs.Replace(s, " ").Trim();

        private static void TokeniseInto(string text, HashSet<string> set, ArrayPool<char> _)
        {
            var span = text.AsSpan();
            int i = 0;
            while (i < span.Length)
            {
                while (i < span.Length && !char.IsLetterOrDigit(span[i])) i++;
                int start = i;
                while (i < span.Length && char.IsLetterOrDigit(span[i])) i++;
                if (start < i)
                    set.Add(span[start..i].ToString().ToLowerInvariant());
            }
        }

        // -------------  TABLE → MARKDOWN (WITH TRACK CHANGES) ----------
        private static string ConvertTableToMarkdown(HtmlNode table)
        {
            var rows = table.SelectNodes(".//tr");
            if (rows == null || rows.Count == 0) return "";

            // Build a string matrix first so we know the widest column count
            var matrix = new List<List<string>>();
            foreach (var row in rows)
            {
                var cells = row.SelectNodes("./th|./td");
                if (cells == null) continue;

                var list = new List<string>();
                foreach (var cell in cells)
                    list.Add(RenderCell(cell));

                matrix.Add(list);
            }
            if (matrix.Count == 0) return "";

            int cols = matrix.Max(r => r.Count);

            var sb = new StringBuilder();

            // header row (first row in source)
            var header = matrix[0];
            if (header.Count < cols)
                header.AddRange(Enumerable.Repeat("", cols - header.Count));
            sb.Append("| ").Append(string.Join(" | ", header)).AppendLine(" |");

            // divider
            sb.Append("| ").Append(string.Join(" | ", Enumerable.Repeat("---", cols)))
              .AppendLine(" |");

            // the rest
            foreach (var row in matrix.Skip(1))
            {
                if (row.Count < cols)
                    row.AddRange(Enumerable.Repeat("", cols - row.Count));
                sb.Append("| ").Append(string.Join(" | ", row)).AppendLine(" |");
            }
            return sb.ToString();
        }

        // render a single <td>/<th> including [ADD]/[DEL] markers
        private static string RenderCell(HtmlNode cell)
        {
            var parts = new List<string>();

            void Walk(HtmlNode n)
            {
                switch (n.NodeType)
                {
                    case HtmlNodeType.Text:
                        var txt = CollapseWs(n.InnerText);
                        if (txt.Length > 0) parts.Add(txt);
                        break;

                    case HtmlNodeType.Element:
                        if (n.Name.Equals("ins", StringComparison.OrdinalIgnoreCase))
                        {
                            var txtAdd = CollapseWs(n.InnerText);
                            if (txtAdd.Length > 0) parts.Add($"[ADD - {txtAdd}]");
                        }
                        else if (n.Name.Equals("del", StringComparison.OrdinalIgnoreCase))
                        {
                            var txtDel = CollapseWs(n.InnerText);
                            if (txtDel.Length > 0) parts.Add($"[DEL - {txtDel}]");
                        }
                        else
                        {
                            foreach (var child in n.ChildNodes)
                                Walk(child);
                        }
                        break;
                }
            }
            foreach (var child in cell.ChildNodes)
                Walk(child);

            return string.Join(" ", parts);
        }

        private static string NormalizeText(string s)
        {
            var lines = s.Split('\n')
                         .Select(line => _rxWs.Replace(line, " ").Trim())
                         .Where(line => line.Length > 0);

            return string.Join("\n", lines);
        }

        private static string Md5(string s)
        {
            if (s.Length == 0) return "";
            using var md5 = MD5.Create();
            return Convert.ToHexString(
                md5.ComputeHash(Encoding.UTF8.GetBytes(s)));
        }

        // ────────────────────────────────────────────────────────────────
        // Helpers
        // ────────────────────────────────────────────────────────────────

        // detect a Markdown table anywhere in the text
        private static bool ContainsMarkdownTable(string content)
            => Regex.IsMatch(content, @"(^|\n)\s*\|.*\n\|[^\n]*\-\-\-",
                             RegexOptions.Singleline);

        // Markdown helper
        private static void Code(this StringBuilder sb, string content)
        {
            content = content.TrimEnd();

            if (ContainsMarkdownTable(content))
                sb.AppendLine(content);                 // already a table
            else
            {
                sb.AppendLine("```");
                sb.AppendLine(content);
                sb.AppendLine("```");
            }
        }
    }
}