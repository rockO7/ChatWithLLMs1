using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace WindSurfConsoleApp
{
    public interface IStringSimilarity { double Score(string a, string b); }

    public sealed class Levenshtein : IStringSimilarity
    {
        public double Score(string a, string b)
        {
            if (a == b) return 1;
            int n = a.Length, m = b.Length;
            if (n == 0 || m == 0) return 0;
            var d = new int[n + 1, m + 1];
            for (int i = 0; i <= n; i++) d[i, 0] = i;
            for (int j = 0; j <= m; j++) d[0, j] = j;

            for (int i = 1; i <= n; i++)
                for (int j = 1; j <= m; j++)
                {
                    int cost = a[i - 1] == b[j - 1] ? 0 : 1;
                    d[i, j] = Math.Min(Math.Min(d[i - 1, j] + 1,
                                                d[i, j - 1] + 1),
                                                d[i - 1, j - 1] + cost);
                }
            int dist = d[n, m];
            return 1 - (double)dist / Math.Max(n, m);
        }
    }

    public sealed class JaroWinkler : IStringSimilarity
    {
        public double Score(string s1, string s2)
        {
            if (s1 == s2) return 1;
            if (s1.Length == 0 || s2.Length == 0) return 0;

            int matchDist = Math.Max(s1.Length, s2.Length) / 2 - 1;
            var s1m = new bool[s1.Length];
            var s2m = new bool[s2.Length];

            int matches = 0;
            for (int i = 0; i < s1.Length; i++)
            {
                int start = Math.Max(0, i - matchDist);
                int end   = Math.Min(i + matchDist + 1, s2.Length);
                for (int j = start; j < end; j++)
                {
                    if (s2m[j] || s1[i] != s2[j]) continue;
                    s1m[i] = s2m[j] = true; matches++; break;
                }
            }
            if (matches == 0) return 0;

            double t = 0;
            for (int i = 0, k = 0; i < s1.Length; i++)
                if (s1m[i])
                {
                    while (!s2m[k]) k++;
                    if (s1[i] != s2[k]) t++;
                    k++;
                }
            t /= 2;

            double m = matches;
            double jaro = (m / s1.Length + m / s2.Length + (m - t) / m) / 3;
            int l = 0;
            while (l < 4 && l < s1.Length && l < s2.Length && s1[l] == s2[l]) l++;
            return jaro + l * 0.1 * (1 - jaro);
        }
    }

    public sealed class JaccardTokens : IStringSimilarity
    {
        public double Score(string a, string b)
        {
            var setA = a.Split(' ', StringSplitOptions.RemoveEmptyEntries).ToHashSet();
            var setB = b.Split(' ', StringSplitOptions.RemoveEmptyEntries).ToHashSet();
            if (setA.Count == 0 && setB.Count == 0) return 1;
            int inter = setA.Intersect(setB).Count();
            int union = setA.Count + setB.Count - inter;
            return (double)inter / union;
        }
    }

    internal static class SimilarityHelpers
    {
        public static double Composite(DocSection a, DocSection b, MergeOptions opt)
        {
            double sum = 0;
            foreach (var m in opt.Similarities)
                sum += m.Score(a.HeadingKey, b.HeadingKey);
            return sum / opt.Similarities.Count;
        }

        public static double AdaptiveThreshold(IEnumerable<double> sims)
        {
            var arr = sims.ToArray(); if (arr.Length == 0) return .9;
            double µ = arr.Average();
            double σ = Math.Sqrt(arr.Sum(x => (x - µ) * (x - µ)) / arr.Length);
            return Math.Max(.75, µ - .5 * σ);
        }

        // first 3 logical lines ➜ Jaccard similarity (0..1)
        private static readonly JaccardTokens JT = new();
        public static double ContentSim(DocSection a, DocSection b)
        {
            string a3 = FirstLines(a.Text);
            string b3 = FirstLines(b.Text);
            return JT.Score(a3, b3);
        }
        public static string FirstLines(string text, int n = 3)
        {
            var canonical = TextTools.Canonical(text);
            var parts = Regex.Split(canonical, @"(?:\.\s+|\n)")
                             .Where(x => x.Length > 0).Take(n);
            return string.Join(' ', parts);
        }
    }
} 