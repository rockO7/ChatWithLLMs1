using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace WindSurfConsoleApp
{
    internal static class HtmlWriter
    {
        public static async Task WriteAsync(IEnumerable<SectionGroup> groups,
                                            string file, CancellationToken ct)
        {
            var sb = new StringBuilder();
            sb.AppendLine("<!DOCTYPE html><html><head><meta charset='UTF-8'><title>Merged</title>");
            sb.AppendLine("<style>h2{font-weight:bold;font-size:24px;margin:20px 0}" +
                          "details{margin:10px 0}summary{font-weight:bold;font-size:18px;" +
                          "cursor:pointer;background:#f0f0f0;padding:5px}</style></head><body>");

            foreach (var g in groups.OrderBy(g => g.CanonicalHeading, StringComparer.OrdinalIgnoreCase))
            {
                sb.AppendLine($"<h2>{System.Net.WebUtility.HtmlEncode(g.CanonicalHeading)}</h2>");
                foreach (var s in g.Entries.OrderBy(e => e.DocumentName))
                {
                    sb.AppendLine("<details>");
                    sb.AppendLine($"<summary>{System.Net.WebUtility.HtmlEncode(s.DocumentName)}</summary>");
                    sb.AppendLine(s.Html);
                    sb.AppendLine("</details>");
                }
                sb.AppendLine("<hr/>");
            }
            sb.AppendLine("</body></html>");

            Directory.CreateDirectory(Path.GetDirectoryName(file)!);
            await File.WriteAllTextAsync(file, sb.ToString(), ct);
        }
    }
} 