using System;
using System.IO;
using HtmlAgilityPack;
using System.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Diagnostics;

public class HtmlFileCleaner
{
    public async Task CleanAllHtmlFilesAsync(string inputDir = "HtmlFiles", string outputDir = "HtmlFiles/Cleaned")
    {
        Directory.CreateDirectory(outputDir); 
        var htmlFiles = Directory.GetFiles(inputDir, "*.html")
                                 .ToList(); 
        
        if (!htmlFiles.Any())
        {
            Debug.WriteLine("--- WARNING: No .html files found in input directory! ---");
            return;
        }

        foreach (var inputPath in htmlFiles)
        {
            string fileName = Path.GetFileName(inputPath);
            string outputPath = Path.Combine(outputDir, fileName);
            await CleanHtmlFileAsync(inputPath, outputPath).ConfigureAwait(false);
            Debug.WriteLine($"--- Cleaned: {fileName} ---"); 
        }
        Debug.WriteLine($"--- Finished cleaning specified files in '{outputDir}'. ---"); 
    }

    public async Task CleanHtmlFileAsync(string inputPath, string outputPath)
    {
        var doc = new HtmlDocument();
        using (var stream = File.OpenRead(inputPath))
        {
            doc.Load(stream);
        }

        // 1. Remove all <style> tags
        foreach (var styleNode in doc.DocumentNode.SelectNodes("//style") ?? new HtmlNodeCollection(doc.DocumentNode))
        {
            styleNode.Remove();
        }

        // 2. Remove all <div> with -aw-headerfooter-type in style (and their content)
        foreach (var div in (doc.DocumentNode.SelectNodes("//div[contains(@style, '-aw-headerfooter-type')]")?.ToList() ?? new List<HtmlNode>()))
        {
            div.Remove();
        }

        // 3. Additional cleaning: remove header/footer divs based on content heuristics
        foreach (var div in (doc.DocumentNode.SelectNodes("//div")?.ToList() ?? new List<HtmlNode>()))
        {
            var text = div.InnerText.Trim();
            if (text.Length > 0 && text.Length < 150 && text.Contains("State of") && text.Contains("Effective:"))
            {
                div.Remove();
            }
        }

        // 4. Remove all style attributes
        foreach (var node in doc.DocumentNode.SelectNodes("//*[@style]") ?? new HtmlNodeCollection(doc.DocumentNode))
        {
            node.Attributes["style"].Remove();
        }

        // 5. Remove empty divs (optional, for extra cleanliness)
        foreach (var div in doc.DocumentNode.SelectNodes("//div[not(node())]") ?? new HtmlNodeCollection(doc.DocumentNode))
        {
            div.Remove();
        }

        // 6. Remove empty tags and useless anchors, but keep <a name=...> if referenced by any href
        // Step 1: Collect all anchor names referenced by href="#..."
        var referencedAnchors = new HashSet<string>(
            (doc.DocumentNode.SelectNodes("//a[@href]") ?? new HtmlNodeCollection(doc.DocumentNode))
            .Select(a => a.GetAttributeValue("href", null))
            .Where(href => !string.IsNullOrEmpty(href) && href.StartsWith("#"))
            .Select(href => href.Substring(1))
        );

        foreach (var node in (doc.DocumentNode.SelectNodes("//a[@name]")?.ToList() ?? new List<HtmlNode>()))
        {
            string anchorName = node.GetAttributeValue("name", null);
            if (!string.IsNullOrEmpty(anchorName) && !referencedAnchors.Contains(anchorName))
            {
                // Remove only if not referenced
                if (string.IsNullOrEmpty(HtmlEntity.DeEntitize(node.InnerHtml).Replace("\u00a0", "").Trim()))
                {
                    node.Remove();
                }
            }
        }

        // Continue removing other empty tags
        foreach (var node in (doc.DocumentNode.SelectNodes("//*")?.ToList() ?? new List<HtmlNode>()))
        {
            if (node.Name.ToLower() == "html" || node.Name.ToLower() == "body")
                continue;
            if (node.Name.ToLower() == "a")
            {
                if (node.Attributes["href"] != null)
                    continue;
                if (node.Attributes["name"] != null)
                {
                    // Already handled above
                    continue;
                }
            }
            string content = HtmlEntity.DeEntitize(node.InnerText).Replace("\u00a0", "").Trim();
            if (string.IsNullOrEmpty(content))
            {
                node.Remove();
            }
        }

        // 7. Add styling for inserted, deleted content, and table formatting
        foreach (var ins in doc.DocumentNode.SelectNodes("//ins") ?? new HtmlNodeCollection(doc.DocumentNode))
        {
            ins.SetAttributeValue("style", "color: green !important;");
        }
        foreach (var del in doc.DocumentNode.SelectNodes("//del") ?? new HtmlNodeCollection(doc.DocumentNode))
        {
            del.SetAttributeValue("style", "color: red !important;");
        }
        foreach (var table in doc.DocumentNode.SelectNodes("//table") ?? new HtmlNodeCollection(doc.DocumentNode))
        {
            table.SetAttributeValue("style", "border: 1px solid black; border-collapse: collapse; width: 100%;");
        }
        foreach (var cell in doc.DocumentNode.SelectNodes("//td|//th") ?? new HtmlNodeCollection(doc.DocumentNode))
        {
            cell.SetAttributeValue("style", "border: 1px solid black; padding: 5px;");
        }

        // --- FORMAT HTML OUTPUT FOR READABILITY ---
        string htmlString;
        using (var stringWriter = new StringWriter())
        {
            doc.Save(stringWriter);
            htmlString = stringWriter.ToString();
        }
        // Add a newline after every </div> and </p>
        htmlString = htmlString.Replace("</div>", "</div>\n").Replace("</p>", "</p>\n");

        await File.WriteAllTextAsync(outputPath, htmlString).ConfigureAwait(false);
    }
}
