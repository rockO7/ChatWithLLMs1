using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;
using HtmlAgilityPack;

namespace WindSurfConsoleApp
{
    public class SectionComparer
    {
        private const double SimilarityThreshold = 0.8;

        public static async Task CompareFilesAsync(string[] inputPaths, string outputPath)
        {
            var docs = inputPaths.ToDictionary(
                path => Path.GetFileName(path),
                path => {
                    var doc = new HtmlDocument();
                    using (var stream = File.OpenRead(path))
                    {
                        doc.Load(stream);
                    }
                    return doc;
                });

            // Extract sections by heading
            var sectionsByFile = docs.ToDictionary(
                kvp => kvp.Key,
                kvp => ExtractSections(kvp.Value));

            // Group sections across files
            var groups = GroupSections(sectionsByFile);

            // Prepare output directory
            Directory.CreateDirectory(Path.GetDirectoryName(outputPath) ?? ".");

            // Build output HTML
            using (var stream = File.Create(outputPath))
            using (var writer = new StreamWriter(stream))
            {
                await writer.WriteLineAsync("<html><body>");
                foreach (var group in groups)
                {
                    await writer.WriteLineAsync($"<h2>{group.Heading}</h2>");
                    foreach (var kv in group.Contents)
                    {
                        await writer.WriteLineAsync($"<p>File: {kv.Key}</p>");
                        await writer.WriteLineAsync(kv.Value);
                    }
                    await writer.WriteLineAsync("<hr/>");
                }
                await writer.WriteLineAsync("</body></html>");
                await writer.FlushAsync().ConfigureAwait(false);
            }
        }

        private static List<SectionInfo> ExtractSections(HtmlDocument doc)
        {
            var sections = new List<SectionInfo>();
            var headingNodes = doc.DocumentNode.SelectNodes("//b[@class='custom-bold-heading']");
            if (headingNodes == null) return sections;

            foreach (var b in headingNodes)
            {
                var heading = b.InnerText.Trim();
                var div = b.Ancestors("div").FirstOrDefault();
                if (div != null)
                {
                    sections.Add(new SectionInfo
                    {
                        Heading = heading,
                        HtmlContent = div.OuterHtml
                    });
                }
            }
            return sections;
        }

        private static List<SectionGroup1> GroupSections(Dictionary<string, List<SectionInfo>> sectionsByFile)
        {
            var groups = new List<SectionGroup1>();

            foreach (var file in sectionsByFile.Keys)
            {
                foreach (var section in sectionsByFile[file])
                {
                    var matched = false;
                    foreach (var grp in groups)
                    {
                        var dist = LevenshteinDistance(section.Heading, grp.Heading);
                        var ratio = 1.0 - (double)dist / Math.Max(section.Heading.Length, grp.Heading.Length);
                        if (ratio >= SimilarityThreshold)
                        {
                            grp.Contents[file] = section.HtmlContent;
                            matched = true;
                            break;
                        }
                    }
                    if (!matched)
                    {
                        var newGroup = new SectionGroup1
                        {
                            Heading = section.Heading,
                            Contents = new Dictionary<string, string>
                            {
                                [file] = section.HtmlContent
                            }
                        };
                        groups.Add(newGroup);
                    }
                }
            }

            return groups;
        }

        private static int LevenshteinDistance(string s, string t)
        {
            if (string.IsNullOrEmpty(s)) return t.Length;
            if (string.IsNullOrEmpty(t)) return s.Length;

            var d = new int[s.Length + 1, t.Length + 1];
            for (int i = 0; i <= s.Length; i++) d[i, 0] = i;
            for (int j = 0; j <= t.Length; j++) d[0, j] = j;

            for (int i = 1; i <= s.Length; i++)
            {
                for (int j = 1; j <= t.Length; j++)
                {
                    var cost = s[i - 1] == t[j - 1] ? 0 : 1;
                    d[i, j] = Math.Min(
                        Math.Min(d[i - 1, j] + 1, d[i, j - 1] + 1),
                        d[i - 1, j - 1] + cost);
                }
            }
            return d[s.Length, t.Length];
        }
    }

    internal class SectionInfo
    {
        public string Heading { get; set; } = string.Empty;
        public string HtmlContent { get; set; } = string.Empty;
    }

    internal class SectionGroup1
    {
        public string Heading { get; set; } = string.Empty;
        public Dictionary<string, string> Contents { get; set; } = new Dictionary<string, string>();
    }
}
