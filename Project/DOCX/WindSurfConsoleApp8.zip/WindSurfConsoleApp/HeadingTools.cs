using System;
using System.Linq;
using System.Text.RegularExpressions;

namespace WindSurfConsoleApp
{
    internal static class HeadingTools
    {
        private static readonly Regex NumPrefix =
            new(@"^(?<num>(?:\d+\.)*\d+)\s*(?<txt>.*)", RegexOptions.Compiled);

        public static (string Key, int[] Numbers) CanonicalKey(string heading)
        {
            var m = NumPrefix.Match(heading);
            string txt = m.Success ? m.Groups["txt"].Value : heading;
            string num = m.Success ? m.Groups["num"].Value : "";
            string key = TextTools.Canonical(txt);
            int[] nums = num.Length == 0 ? Array.Empty<int>()
                                         : num.Split('.', StringSplitOptions.RemoveEmptyEntries)
                                              .Select(int.Parse).ToArray();
            return (key, nums);
        }

        // Numeric arrays compatible when:
        // 1) identical OR
        // 2) one is a suffix of the other (missing one or more leading numbers)
        public static bool NumericCompatible(int[] a, int[] b)
        {
            if (a.SequenceEqual(b)) return true;
            if (a.Length > b.Length && a[^b.Length..].SequenceEqual(b)) return true; // b is suffix of a
            if (b.Length > a.Length && b[^a.Length..].SequenceEqual(a)) return true; // a is suffix of b
            return false;
        }
    }
} 