using System;
using HtmlAgilityPack;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Threading.Tasks;

public static class ExtractTrackedDivs
{
    public static async Task ExtractTrackedChangeSectionsBetweenHeadingsAsync(
        string inputPath,
        string outputPath)
    {
        var doc = new HtmlDocument();
        using (var stream = File.OpenRead(inputPath))
        {
            doc.Load(stream);
        }

        var body = doc.DocumentNode.SelectSingleNode("//body");
        if (body == null)
        {
            Console.WriteLine("No <body> element found.");
            return;
        }

        // Collect all direct children of <body>
        var children = body.ChildNodes.Where(n => n.NodeType == HtmlNodeType.Element).ToList();
        var sections = new List<List<HtmlNode>>();
        List<HtmlNode> currentSection = null;

        foreach (var node in children)
        {
            bool isHeadingBlock = false;
            if (node.Name == "ol")
            {
                var hr = node.SelectSingleNode(".//li/hr");
                var bold = node.SelectSingleNode(".//li/b[@class='custom-bold-heading']");
                if (hr != null && bold != null)
                    isHeadingBlock = true;
            }
            else if (node.Name == "hr" && node.NextSibling != null && node.NextSibling.Name == "b")
            {
                // Also consider <hr><b class='custom-bold-heading'> as a heading block
                var bold = node.NextSibling;
                if (bold.GetAttributeValue("class","") == "custom-bold-heading")
                    isHeadingBlock = true;
            }

            if (isHeadingBlock)
            {
                if (currentSection != null && currentSection.Count > 0)
                    sections.Add(currentSection);
                currentSection = new List<HtmlNode>();
            }
            if (currentSection == null)
                currentSection = new List<HtmlNode>();
            currentSection.Add(node);
        }
        if (currentSection != null && currentSection.Count > 0)
            sections.Add(currentSection);

        // Build output doc that contains only sections with tracked changes
        var outDoc = new HtmlDocument();
        outDoc.LoadHtml("<html><head></head><body></body></html>");

        var outBody = outDoc.DocumentNode.SelectSingleNode("//body");

        foreach (var slice in sections)
        {
            bool hasTracked =
                slice.Any(n => n.SelectSingleNode(".//*[self::ins or self::del]") != null);

            if (!hasTracked) continue;

            // Wrap this slice in a fresh <div>
            var wrapper = outDoc.CreateElement("div");
            wrapper.SetAttributeValue("class", "custom-section");
            var sb = new System.Text.StringBuilder();

            foreach (var n in slice)
                sb.Append(n.OuterHtml);

            wrapper.InnerHtml = sb.ToString();
            outBody.AppendChild(wrapper);
        }

        using (var stream = File.Create(outputPath))
        {
            outDoc.Save(stream);
            await stream.FlushAsync().ConfigureAwait(false);
        }
        Console.WriteLine($"Extracted sections written to: {outputPath}");
    }
}