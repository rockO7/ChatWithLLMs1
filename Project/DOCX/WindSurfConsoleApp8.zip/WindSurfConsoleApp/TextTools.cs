using System;
using System.Linq;
using System.Text.RegularExpressions;
using System.Collections.Generic;

namespace WindSurfConsoleApp
{
    internal static class TextTools
    {
        private static readonly Regex DotSpace = new(@"^((?:\d+\.)+\d+)\s+", RegexOptions.Compiled);
        private static readonly Regex Punct    = new(@"[\p{P}\p{S}]+", RegexOptions.Compiled);
        private static readonly Regex White    = new(@"\s+", RegexOptions.Compiled);

        private static readonly HashSet<string> Stop =
            new(StringComparer.OrdinalIgnoreCase)
            { "a","an","and","the","of","in","on","for","to","with","by","is","are","be","this","that" };

        public static string Canonical(string txt)
        {
            txt = System.Net.WebUtility.HtmlDecode(txt);
            txt = DotSpace.Replace(txt, "$1");                // kill space after numeric prefix
            txt = txt.ToLowerInvariant();
            txt = Punct.Replace(txt, " ");
            txt = White.Replace(txt, " ").Trim();
            return string.Join(' ', txt.Split(' ').Where(w => !Stop.Contains(w)));
        }
    }
} 