// ======================================================================
// File : FusionWeaver.cs
// (c) 2024 – feel free to change the namespace / banner.
// ======================================================================

using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Collections.Concurrent;
using WindSurfConsoleApp;

namespace WindSurfConsoleApp   //  <<<— change to whatever you like
{
    // ──────────────────────────────────────────────────────────────
    //  PUBLIC FAÇADE
    // ──────────────────────────────────────────────────────────────
    public sealed class DocumentMerger
    {
        private readonly MergeOptions _opt;
        public DocumentMerger(MergeOptions? opt = null) => _opt = opt ?? MergeOptions.Default;

        public async Task MergeAsync(IEnumerable<(string Path, string Name)> sources,
                                     string outputFile,
                                     CancellationToken ct = default)
        {
            var sw = Stopwatch.StartNew();
            _opt.Log("⏳ Parsing …");

            // -------------------------------------------------- 1) Parse
            var all = new ConcurrentBag<DocSection>();
            await Parallel.ForEachAsync(sources, _opt.Parallel, async (src, token) =>
            {
                foreach (var s in await SectionExtractor.ExtractAsync(src.Path, src.Name, token))
                    all.Add(s);
            });

            if (all.IsEmpty) throw new InvalidOperationException("No custom sections found.");
            int docsTotal = all.Select(s => s.DocumentName).Distinct().Count();
            _opt.Log($"✔ Parsed {all.Count} sections from {docsTotal} documents.");

            // -------------------------------------------------- 2) Coarse bucket (SimHash on heading‑text key)
            var buckets = all.GroupBy(s => SimHash.Of(s.HeadingKey) >> _opt.SimHashBits)
                             .Select(g => g.ToList()).ToList();
            _opt.Log($"✔ SimHash → {buckets.Count} buckets");

            // -------------------------------------------------- 3) Fine cluster inside bucket
            var groups = new List<SectionGroup>();
            foreach (var bucket in buckets)
                groups.AddRange(Clusterer.Cluster(bucket, _opt));

            _opt.Log($"✔ Fine clustering → {groups.Count} groups");

            // -------------------------------------------------- 4) Repair pass – merge groups still missing docs
            groups = RepairPass(groups, _opt, docsTotal).ToList();
            _opt.Log($"✔ Repair pass     → {groups.Count} groups after merge");

            // -------------------------------------------------- 5) Duplicate‑document guard
            foreach (var g in groups)
            {
                // Instead of throwing on duplicate, rename duplicates with (copy), (copy 2), etc.
                var seen = new HashSet<string>();
                foreach (var entry in g.Entries.ToList())
                {
                    string key = entry.DocumentName + "::" + entry.Heading;
                    int copyIndex = 1;
                    string newHeading = entry.Heading;
                    while (!seen.Add(key))
                    {
                        copyIndex++;
                        newHeading = entry.Heading + $" (copy{(copyIndex > 2 ? " " + copyIndex.ToString() : "")})";
                        key = entry.DocumentName + "::" + newHeading;
                    }
                    if (newHeading != entry.Heading)
                    {
                        // Update heading in-place
                        entry.Heading = newHeading;
                        // Also update HTML <b class='custom-bold-heading'> if present
                        if (!string.IsNullOrEmpty(entry.Html))
                        {
                            entry.Html = System.Text.RegularExpressions.Regex.Replace(
                                entry.Html,
                                "(<b[^>]*class=['\"]custom-bold-heading['\"][^>]*>)(.*?)(</b>)",
                                m => m.Groups[1].Value + newHeading + m.Groups[3].Value,
                                System.Text.RegularExpressions.RegexOptions.IgnoreCase
                            );
                        }
                    }
                }
            }

            // -------------------------------------------------- 6) Write HTML
            await HtmlWriter.WriteAsync(groups, outputFile, ct);
            _opt.Log($"🏁 Finished in {sw.ElapsedMilliseconds} ms  →  {outputFile}");
        }

        // ----- merge groups that still miss one or more documents -----------------
        private static IEnumerable<SectionGroup> RepairPass(List<SectionGroup> input,
                                                            MergeOptions opt,
                                                            int docsTotal)
        {
            var work = input;          // mutate in place
            bool changed;
            do
            {
                changed = false;
                for (int i = 0; i < work.Count; i++)
                {
                    var gA = work[i];
                    if (gA.Entries.Select(e => e.DocumentName).Distinct().Count() == docsTotal)
                        continue; // group already complete

                    for (int j = i + 1; j < work.Count; j++)
                    {
                        var gB = work[j];

                        // skip if numeric arrays incompatible
                        if (!HeadingTools.NumericCompatible(gA.Entries[0].HeadingNums,
                                                             gB.Entries[0].HeadingNums))
                            continue;

                        double hSim = SimilarityHelpers.Composite(gA.Entries[0], gB.Entries[0], opt);
                        double bestContent = 0;
                        foreach (var a in gA.Entries)
                            foreach (var b in gB.Entries)
                                bestContent = Math.Max(bestContent, SimilarityHelpers.ContentSim(a, b));

                        if (hSim >= 0.85 && bestContent >= 0.80)
                        {
                            // merge but keep max‑one section per doc
                            foreach (var sec in gB.Entries)
                                if (!gA.Entries.Any(x => x.DocumentName == sec.DocumentName))
                                    gA.Entries.Add(sec);
                            work.RemoveAt(j);
                            j--;
                            changed = true;
                        }
                    }
                }
            } while (changed);

            return work;
        }
    }

    // ──────────────────────────────────────────────────────────────
    //  CONFIGURATION
    // ──────────────────────────────────────────────────────────────
    public sealed record MergeOptions
    {
        public IReadOnlyList<IStringSimilarity> Similarities { get; init; } =
            new IStringSimilarity[]
            {
                new Levenshtein(),
                new JaroWinkler(),
                new JaccardTokens()     // token‑set similarity
            };

        public Func<IEnumerable<double>, double> ThresholdSelector { get; init; } =
            SimilarityHelpers.AdaptiveThreshold;

        public int SimHashBits { get; init; } = 48;

        public ParallelOptions Parallel { get; init; } =
            new() { MaxDegreeOfParallelism = Environment.ProcessorCount };

        public Action<string> Log { get; init; } =
            msg => Console.WriteLine($"[{DateTime.Now:HH:mm:ss}] {msg}");

        public static MergeOptions Default => new();
    }

    // ──────────────────────────────────────────────────────────────
    //  DATA CLASSES
    // ──────────────────────────────────────────────────────────────
    public sealed class DocSection
    {
        public string DocumentName  { get; set; } = "";
        public string Heading       { get; set; } = "";
        public string HeadingKey    { get; set; } = "";
        public int[]  HeadingNums   { get; set; } = Array.Empty<int>();
        public string Html          { get; set; } = "";
        public string Text          { get; set; } = "";
    }
    public sealed class SectionGroup
    {
        public string CanonicalHeading { get; set; } = "";
        public List<DocSection> Entries { get; } = new();
    }
}