using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using HtmlAgilityPack;

namespace WindSurfConsoleApp
{
    public static class MergedDocumentCleaner
    {
        public static async Task CleanAsync(string mergedHtmlPath)
        {
            var doc = new HtmlDocument();
            doc.Load(mergedHtmlPath);
            var detailsNodes = doc.DocumentNode.SelectNodes("//details");
            if (detailsNodes == null) return;
            foreach (var details in detailsNodes.ToList())
            {
                int insLen = details.SelectNodes(".//ins")?.Sum(n => n.InnerText.Length) ?? 0;
                int delLen = details.SelectNodes(".//del")?.Sum(n => n.InnerText.Length) ?? 0;
                if (insLen + delLen < 5)
                {
                    details.Remove();
                    continue;
                }
                // Heading check: summary is the heading for this details
                var summary = details.SelectSingleNode("./summary");
                if (summary != null)
                {
                    string heading = summary.InnerText;
                    string headingNoPunct = new string(heading.Where(c => !char.IsPunctuation(c)).ToArray());
                    int diff = Math.Abs(heading.Length - headingNoPunct.Length);
                    if (diff < 3)
                    {
                        details.Remove();
                        continue;
                    }
                }
            }
            doc.Save(mergedHtmlPath);
        }
    }
}
