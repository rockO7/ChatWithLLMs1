/*
DETAILED WORKFLOW EXPLANATION FOR THIS PROGRAM
-------------------------------------------------
This C# program processes HTML files to extract and highlight tracked changes, bold headings, and clean up Table of Contents (TOC) sections. Here is a step-by-step explanation of what each major operation does, why it is called, what input it expects, and what output it produces.

1. HtmlFileCleaner.CleanAllHtmlFilesAsync()
   - What: Cleans all HTML files in the 'HtmlFiles' directory and writes cleaned versions to 'HtmlFiles/Cleaned'.
   - Why: Removes unnecessary tags (like <style>), header/footer divs, and applies consistent styles to tracked changes and tables. Prepares files for further processing.
   - Input: All .html files in 'HtmlFiles' directory.
   - Output: Cleaned .html files in 'HtmlFiles/Cleaned'.

2. HeadingBolder.BoldHeadingsForTocAnchorsAsync(cleanedInputPath)
   - What: Bolds headings in the HTML that correspond to TOC anchors (e.g., <a name="_Toc..."></a>).
   - Why: Visually highlights headings that are referenced in the Table of Contents, making navigation easier.
   - Input: Cleaned HTML file path (e.g., 'HtmlFiles/Cleaned/CTC.html').
   - Output: The same file, but with relevant headings wrapped in <b class="custom-bold-heading"> tags.

3. ExtractTrackedSections.ExtractTrackedChangeDivsFromCleanedFile(cleanedInputPath, trackedOutputPath)
   - What: Extracts <div> blocks from the cleaned HTML that are either TOC candidates or contain tracked changes (<ins> or <del> tags).
   - Why: Isolates only the sections of the document that have tracked changes or are part of the TOC for further analysis.
   - Input: Cleaned HTML file and output path for tracked changes only file.
   - Output: New HTML file with only the relevant <div> blocks.

4. ExtractTrackedSections.ExtractTrackedChangeSectionsFromCleanedFileAsync(cleanedInputPath, trackedOutputPath)
   - What: Extracts all <div> sections from the cleaned HTML that contain tracked changes.
   - Why: Focuses only on content that has been edited (tracked changes), ignoring unchanged content.
   - Input: Cleaned HTML file and output path for tracked changes only file.
   - Output: New HTML file with only tracked changes sections.

5. ExtractTrackedDivs.ExtractTrackedChangeSectionsBetweenHeadingsAsync(trackedOutputPath, outputPath)
   - What: Further splits the tracked changes file into sections that are grouped between headings (typically <b> tags with class 'custom-bold-heading').
   - Why: Organizes tracked changes by logical document sections for easier review and comparison.
   - Input: Tracked changes only HTML file and output path for the sectioned file.
   - Output: New HTML file with tracked changes grouped by headings.

6. TOCPruner.PruneTocInTrackedFileAsync(outputPath)
   - What: Cleans up the Table of Contents in the tracked changes file by removing empty or irrelevant TOC sections.
   - Why: Ensures the final output is clean, with only meaningful TOC entries, and no empty or broken links.
   - Input: The sectioned tracked changes HTML file.
   - Output: The same file, but with pruned TOC sections.

Helper: RemoveDivTagsFromFileAsync(filePath)
   - What: Removes all <div> and </div> tags from a file.
   - Why: Used (if called) to flatten the document structure for final output or compatibility.
   - Input: Path to any HTML file.
   - Output: The same file, but with all <div> tags removed.

OVERALL PIPELINE:
1. Clean all HTMLs (removes noise, applies styles).
2. Bold TOC headings for clarity.
3. Extract only tracked/TOC <div>s for focused review.
4. Extract only tracked change sections for change analysis.
5. Split content between headings for section-based diffing.
6. Prune TOC for a clean, navigable output.

This workflow ensures that the final HTML outputs are clean, well-organized, and focused on tracked changes, with clear navigation and minimal clutter.
*/

using System;
using System.IO;
using WindSurfConsoleApp;

class Program
{
    static async Task Main(string[] args)
    {
   //      try
   //      {
   //         Console.WriteLine("Started");
   //         var cleaner = new HtmlFileCleaner();
   //         await cleaner.CleanAllHtmlFilesAsync();
   //      }
   //      catch (Exception exCleaner)
   //      {
   //         Console.WriteLine("Failed");

   //         Console.WriteLine($"*** FATAL ERROR during CleanAllHtmlFilesAsync section: {exCleaner.ToString()} ***");
   //         return;
   //      }

   //      string cleanedInputPath = "HtmlFiles/Cleaned/CTC.html";
   //      string cleanedInputPath1 = "HtmlFiles/Cleaned/CLTIC.html";
   //      string cleanedInputPath2 = "HtmlFiles/Cleaned/TTC.html";
   //      string cleanedInputPath3 = "HtmlFiles/Cleaned/CTIC.html";
   //      string cleanedInputPath4 = "HtmlFiles/Cleaned/FNTC.html";
   //      string cleanedInputPath5 = "HtmlFiles/Cleaned/FNTCCA.html";
   //      string cleanedInputPath6 = "HtmlFiles/Cleaned/FNTIC.html";
   //      string cleanedInputPath7 = "HtmlFiles/Cleaned/CLTC.html";


   //      string trackedOutputPath = "HtmlFiles/Cleaned/CTC_TrackedChangesOnly1.html";
   //      string trackedOutputPath1 = "HtmlFiles/Cleaned/CLTIC_TrackedChangesOnly1.html";
   //      string trackedOutputPath2 = "HtmlFiles/Cleaned/TTC_TrackedChangesOnly1.html";
   //      string trackedOutputPath3 = "HtmlFiles/Cleaned/CTIC_TrackedChangesOnly1.html";
   //      string trackedOutputPath4 = "HtmlFiles/Cleaned/FNTC_TrackedChangesOnly1.html";
   //      string trackedOutputPath5 = "HtmlFiles/Cleaned/FNTCCA_TrackedChangesOnly1.html";
   //      string trackedOutputPath6 = "HtmlFiles/Cleaned/FNTIC_TrackedChangesOnly1.html";
   //      string trackedOutputPath7 = "HtmlFiles/Cleaned/CLTC_TrackedChangesOnly1.html";
        

   //      string outputPath = "HtmlFiles/Cleaned/CTC_TrackedChangesOnly_BetweenHeadings1.html";
   //      string outputPath1 = "HtmlFiles/Cleaned/CLTIC_TrackedChangesOnly_BetweenHeadings1.html";
   //      string outputPath2 = "HtmlFiles/Cleaned/TTC_TrackedChangesOnly_BetweenHeadings1.html";
   //      string outputPath3 = "HtmlFiles/Cleaned/CTIC_TrackedChangesOnly_BetweenHeadings1.html";
   //      string outputPath4 = "HtmlFiles/Cleaned/FNTC_TrackedChangesOnly_BetweenHeadings1.html";
   //      string outputPath5 = "HtmlFiles/Cleaned/FNTCCA_TrackedChangesOnly_BetweenHeadings1.html";
   //      string outputPath6 = "HtmlFiles/Cleaned/FNTIC_TrackedChangesOnly_BetweenHeadings1.html";
   //      string outputPath7 = "HtmlFiles/Cleaned/CLTC_TrackedChangesOnly_BetweenHeadings1.html";
        
   //      string mergedOutputPath = "HtmlFiles/Merged/MergedDocument.html";



   //      await RemoveDivTagsFromFileAsync(cleanedInputPath1).ConfigureAwait(false);
   //      await RemoveDivTagsFromFileAsync(cleanedInputPath).ConfigureAwait(false);
   //      await RemoveDivTagsFromFileAsync(cleanedInputPath2).ConfigureAwait(false);
   //      await RemoveDivTagsFromFileAsync(cleanedInputPath3).ConfigureAwait(false);
   //      await RemoveDivTagsFromFileAsync(cleanedInputPath4).ConfigureAwait(false);
   //      await RemoveDivTagsFromFileAsync(cleanedInputPath5).ConfigureAwait(false);
   //      await RemoveDivTagsFromFileAsync(cleanedInputPath6).ConfigureAwait(false);
   //      await RemoveDivTagsFromFileAsync(cleanedInputPath7).ConfigureAwait(false);

   //      await HeadingBolder.BoldHeadingsForTocAnchorsAsync(cleanedInputPath1, trackedOutputPath1);
   //      await HeadingBolder.BoldHeadingsForTocAnchorsAsync(cleanedInputPath, trackedOutputPath);
   //      await HeadingBolder.BoldHeadingsForTocAnchorsAsync(cleanedInputPath2, trackedOutputPath2);
   //      await HeadingBolder.BoldHeadingsForTocAnchorsAsync(cleanedInputPath3, trackedOutputPath3);
   //      await HeadingBolder.BoldHeadingsForTocAnchorsAsync(cleanedInputPath4, trackedOutputPath4);
   //      await HeadingBolder.BoldHeadingsForTocAnchorsAsync(cleanedInputPath5, trackedOutputPath5);
   //      await HeadingBolder.BoldHeadingsForTocAnchorsAsync(cleanedInputPath6, trackedOutputPath6);
   //      await HeadingBolder.BoldHeadingsForTocAnchorsAsync(cleanedInputPath7, trackedOutputPath7);

   //      await TocContentFilter.FilterTocLinksOnlyAsync(trackedOutputPath1);
   //      await TocContentFilter.FilterTocLinksOnlyAsync(trackedOutputPath);
   //      await TocContentFilter.FilterTocLinksOnlyAsync(trackedOutputPath2);
   //      await TocContentFilter.FilterTocLinksOnlyAsync(trackedOutputPath3);
   //      await TocContentFilter.FilterTocLinksOnlyAsync(trackedOutputPath4);
   //      await TocContentFilter.FilterTocLinksOnlyAsync(trackedOutputPath5);
   //      await TocContentFilter.FilterTocLinksOnlyAsync(trackedOutputPath6);
   //      await TocContentFilter.FilterTocLinksOnlyAsync(trackedOutputPath7);
         

   //      await ExtractTrackedSections.ExtractTrackedChangeSectionsFromCleanedFileAsync(trackedOutputPath1, outputPath1);
   //      await ExtractTrackedSections.ExtractTrackedChangeSectionsFromCleanedFileAsync(trackedOutputPath, outputPath);
   //      await ExtractTrackedSections.ExtractTrackedChangeSectionsFromCleanedFileAsync(trackedOutputPath2, outputPath2);
   //      await ExtractTrackedSections.ExtractTrackedChangeSectionsFromCleanedFileAsync(trackedOutputPath3, outputPath3);
   //      await ExtractTrackedSections.ExtractTrackedChangeSectionsFromCleanedFileAsync(trackedOutputPath4, outputPath4);
   //      await ExtractTrackedSections.ExtractTrackedChangeSectionsFromCleanedFileAsync(trackedOutputPath5, outputPath5);
   //      await ExtractTrackedSections.ExtractTrackedChangeSectionsFromCleanedFileAsync(trackedOutputPath6, outputPath6); 
   //      await ExtractTrackedSections.ExtractTrackedChangeSectionsFromCleanedFileAsync(trackedOutputPath7, outputPath7);


   //      await TOCPruner.PruneTocInTrackedFileAsync(outputPath1);
   //      await TOCPruner.PruneTocInTrackedFileAsync(outputPath);
   //      await TOCPruner.PruneTocInTrackedFileAsync(outputPath2);
   //      await TOCPruner.PruneTocInTrackedFileAsync(outputPath3);
   //      await TOCPruner.PruneTocInTrackedFileAsync(outputPath4);
   //      await TOCPruner.PruneTocInTrackedFileAsync(outputPath5);
   //      await TOCPruner.PruneTocInTrackedFileAsync(outputPath6);
   //      await TOCPruner.PruneTocInTrackedFileAsync(outputPath7);



        try
        {
            Console.WriteLine("Started Merging!");

            var sources = new[]
            {
                (Path: "HtmlFiles/Cleaned/CTC_TrackedChangesOnly_BetweenHeadings1.html", Name: "CTC"),
                (Path: "HtmlFiles/Cleaned/CLTIC_TrackedChangesOnly_BetweenHeadings1.html", Name: "CLTIC"),
                (Path: "HtmlFiles/Cleaned/TTC_TrackedChangesOnly_BetweenHeadings1.html", Name: "TTC"),
                (Path: "HtmlFiles/Cleaned/CTIC_TrackedChangesOnly_BetweenHeadings1.html", Name: "CTIC"),
                (Path: "HtmlFiles/Cleaned/FNTC_TrackedChangesOnly_BetweenHeadings1.html", Name: "FNTC"),
                (Path: "HtmlFiles/Cleaned/FNTCCA_TrackedChangesOnly_BetweenHeadings1.html", Name: "FNTCCA"),
                (Path: "HtmlFiles/Cleaned/FNTIC_TrackedChangesOnly_BetweenHeadings1.html", Name: "FNTIC"),
                (Path: "HtmlFiles/Cleaned/CLTC_TrackedChangesOnly_BetweenHeadings1.html", Name: "CLTC")
            };

            var merger = new DocumentMerger();  // or new DocumentMerger(customOptions)
            await merger.MergeAsync(sources, "HtmlFiles/Merged/MergedDocument.html");


            Console.WriteLine("Document merge completed successfully!");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"*** ERROR during document merge: {ex} ***");
        }
    }

    static async Task RemoveDivTagsFromFileAsync(string filePath)
    {
        try
        {
            if (!File.Exists(filePath))
            {
                return; 
            }
            string content = await File.ReadAllTextAsync(filePath);
            content = content.Replace("<div>", string.Empty).Replace("</div>", string.Empty);
            await File.WriteAllTextAsync(filePath, content);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"*** ERROR in RemoveDivTagsFromFileAsync for {filePath}: {ex.Message}"); 
        }
    }
}
