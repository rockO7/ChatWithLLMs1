using System;
using System.Collections.Generic;
using System.Text;

namespace WindSurfConsoleApp
{
    internal static class SimHash
    {
        public static ulong Of(string text)
        {
            var vec = new int[64];
            var bytes = Encoding.UTF8.GetBytes(text);
            foreach (var h in Murmur(bytes))
                for (int i = 0; i < 64; i++)
                    vec[i] += ((h >> i) & 1) == 1 ? 1 : -1;

            ulong sig = 0;
            for (int i = 0; i < 64; i++)
                if (vec[i] > 0) sig |= 1UL << i;
            return sig;
        }

        private static IEnumerable<ulong> Murmur(byte[] data)
        {
            const ulong c1 = 0x87c37b91114253d5, c2 = 0x4cf5ad432745937f;
            ulong h1 = 0, h2 = 0, len = (ulong)data.Length;
            for (int i = 0; i < data.Length / 16; i++)
            {
                ulong k1 = BitConverter.ToUInt64(data, i * 16);
                ulong k2 = BitConverter.ToUInt64(data, i * 16 + 8);
                k1 *= c1; k1 = Rotl(k1, 23); k1 *= c2; h1 ^= k1; h1 += h2; h1 = h1 * 5 + 0x52dce729;
                k2 *= c2; k2 = Rotl(k2, 23); k2 *= c1; h2 ^= k2; h2 += h1; h2 = h2 * 5 + 0x38495ab5;
            }
            h1 ^= len; h2 ^= len; h1 += h2; h2 += h1; yield return h1; yield return h2;
        }
        private static ulong Rotl(ulong x, byte r) => (x << r) | (x >> (64 - r));
    }
} 