using System;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;
using AngleSharp;
using AngleSharp.Dom;

namespace WindSurfConsoleApp
{
    internal static class SectionExtractor
    {
        private static readonly Regex White     = new(@"\s+", RegexOptions.Compiled);
        private static readonly Regex FirstLine = new(@"^([^\r\n:]+)", RegexOptions.Compiled);

        public static async Task<IReadOnlyList<DocSection>> ExtractAsync(string file,
                                                                         string docName,
                                                                         CancellationToken ct)
        {
            var html = await File.ReadAllTextAsync(file, ct);
            var dom  = await BrowsingContext.New(Configuration.Default)
                                            .OpenAsync(req => req.Content(html), ct);

            var list = new List<DocSection>();
            var nodes = dom.QuerySelectorAll("div.custom-section")
                           .Where(x => !x.QuerySelectorAll(".TableofContents").Any());

            foreach (var node in nodes)
            {
                var bold = node.QuerySelector("b.custom-bold-heading") ?? node.QuerySelector("b");
                if (bold is null) continue;

                foreach (var del in bold.QuerySelectorAll("del").ToArray()) del.Remove();

                // extract heading text from nested <a><span> if present, else use bold text
                var span = bold.QuerySelector("a span");
                string rawHeading = span != null ? span.TextContent.Trim()
                                                 : White.Replace(bold.TextContent, " ").Trim();
                if (string.IsNullOrWhiteSpace(rawHeading)) continue;
                var m = FirstLine.Match(rawHeading);
                string heading = m.Success ? m.Groups[1].Value.Trim() : rawHeading;

                var (key, nums) = HeadingTools.CanonicalKey(heading);

                list.Add(new DocSection
                {
                    DocumentName  = docName,
                    Heading       = heading,
                    HeadingKey    = key,
                    HeadingNums   = nums,
                    Html          = node.OuterHtml,
                    Text          = TextTools.Canonical(node.TextContent)
                });
            }
            return list;
        }
    }
} 