using System;
using System.Collections.Generic;
using System.Linq;

namespace WindSurfConsoleApp
{
    internal static class Clusterer
    {
        public static IEnumerable<SectionGroup> Cluster(List<DocSection> bucket, MergeOptions opt)
        {
            if (bucket.Count == 1)
                return new[] { new SectionGroup { CanonicalHeading = bucket[0].Heading,
                                                  Entries = { bucket[0] } } };

            int n = bucket.Count;
            var uf = new UnionFind(n);

            // 1) Pre‑union when numeric arrays are compatible AND heading‑key identical
            for (int i = 0; i < n; i++)
            {
                for (int j = i + 1; j < n; j++)
                {
                    if (uf.Find(i) == uf.Find(j)) continue;
                    if (bucket[i].HeadingKey != bucket[j].HeadingKey) continue;
                    if (!HeadingTools.NumericCompatible(bucket[i].HeadingNums, bucket[j].HeadingNums))
                        continue;
                    uf.Union(i, j);
                }
            }

            // 2) Similarity‑based union (only for numeric‑compatible pairs)
            var sims = new List<(int i, int j, double s)>();
            for (int i = 0; i < n; i++)
                for (int j = i + 1; j < n; j++)
                    if (uf.Find(i) != uf.Find(j) &&
                        HeadingTools.NumericCompatible(bucket[i].HeadingNums, bucket[j].HeadingNums))
                    {
                        double s = SimilarityHelpers.Composite(bucket[i], bucket[j], opt);
                        sims.Add((i, j, s));
                    }

            double th = opt.ThresholdSelector(sims.Select(x => x.s));
            foreach (var (i, j, s) in sims)
                if (s >= th) uf.Union(i, j);

            // 3) Materialise groups
            var map = new Dictionary<int, SectionGroup>();
            for (int i = 0; i < n; i++)
            {
                int root = uf.Find(i);
                if (!map.TryGetValue(root, out var g))
                    map[root] = g = new SectionGroup { CanonicalHeading = bucket[i].Heading };
                g.Entries.Add(bucket[i]);
            }
            return map.Values;
        }

        internal sealed class UnionFind
        {
            private readonly int[] _p;
            public UnionFind(int n) => _p = Enumerable.Range(0, n).ToArray();
            public int Find(int x) => _p[x] == x ? x : _p[x] = Find(_p[x]);
            public void Union(int a, int b)
            {
                int ra = Find(a), rb = Find(b);
                if (ra != rb) _p[ra] = rb;
            }
        }
    }
} 