using System;
using System.IO;
using HtmlAgilityPack;
using System.Linq;
using System.Text.RegularExpressions; // For counting occurrences
using System.Collections.Generic;

public static class TOCPruner
{
    public static async Task PruneTocInTrackedFileAsync(string trackedFilePath)
    {
        var doc = new HtmlDocument();
        try
        {
            using (var stream = File.OpenRead(trackedFilePath))
            {
                doc.Load(stream);
            }
        }
        catch (FileNotFoundException)
        {
            Console.WriteLine($"Warning: Tracked changes file not found, skipping TOC pruning: {trackedFilePath}");
            return;
        }
        catch (Exception ex)
        {
             Console.WriteLine($"Error loading tracked changes file '{trackedFilePath}': {ex.Message}");
             return;
        }

        // First, find all heading nodes with the custom bold class
        var headingNodes = doc.DocumentNode.SelectNodes("//b[@class='custom-bold-heading']")?.ToList() ?? new List<HtmlNode>();
        var headingAnchors = new HashSet<string>();
        
        // Collect all the anchor IDs from the headings
        foreach (var heading in headingNodes)
        {
            // Check if this heading has an anchor
            var anchor = heading.SelectSingleNode(".//a[@name]");
            if (anchor != null)
            {
                string nameAttr = anchor.GetAttributeValue("name", "");
                if (!string.IsNullOrEmpty(nameAttr))
                {
                    headingAnchors.Add(nameAttr);
                }
            }
        }
        
        // If we didn't find any heading anchors, try searching for all name attributes
        if (headingAnchors.Count == 0)
        {
            var allAnchors = doc.DocumentNode.SelectNodes("//a[@name]");
            if (allAnchors != null)
            {
                foreach (var anchor in allAnchors)
                {
                    string nameAttr = anchor.GetAttributeValue("name", "");
                    if (!string.IsNullOrEmpty(nameAttr))
                    {
                        headingAnchors.Add(nameAttr);
                    }
                }
            }
        }

        // Check first 4 divs for potential TOCs
        var potentialTocDivs = doc.DocumentNode.SelectNodes("//body/div")
                                ?.Take(4).ToList() ?? new List<HtmlNode>();

        bool modified = false;
        foreach(var div in potentialTocDivs)
        {
            // Heuristic: Does this div contain multiple href anchors?
            var tocLinks = div.SelectNodes(".//a[@href]");
            if (tocLinks == null || tocLinks.Count <= 2) continue; // Skip if not likely a TOC

            var paragraphsToRemove = new List<HtmlNode>();
            var ps = div.SelectNodes(".//p[.//a[@href]]")?.ToList() ?? new List<HtmlNode>();

            foreach (var p in ps)
            {
                var a = p.SelectSingleNode(".//a[@href]");
                if (a != null)
                {
                    var href = a.GetAttributeValue("href", "");
                    if (href.StartsWith("#"))
                    {
                        var id = href.Substring(1);
                        if (!string.IsNullOrEmpty(id))
                        {
                            // Check if the ID exists in our heading anchors
                            if (!headingAnchors.Contains(id))
                            {
                                paragraphsToRemove.Add(p);
                                modified = true;
                            }
                        }
                        else
                        {
                            paragraphsToRemove.Add(p); // Remove if ID is empty
                            modified = true;
                        }
                    }
                    else
                    {
                        paragraphsToRemove.Add(p); // Remove if href doesn't start with #
                        modified = true;
                    }
                }
            }

            // Remove marked paragraphs
            foreach (var pToRemove in paragraphsToRemove)
            {
                pToRemove.Remove();
            }
            
            // Clean up empty TOC divs
            if (!div.SelectNodes(".//p")?.Any() ?? true)
            {
                div.Remove();
                modified = true;
            }
        }

        if (modified)
        {
            using (var stream = File.Create(trackedFilePath))
            {
                doc.Save(stream);
                await stream.FlushAsync().ConfigureAwait(false);
            }
            Console.WriteLine($"Pruned TOC in: {trackedFilePath}");
        }
    }

    // Helper method for simple string counting (kept for backward compatibility)
    private static int CountStringOccurrences(string text, string pattern)
    {
        int count = 0;
        int i = 0;
        while ((i = text.IndexOf(pattern, i, StringComparison.Ordinal)) != -1)
        {
            i += pattern.Length;
            count++;
        }
        return count;
    }
}