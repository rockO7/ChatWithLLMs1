using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;
using HtmlAgilityPack;
using System.Text.RegularExpressions;

public static class HeadingBolder
{
    /* ---------------------------------------------------------------- */
    private const string HrMarkup          = "<hr style=\"border:1px solid black;margin:12px 0;\"/>";
    private const int    TocLinkThreshold  = 5;    // ≥ this many links → TOC
    private const int    TocWrapperLimit   = 4;    // rename at most this many

    /* ---------------------------------------------------------------- */
    public static async Task BoldHeadingsForTocAnchorsAsync(
        string inputPath, string outputPath)
    {
        Console.WriteLine($"Processing file: {inputPath}");
        var doc = new HtmlDocument();
        doc.OptionWriteEmptyNodes = true;

        try { using var s = File.OpenRead(inputPath); doc.Load(s); }
        catch (Exception ex) { Console.WriteLine($"Error loading file: {ex.Message}"); return; }

        /* === 1. Build TOC dictionary  anchor‑id → caption ============= */
        var tocMap = BuildTocDictionary(doc);
        Console.WriteLine($"TOC map entries: {tocMap.Count}");
        if (tocMap.Count == 0) 
        { 
            // Debug TOC elements to see why none match
            Console.WriteLine("No TOC found. Analyzing href elements:"); 
            var paragraphs = doc.DocumentNode.SelectNodes("//body/p");
            Console.WriteLine($"Found {paragraphs?.Count ?? 0} paragraphs under body");
            
            foreach (var p in paragraphs ?? Enumerable.Empty<HtmlNode>())
            {
                var a = p.SelectSingleNode("./a[@href]");
                if (a != null)
                {
                    var href = a.GetAttributeValue("href", "");
                    var insNodes = a.SelectNodes(".//ins[not(ancestor::del)]");
                    Console.WriteLine($"Found anchor with href={href}, has ins elements: {insNodes?.Count ?? 0}");
                }
            }
            return; 
        }

        /* === 2. Create / clean headings, collect heading containers ==== */
        var headingContainers = CreateHeadings(doc, tocMap);
        Console.WriteLine($"Created heading containers: {headingContainers.Count}");
        if (headingContainers.Count == 0) 
        { 
            // Debug name anchors to see why none match
            Console.WriteLine("No headings created. Analyzing name anchors:"); 
            var anchors = doc.DocumentNode.SelectNodes("//a[@name]");
            Console.WriteLine($"Found {anchors?.Count ?? 0} anchors with name attribute");
            
            foreach (var anchor in anchors ?? Enumerable.Empty<HtmlNode>())
            {
                var name = anchor.GetAttributeValue("name", "");
                Console.WriteLine($"Anchor name={name}, exists in TOC map: {tocMap.ContainsKey(name)}");
            }
            Console.WriteLine("Nothing changed."); 
            return; 
        }

        /* === 3. Split document into <div class="custom-section"> blocks */
        BuildSectionWrappers(doc, headingContainers);

        /* === 4.  Rename Table‑of‑Contents wrappers ==================== */
        MarkTableOfContentsBlocks(doc);

        /* === 5. Save =================================================== */
        Directory.CreateDirectory(Path.GetDirectoryName(outputPath)!);
        using var outStream = File.Create(outputPath);
        doc.Save(outStream);
        await outStream.FlushAsync();
        Console.WriteLine($"Written: {outputPath}");
    }

    /* ================================================================= */
    /*  Step 1 : read the visible captions from the Table of Contents    */
    /* ================================================================= */
    private static Dictionary<string,string> BuildTocDictionary(HtmlDocument doc)
    {
        var map = new Dictionary<string,string>(StringComparer.Ordinal);

        foreach (var p in doc.DocumentNode.SelectNodes("//body/p") ?? Enumerable.Empty<HtmlNode>())
        {
            var a = p.SelectSingleNode("./a[@href]");
            if (a == null) continue;

            var href = a.GetAttributeValue("href", "");
            if (!href.StartsWith("#") || href.Length <= 1) continue;

            var id = href[1..];

            // Extract all visible text excluding deleted parts to handle tracked changes
            var parts = a.SelectNodes(".//text()[not(ancestor::del)]")
                        ?.Select(x => HtmlEntity.DeEntitize(x.InnerText.Trim()))
                        .Where(t => !string.IsNullOrEmpty(t))
                        .ToList();
            var caption = "";
            if (parts != null && parts.Count > 0)
            {
                caption = string.Join(" ", parts);
            }
            else
            {
                caption = HtmlEntity.DeEntitize(a.InnerText.Trim());
            }

            if (!string.IsNullOrEmpty(caption))
            {
                // collapse spaces around dot in numeric headings
                caption = Regex.Replace(caption, @"(?<=\d)\s*\.\s*(?=\d)", ".");
                map[id] = caption;
                Console.WriteLine($"Added TOC entry: {id} -> {caption}");
            }
        }
        return map;
    }

    /* ================================================================= */
    /*  Step 2 : rebuild headings – return list of their containers      */
    /* ================================================================= */
    private static List<HtmlNode> CreateHeadings(HtmlDocument doc,
                                                 Dictionary<string,string> tocMap)
    {
        var containers = new List<HtmlNode>();

        foreach (var tgt in doc.DocumentNode.SelectNodes("//a[@name]") ?? Enumerable.Empty<HtmlNode>())
        {
            var id = tgt.GetAttributeValue("name", "");
            if (!tocMap.TryGetValue(id, out var caption)) 
            {
                Console.WriteLine($"No TOC entry found for anchor: {id}");
                continue;
            }

            // Pick <li>/<p> as container when possible
            HtmlNode container = tgt.ParentNode?.Name switch
            {
                "li" or "p" => tgt.ParentNode,
                _           => tgt
            };

            // Skip if already processed
            if (container.SelectSingleNode(".//b[@class='custom-bold-heading']") != null)
                continue;

            // Hide browser auto‑number if this is a list item
            if (container.Name == "li")
                AddStyle(container, "list-style-type:none;");

            container.InnerHtml =
                  HrMarkup
                + $"<b class=\"custom-bold-heading\"><a name=\"{id}\">{HtmlEntity.Entitize(caption)}</a></b>";

            containers.Add(container);
            Console.WriteLine($"Created heading for: {id}");
        }
        return containers;
    }

    /* ================================================================= */
    /*  Step 3 : wrap everything into <div class="custom-section"> …     */
    /* ================================================================= */
    private static void BuildSectionWrappers(HtmlDocument doc,
                                             List<HtmlNode> headingContainers)
    {
        var body = doc.DocumentNode.SelectSingleNode("//body");
        if (body == null) return;

        /* 3.1  unwrap any existing custom-section divs (idempotent) */
        foreach (var old in body.SelectNodes(".//div[@class='custom-section']") ?? Enumerable.Empty<HtmlNode>())
        {
            foreach (var child in old.ChildNodes.ToList())
                old.ParentNode.InsertBefore(child, old);
            old.Remove();
        }

        /* 3.2  mark which top‑level nodes start a section */
        var starts = new HashSet<HtmlNode>();
        foreach (var hc in headingContainers)
        {
            var node = hc;
            while (node.ParentNode != null && node.ParentNode.Name != "body")
                node = node.ParentNode;
            starts.Add(node);
        }

        /* 3.3  rebuild body children, inserting wrappers */
        var original = body.ChildNodes.ToList();
        body.RemoveAllChildren();

        HtmlNode currentWrapper = null;

        foreach (var node in original)
        {
            if (starts.Contains(node))
            {
                currentWrapper = HtmlNode.CreateNode("<div class=\"custom-section\"></div>");
                body.AppendChild(currentWrapper);
            }

            if (currentWrapper == null)
            {
                currentWrapper = HtmlNode.CreateNode("<div class=\"custom-section\"></div>");
                body.AppendChild(currentWrapper);
            }

            currentWrapper.AppendChild(node);
        }
    }

    /* ================================================================= */
    /*  Step 4 : rename TOC wrapper(s) to <div class="TableofContents">  */
    /* ================================================================= */
    private static void MarkTableOfContentsBlocks(HtmlDocument doc)
    {
        var body     = doc.DocumentNode.SelectSingleNode("//body");
        if (body == null) return;

        var wrappers = body.SelectNodes("./div[@class='custom-section']") ?? Enumerable.Empty<HtmlNode>();
        int renamed  = 0;

        foreach (var w in wrappers)
        {
            if (renamed >= TocWrapperLimit) break;

            // A wrapper is the TOC if:
            //  • has many # links
            //  • and does NOT contain any bold heading
            var linkCount = w.SelectNodes(".//a[@href]")?.Count ?? 0;
            var hasHeading = w.SelectSingleNode(".//b[@class='custom-bold-heading']") != null;

            if (linkCount >= TocLinkThreshold && !hasHeading)
            {
                w.SetAttributeValue("class", "TableofContents");
                renamed++;
            }
        }
    }

    /* ================================================================= */
    /*  Helpers                                                          */
    /* ================================================================= */
    private static void AddStyle(HtmlNode node, string style)
    {
        var existing = node.GetAttributeValue("style", "");
        if (!existing.Contains(style, StringComparison.OrdinalIgnoreCase))
        {
            if (!string.IsNullOrWhiteSpace(existing) && !existing.TrimEnd().EndsWith(";"))
                existing += ";";
            node.SetAttributeValue("style", existing + style);
        }
    }
}