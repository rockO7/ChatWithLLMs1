import { NextResponse } from "next/server";

export async function GET() {
  const client_id = process.env.GITHUB_CLIENT_ID || "Ov23liybvKZsCVgfoSDW";
  const redirect_uri = "http://localhost:3000/api/auth/callback/github";
  const scope = "repo,user";
  const url = `https://github.com/login/oauth/authorize?client_id=${client_id}&redirect_uri=${encodeURIComponent(
    redirect_uri
  )}&scope=${encodeURIComponent(scope)}`;
  return NextResponse.redirect(url);
}
