import { NextResponse } from "next/server";
import { cookies } from "next/headers";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const code = searchParams.get("code");

  if (!code) {
    return NextResponse.redirect("http://localhost:3000/?error=no_code");
  }

  const client_id = process.env.GITHUB_CLIENT_ID || "Ov23liybvKZsCVgfoSDW";
  const client_secret = process.env.GITHUB_CLIENT_SECRET || "372ea87d3442b930cbd9c990c13e3ce1f1970890";

  try {
    const res = await fetch("https://github.com/login/oauth/access_token", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({
        client_id,
        client_secret,
        code,
      }),
    });

    const data = await res.json();

    if (data.error) {
      console.error("GitHub OAuth error:", data.error);
      return NextResponse.redirect(`http://localhost:3000/?error=${data.error}`);
    }

    const token = data.access_token;
    if (!token) {
      return NextResponse.redirect("http://localhost:3000/?error=no_token");
    }

    const cookieStore = await cookies();
    cookieStore.set("github_token", token, {
      httpOnly: false, // Accessible by client-side Zustand store
      secure: process.env.NODE_ENV === "production",
      path: "/",
      maxAge: 60 * 60 * 24 * 7, // 1 week
    });

    return NextResponse.redirect("http://localhost:3000/");
  } catch (err) {
    console.error("Failed to exchange code:", err);
    return NextResponse.redirect("http://localhost:3000/?error=callback_failed");
  }
}
