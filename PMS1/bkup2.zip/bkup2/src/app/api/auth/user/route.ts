import { NextResponse } from "next/server";
import { cookies } from "next/headers";

export async function GET() {
  const cookieStore = await cookies();
  const token = cookieStore.get("github_token")?.value;

  if (!token) {
    return NextResponse.json({ authenticated: false }, { status: 401 });
  }

  try {
    const res = await fetch("https://api.github.com/user", {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/vnd.github+json",
        "User-Agent": "PromptHub-PMS",
      },
    });

    if (!res.ok) {
      return NextResponse.json({ authenticated: false }, { status: res.status });
    }

    const userData = await res.json();
    return NextResponse.json({
      authenticated: true,
      user: {
        name: userData.name || userData.login,
        avatar_url: userData.avatar_url,
        login: userData.login,
      },
      token: token,
    });
  } catch (err) {
    console.error("Failed to fetch GitHub user:", err);
    return NextResponse.json({ authenticated: false, error: "Server error" }, { status: 500 });
  }
}
