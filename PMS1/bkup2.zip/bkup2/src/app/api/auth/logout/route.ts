import { NextResponse } from "next/server";
import { cookies } from "next/headers";

export async function GET() {
  const cookieStore = await cookies();
  cookieStore.delete("github_token");
  return NextResponse.redirect("http://localhost:3000/");
}
