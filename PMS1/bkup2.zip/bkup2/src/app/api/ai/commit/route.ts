import { NextResponse } from "next/server";
import { OpenAI } from "openai";

export async function POST(req: Request) {
  try {
    const { original, modified, filename } = await req.json();

    const endpoint = process.env.AZURE_OPENAI_ENDPOINT;
    const apiKey = process.env.AZURE_OPENAI_API_KEY;
    const deploymentName = process.env.AZURE_OPENAI_DEPLOYMENT_NAME;

    // Check if configuration is missing or holds placeholder values
    const isConfigMissing =
      !endpoint ||
      !apiKey ||
      !deploymentName ||
      apiKey.includes("your-") ||
      endpoint.includes("your-");

    if (isConfigMissing) {
      return NextResponse.json({
        commitMessage: `feat: update ${filename || "prompts"} rules and configuration`,
      });
    }

    // Generate a simple line-by-line diff
    const originalLines = (original || "").split("\n");
    const modifiedLines = (modified || "").split("\n");
    let diff = "";
    const maxLines = Math.max(originalLines.length, modifiedLines.length);
    for (let i = 0; i < maxLines; i++) {
      const orig = originalLines[i];
      const mod = modifiedLines[i];
      if (orig !== mod) {
        if (orig !== undefined) diff += `- ${orig}\n`;
        if (mod !== undefined) diff += `+ ${mod}\n`;
      }
    }

    const client = new OpenAI({
      baseURL: endpoint.replace(/\/$/, ""),
      apiKey: apiKey,
    });

    const result = await client.chat.completions.create({
      messages: [
        {
          role: "system",
          content:
            "You are an AI assistant that writes git commit messages. You will be given a unified git diff. Write a clear, concise conventional commit message (e.g. feat: add validation, fix: resolve syntax error) describing the changes. Do not include markdown ticks, do not write explanations. Write ONLY the commit message in 1 line.",
        },
        {
          role: "user",
          content: `Unified Diff:\n${diff || "No changes"}`,
        },
      ],
      model: deploymentName,
      reasoning_effort: "none"
    });

    let commitMessage = result.choices?.[0]?.message?.content || "";
    commitMessage = commitMessage.replace(/["']/g, "").trim();
    return NextResponse.json({ commitMessage });
  } catch (err) {
    console.error("AI commit route handler error:", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
