import { NextResponse } from "next/server";
import { OpenAI } from "openai";

export async function POST(req: Request) {
  try {
    const { prefix } = await req.json();

    const endpoint = process.env.AZURE_OPENAI_ENDPOINT;
    const apiKey = process.env.AZURE_OPENAI_API_KEY;
    const deploymentName = process.env.AZURE_OPENAI_DEPLOYMENT_NAME;

    // Check if configuration is missing or holds placeholder values
    const isConfigMissing =
      !endpoint ||
      !apiKey ||
      !deploymentName ||
      apiKey.includes("your-") ||
      endpoint.includes("your-");

    if (isConfigMissing) {
      let simulated = "";
      if (prefix.trim().endsWith("role:")) {
        simulated = " system";
      } else if (prefix.trim().endsWith("system-rules")) {
        simulated = "\n# Instructions for the assistant...";
      } else if (prefix.trim().endsWith("import")) {
        simulated = " React from 'react';";
      } else {
        simulated = " // Keep typing to receive suggestions...";
      }
      return NextResponse.json({ suggestion: simulated });
    }

    const client = new OpenAI({
      baseURL: endpoint.replace(/\/$/, ""),
      apiKey: apiKey,
    });

    const result = await client.chat.completions.create({
      messages: [
        {
          role: "system",
          content:
            "You are an AI code completion assistant. You will be given a prefix representing the code/prompt written so far. Your job is to output ONLY the next few characters or lines to complete the current line or next line. Do not wrap your response in markdown code blocks, do not explain anything, do not output anything other than the exact completion content.",
        },
        {
          role: "user",
          content: prefix,
        },
      ],
      model: deploymentName,
      reasoning_effort: "none"
    });

    const suggestion = result.choices?.[0]?.message?.content || "";
    return NextResponse.json({ suggestion });
  } catch (err) {
    console.error("AI suggest route handler error:", err);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
