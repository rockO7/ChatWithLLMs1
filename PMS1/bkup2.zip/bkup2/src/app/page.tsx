"use client";

import React, { useEffect } from "react";
import { useAppStore } from "@/store";
import { TopBar } from "@/components/layout/TopBar";
import { StatusBar } from "@/components/layout/StatusBar";
import { FileTree } from "@/components/file-tree/FileTree";
import { PromptEditor } from "@/components/editor/PromptEditor";
import { LivePreview } from "@/components/preview/LivePreview";
import { VersionTimeline } from "@/components/versioning/VersionTimeline";
import { TestingWorkspace } from "@/components/testing/TestingWorkspace";
import { CommandPalette } from "@/components/common/CommandPalette";
import { ToastContainer } from "@/components/common/ToastContainer";
import { CreatePrModal } from "@/components/versioning/CreatePrModal";
import { SettingsDocsHelpModals } from "@/components/layout/SettingsDocsHelpModals";
import { motion, AnimatePresence } from "framer-motion";
import { Group, Panel, Separator } from "react-resizable-panels";
import { cn } from "@/lib/utils";
import { Tooltip } from "@/components/ui/Tooltip";
import Image from "next/image";

import { FilePlus, GitFork, BookOpen, Star, Sun, Moon, Layers } from "lucide-react";
import { MarketplacePage } from "@/components/marketplace/MarketplacePage";

function ResizeHandle({ className }: { className?: string }) {
  return (
    <Separator
      className={cn(
        "relative !w-px !basis-px bg-border hover:bg-zinc-600 active:bg-zinc-500 transition-colors duration-150",
        className,
      )}
    />
  );
}

function EditorWorkspace() {
  const {
    sidebarOpen,
    versionPanelOpen,
    setVersionPanelOpen,
    previewPanelOpen,
    setPreviewPanelOpen,
    selectedFile,
  } = useAppStore();

  const isPreviewable = React.useMemo(() => {
    if (!selectedFile) return true;
    const name = selectedFile.name.toLowerCase();
    return name.endsWith(".md") || name.endsWith(".txt");
  }, [selectedFile]);

  const showPreviewPanel = previewPanelOpen && isPreviewable;

  // Calculate default sizes dynamically so they always sum to 100
  const sidebarSize = sidebarOpen ? 18 : 0;
  const versionSize = versionPanelOpen ? 18 : 0;
  const previewSize = showPreviewPanel ? 25 : 0;
  const editorSize = 100 - (sidebarSize + versionSize + previewSize);

  return (
    <div className="flex-1 flex overflow-hidden h-full">
      <Group
        orientation="horizontal"
        id="editor-layout"
        key={`${sidebarOpen}-${versionPanelOpen}-${showPreviewPanel}`}
      >
        {/* Sidebar */}
        {sidebarOpen && (
          <>
            <Panel
              defaultSize={sidebarSize}
              minSize={14}
              maxSize={35}
              id="sidebar"
              style={{ minWidth: "250px" }}
            >
              <FileTree />
            </Panel>
            <ResizeHandle />
          </>
        )}

        {/* Editor */}
        <Panel defaultSize={editorSize} minSize={25} id="editor">
          <PromptEditor />
        </Panel>

        {/* Preview */}
        {showPreviewPanel && (
          <>
            <ResizeHandle />
            <Panel defaultSize={previewSize} minSize={15} id="preview">
              <LivePreview />
            </Panel>
          </>
        )}

        {/* Version panel */}
        {versionPanelOpen && (
          <>
            <ResizeHandle />
            <Panel
              defaultSize={versionSize}
              minSize={14}
              maxSize={35}
              id="version"
              style={{ minWidth: "250px" }}
            >
              <VersionTimeline />
            </Panel>
          </>
        )}
      </Group>

      {/* Edge toggle buttons when preview or version panels are collapsed */}
      <div className="flex flex-col border-l border-border bg-bg-primary">
        {!showPreviewPanel && (
          <Tooltip
            content={
              isPreviewable
                ? "Open Preview Panel"
                : "Preview only available for .md and .txt files"
            }
            side="left"
          >
            <button
              onClick={() => {
                if (isPreviewable) setPreviewPanelOpen(true);
              }}
              disabled={!isPreviewable}
              className={cn(
                "w-8 flex-1 flex flex-col items-center justify-center border-b border-border transition-colors",
                isPreviewable
                  ? "hover:bg-bg-hover text-text-muted hover:text-text-primary cursor-pointer"
                  : "opacity-30 cursor-not-allowed text-text-muted/60",
              )}
            >
              <span className="text-[11px] font-medium tracking-widest [writing-mode:vertical-lr] select-none">
                PREVIEW
              </span>
            </button>
          </Tooltip>
        )}

        {!versionPanelOpen && (
          <Tooltip content="Open Version Panel" side="left">
            <button
              onClick={() => setVersionPanelOpen(true)}
              className="w-8 flex-1 flex flex-col items-center justify-center hover:bg-bg-hover transition-colors"
            >
              <span className="text-[11px] font-medium text-text-muted tracking-widest [writing-mode:vertical-lr] select-none">
                VERSIONS
              </span>
            </button>
          </Tooltip>
        )}
      </div>
    </div>
  );
}

export default function Home() {
  const {
    viewMode,
    setViewMode,
    initializeSelection,
    currentRepository,
    selectRepository,
    createFile,
    themeMode,
    toggleThemeMode,
    isAuthenticated,
    user,
    login,
    logout,
    checkSession,
    repositories,
    createPrModalOpen,
    setDocsModalOpen,
    sidebarOpen,
    setSidebarOpen,
  } = useAppStore();

  // Load session on startup
  useEffect(() => {
    checkSession();
  }, [checkSession]);

  // Initialize selection when repository changes
  useEffect(() => {
    if (currentRepository) {
      initializeSelection();
    }
  }, [currentRepository, initializeSelection]);

  // Keyboard shortcuts
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "1") {
        e.preventDefault();
        setViewMode("editor");
      }
      if ((e.metaKey || e.ctrlKey) && e.key === "2") {
        e.preventDefault();
        setViewMode("testing");
      }
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "b") {
        e.preventDefault();
        setSidebarOpen(!sidebarOpen);
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [setViewMode, sidebarOpen, setSidebarOpen]);

  // Handle direct "Create Prompt" click from landing page
  const handleCreatePromptFromDashboard = (repoName: string) => {
    selectRepository(repoName);
    setTimeout(() => {
      const name = prompt("Enter prompt file name (e.g. system-rules.md):");
      if (name) {
        createFile(null, name);
      }
    }, 100);
  };

  const reposToDisplay = repositories;
  const totalStars = reposToDisplay.reduce(
    (sum, repo) => sum + (repo.stars || 0),
    0,
  );

  // If no repository is active, show the stunning dashboard
  if (!currentRepository && viewMode !== "marketplace") {
    return (
      <div className="h-screen w-screen flex flex-col bg-bg-primary overflow-y-auto select-none relative">
        {/* Glow ambient background circles */}
        <div className="absolute top-[-100px] left-1/4 w-[500px] h-[500px] bg-indigo-500/10 rounded-full blur-[120px] pointer-events-none animate-pulse-slow" />
        <div className="absolute top-[-50px] right-1/4 w-[400px] h-[400px] bg-emerald-500/5 rounded-full blur-[100px] pointer-events-none" />

        {/* Dashboard TopBar */}
        <div className="h-14 border-b border-border flex items-center justify-between px-6 bg-bg-primary/75 backdrop-blur-md flex-shrink-0 select-none sticky top-0 z-50">
          <div className="flex items-center gap-2.5">
            <div className="h-6 w-6 bg-white rounded-md flex items-center justify-center shadow-lg">
              <span className="text-[12px] font-bold text-black">P</span>
            </div>
            <span className="text-[14px] font-semibold text-text-primary tracking-tight">
              PromptHub{" "}
              <span className="text-text-tertiary font-normal">
                / Dashboard
              </span>
            </span>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setViewMode("marketplace")}
              className={cn(
                "text-[12px] font-bold transition-all cursor-pointer border px-3 py-1.5 rounded-lg mr-2",
                themeMode === "light"
                  ? "bg-transparent border-emerald-600/35 text-emerald-700 hover:text-emerald-800"
                  : "border-emerald-500/20 bg-emerald-950/20 text-emerald-400 hover:text-emerald-300 hover:border-emerald-500/40"
              )}
            >
              Explore Marketplace
            </button>
            <span className="text-[11px] text-text-muted">
              PMS Enterprise v2.1
            </span>

            {/* Theme Toggle in Dashboard */}
            <Tooltip
              content={
                themeMode === "dark"
                  ? "Switch to Light Mode"
                  : "Switch to Dark Mode"
              }
            >
              <button
                onClick={toggleThemeMode}
                className="h-7 w-7 flex items-center justify-center rounded-md text-text-tertiary hover:text-text-primary hover:bg-bg-hover transition-colors duration-150 cursor-pointer"
              >
                {themeMode === "dark" ? <Sun size={14} /> : <Moon size={14} />}
              </button>
            </Tooltip>

            {isAuthenticated ? (
              <div className="flex items-center gap-2 border border-border bg-bg-elevated/40 pl-1.5 pr-2.5 py-1 rounded-lg shadow-sm">
                {user?.avatar_url && (
                  <Image
                    src={user.avatar_url}
                    alt={user.name || ""}
                    width={20}
                    height={20}
                    className="h-5 w-5 rounded-full border border-border/50"
                  />
                )}
                <span className="text-[11.5px] font-semibold text-text-secondary">
                  {user?.name}
                </span>
                <span className="text-border-strong text-[10px] select-none">
                  ·
                </span>
                <button
                  onClick={logout}
                  className="text-[11px] text-text-muted hover:text-text-primary transition-colors cursor-pointer"
                >
                  Logout
                </button>
              </div>
            ) : (
              <button
                onClick={login}
                className="h-8 px-3 rounded-lg text-[11px] font-bold bg-white text-black hover:bg-zinc-200 transition-colors flex items-center gap-1.5 cursor-pointer shadow-subtle animate-pulse-slow"
              >
                Connect GitHub
              </button>
            )}
          </div>
        </div>

        {/* Dashboard Content */}
        <div className="flex-1 max-w-5xl w-full mx-auto px-6 py-10 flex flex-col justify-center relative z-10">
          <div className="mb-10 text-center max-w-xl mx-auto space-y-3">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full border border-indigo-500/25 bg-indigo-500/5 text-indigo-400 text-[11px] font-semibold tracking-wide">
              <span>🚀 Prompt Management Redefined</span>
            </div>
            <h1 className="text-4xl font-extrabold text-text-primary tracking-tight sm:text-5xl bg-gradient-to-r from-text-primary via-slate-100 to-indigo-400 bg-clip-text">
              Select a Prompt Repository
            </h1>
            <p className="text-[14px] text-text-secondary leading-relaxed max-w-md mx-auto">
              Collaborate, track versions, and test prompts across isolated environments using GitHub as your single source of truth.
            </p>
          </div>

          {/* Sandbox Indicator Banner */}
          {!isAuthenticated && (
            <div className="mb-8 p-4 rounded-xl border border-indigo-500/20 bg-indigo-500/5 backdrop-blur-sm flex flex-col sm:flex-row items-center justify-between gap-4 shadow-lg shadow-indigo-500/2 animate-in fade-in slide-in-from-top-2 duration-300">
              <div className="flex items-center gap-3 text-center sm:text-left">
                <div className="h-8 w-8 rounded-lg bg-indigo-500/10 flex items-center justify-center text-indigo-400 flex-shrink-0">
                  <Layers size={16} />
                </div>
                <div>
                  <h4 className="text-[13px] font-bold text-text-primary">
                    Sandbox Mode Active
                  </h4>
                  <p className="text-[11.5px] text-text-secondary leading-relaxed">
                    You are exploring PromptHub with local mock repositories. Connect to GitHub to sync live changes.
                  </p>
                </div>
              </div>
              <button
                onClick={login}
                className="h-8 px-4 bg-indigo-600 hover:bg-indigo-500 text-[11px] font-bold text-white rounded-lg transition-all shadow-md shadow-indigo-600/10 flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
              >
                Connect GitHub Profile
              </button>
            </div>
          )}

          {/* Stats Bar */}
          <div className="grid grid-cols-3 gap-4 mb-8">
            <div className="p-4 rounded-xl border border-border bg-bg-secondary/25 backdrop-blur-sm flex flex-col justify-center">
              <span className="text-[10px] text-text-muted font-bold uppercase tracking-wider">Repositories</span>
              <span className="text-xl font-bold text-text-primary mt-1">{reposToDisplay.length} active</span>
            </div>
            <div className="p-4 rounded-xl border border-border bg-bg-secondary/25 backdrop-blur-sm flex flex-col justify-center">
              <span className="text-[10px] text-text-muted font-bold uppercase tracking-wider">Starred Prompts</span>
              <span className="text-xl font-bold text-text-primary mt-1">{totalStars} total</span>
            </div>
            <div className="p-4 rounded-xl border border-border bg-bg-secondary/25 backdrop-blur-sm flex flex-col justify-center">
              <span className="text-[10px] text-text-muted font-bold uppercase tracking-wider">System Status</span>
              <span className="text-xl font-bold text-emerald-400 mt-1 flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                Synced
              </span>
            </div>
          </div>

          {/* Repository Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {reposToDisplay.map((repo) => (
              <div
                key={repo.name}
                className="group relative flex flex-col justify-between glass-panel glass-panel-hover rounded-xl p-5 shadow-lg transition-all duration-300 transform hover:-translate-y-1"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="p-2 rounded-lg bg-white/[0.04] border border-border group-hover:border-white/10 group-hover:bg-white/[0.08] transition-all">
                      <GitFork size={18} className="text-text-secondary group-hover:text-text-primary transition-colors" />
                    </div>
                    <span className="text-[10px] font-mono font-semibold text-text-muted bg-white/[0.03] border border-border px-2 py-0.5 rounded-full select-none">
                      {repo.branch}
                    </span>
                  </div>

                  <h3 className="text-[15px] font-bold text-text-primary mb-2 tracking-tight group-hover:text-indigo-400 transition-colors">
                    {repo.name}
                  </h3>
                  <p className="text-[12px] text-text-secondary leading-relaxed mb-6">
                    {repo.description}
                  </p>
                </div>

                <div className="space-y-3 pt-4 border-t border-border/50">
                  <div className="flex items-center justify-between text-[11px] text-text-muted">
                    <span>Active prompts</span>
                    <span className="font-mono font-bold text-text-secondary">
                      {repo.promptCount || repo.fileTree?.reduce((acc, current) => {
                        const countFiles = (node: any): number => {
                          if (node.type === "file") return 1;
                          return node.children?.reduce((accChild: number, childNode: any) => accChild + countFiles(childNode), 0) || 0;
                        };
                        return acc + countFiles(current);
                      }, 0) || 4}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-text-muted mb-2">
                    <span>Last updated</span>
                    <span className="text-text-secondary font-medium">{repo.lastModified}</span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 pt-2">
                    <button
                      onClick={() => selectRepository(repo.name)}
                      className="h-8 rounded-lg text-[11.5px] font-bold bg-white text-black hover:bg-zinc-200 transition-colors flex items-center justify-center gap-1 cursor-pointer shadow-subtle"
                    >
                      Open File
                    </button>
                    <button
                      onClick={() => handleCreatePromptFromDashboard(repo.name)}
                      className="h-8 rounded-lg text-[11.5px] font-bold border border-border hover:border-border-strong text-text-secondary hover:text-text-primary bg-bg-elevated/20 hover:bg-bg-elevated/50 transition-colors flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <FilePlus size={11} />
                      New Prompt
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Quick guides / Info */}
          <div className="mt-16 border-t border-border pt-8 flex flex-col md:flex-row items-center justify-between gap-6 text-[12px] text-text-muted">
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1 select-none font-medium">
                <Star size={12} className="text-yellow-500" /> Starred:{" "}
                <strong className="text-text-secondary font-mono ml-0.5">{totalStars}</strong>
              </span>
              <button
                onClick={() => setDocsModalOpen(true)}
                className="flex items-center gap-1.5 hover:text-text-primary transition-colors cursor-pointer"
              >
                <BookOpen size={12} className="text-indigo-400" /> Read
                documentation
              </button>
              <span className="text-border-strong text-[10px] select-none">·</span>
              <button
                onClick={() => setViewMode("marketplace")}
                className="flex items-center gap-1.5 hover:text-text-primary text-emerald-400 font-semibold transition-colors cursor-pointer"
              >
                <Layers size={12} className="text-emerald-400" /> Explore Marketplace
              </button>
            </div>
            <div className="flex items-center gap-2 select-none font-medium">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <span>
                All {reposToDisplay.length} repository environment
                {reposToDisplay.length !== 1 ? "s" : ""} synced & healthy
              </span>
            </div>
          </div>
        </div>
        <ToastContainer />
      </div>
    );
  }

  return (
    <div className="h-screen w-screen flex flex-col bg-bg-primary overflow-hidden">
      <TopBar />

      <div className="flex-1 overflow-hidden">
        <AnimatePresence mode="wait">
          {viewMode === "editor" ? (
            <motion.div
              key="editor"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.15 }}
              className="h-full"
            >
              <EditorWorkspace />
            </motion.div>
          ) : viewMode === "testing" ? (
            <motion.div
              key="testing"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.15 }}
              className="h-full"
            >
              <TestingWorkspace />
            </motion.div>
          ) : (
            <motion.div
              key="marketplace"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.15 }}
              className="h-full"
            >
              <MarketplacePage />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <StatusBar />
      <CommandPalette />
      {createPrModalOpen && <CreatePrModal />}
      <SettingsDocsHelpModals />
      <ToastContainer />
    </div>
  );
}
