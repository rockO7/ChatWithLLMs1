"use client";

import { useEffect } from "react";
import { useAppStore } from "@/store";

export function useKeyboardShortcuts() {
  const { setCommandPaletteOpen, setViewMode, setIsDirty } = useAppStore();

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      // Cmd+K: Command palette
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setCommandPaletteOpen(true);
      }

      // Cmd+S: Save
      if ((e.metaKey || e.ctrlKey) && e.key === "s") {
        e.preventDefault();
        setIsDirty(false);
      }

      // Cmd+1: Editor mode
      if ((e.metaKey || e.ctrlKey) && e.key === "1") {
        e.preventDefault();
        setViewMode("editor");
      }

      // Cmd+2: Testing mode
      if ((e.metaKey || e.ctrlKey) && e.key === "2") {
        e.preventDefault();
        setViewMode("testing");
      }
    };

    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [setCommandPaletteOpen, setViewMode, setIsDirty]);
}
