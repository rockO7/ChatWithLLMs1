export type FileStatus = "draft" | "synced" | "behind" | "modified" | "new";

export interface FileNode {
  id: string;
  name: string;
  type: "file" | "folder";
  path: string;
  status?: FileStatus;
  extension?: string;
  children?: FileNode[];
  content?: string;
  originalContent?: string;
  sha?: string;
  lastModified?: Date;
}

export interface Commit {
  id: string;
  hash: string;
  message: string;
  author: {
    name: string;
    avatar: string;
  };
  date: Date;
  additions: number;
  deletions: number;
  files: string[];
}

export interface PromptVersion {
  id: string;
  version: string;
  content: string;
  commit: Commit;
  variables: string[];
}

export interface Variable {
  name: string;
  defaultValue?: string;
  description?: string;
  type?: "string" | "number" | "boolean" | "enum";
  options?: string[];
}

export interface TestRun {
  id: string;
  model: string;
  prompt: string;
  variables: Record<string, string>;
  response: string;
  tokens: {
    input: number;
    output: number;
  };
  latency: number;
  timestamp: Date;
  rating?: "up" | "down";
}

export interface ModelConfig {
  id: string;
  name: string;
  provider: string;
  icon: string;
  maxTokens: number;
  selected: boolean;
}

export type ViewMode = "editor" | "testing" | "marketplace";
export type PreviewMode = "raw" | "simulated" | "mobile";
