export type MarketplaceItemType = "agent" | "skill" | "instruction" | "prompt";

export interface MarketplaceItem {
  id: string;
  name: string;
  type: MarketplaceItemType;
  publisher: string;
  isOfficial: boolean;
  category: string;
  shortDescription: string;
  longDescription: string;
  whatItDoes: string;
  whatItDoesHighlight?: string;
  whenToUse: string[];
  content: string;
  contentFilename: string;
  stars?: number;
  downloads?: number;
}

export interface PublisherInfo {
  name: string;
  displayName: string;
  avatarUrl?: string;
}

export interface CategoryInfo {
  id: string;
  name: string;
  displayName: string;
}
