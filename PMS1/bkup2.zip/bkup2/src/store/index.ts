import { create } from "zustand";
import type { AppState } from "./types";
import { createUISlice } from "./slices/uiSlice";
import { createFileTreeSlice } from "./slices/fileTreeSlice";
import { createEditorSlice } from "./slices/editorSlice";
import { createPreviewSlice } from "./slices/previewSlice";
import { createVariablesSlice } from "./slices/variablesSlice";
import { createGitSlice } from "./slices/gitSlice";
import { createAuthSlice } from "./slices/authSlice";
import { createRepositorySlice } from "./slices/repositorySlice";
import { createBranchSlice } from "./slices/branchSlice";
import { createDiffSlice } from "./slices/diffSlice";
import { createPrSlice } from "./slices/prSlice";
import { createSyncSlice } from "./slices/syncSlice";
import { createThemeSlice } from "./slices/themeSlice";
import { createToastSlice } from "./slices/toastSlice";
import { createTestingSlice } from "./slices/testingSlice";
import { createMarketplaceSlice } from "./slices/marketplaceSlice";

export const useAppStore = create<AppState>((set, get) => ({
  ...createUISlice(set),
  ...createFileTreeSlice(set, get),
  ...createEditorSlice(set, get),
  ...createPreviewSlice(set),
  ...createVariablesSlice(set),
  ...createGitSlice(set, get),
  ...createAuthSlice(set, get),
  ...createRepositorySlice(set, get),
  ...createBranchSlice(set, get),
  ...createDiffSlice(set, get),
  ...createPrSlice(set, get),
  ...createSyncSlice(set),
  ...createThemeSlice(set, get),
  ...createToastSlice(set, get),
  ...createTestingSlice(set),
  ...createMarketplaceSlice(set, get),
}));
