import { AppState } from "../types";
import { MarketplaceItem } from "@/types/marketplace";
import { mockMarketplaceItems } from "@/data/marketplaceMock";

export const createMarketplaceSlice = (set: any, get: any) => ({
  marketplaceItems: mockMarketplaceItems,
  selectedMarketplaceItem: null,
  marketplaceSearchQuery: "",
  marketplaceSelectedCategory: "all",
  marketplaceSelectedPublisher: "all",
  marketplaceSelectedType: "all",

  setSelectedMarketplaceItem: (item: MarketplaceItem | null) => {
    set({ selectedMarketplaceItem: item });
  },

  setMarketplaceSearchQuery: (query: string) => {
    set({ marketplaceSearchQuery: query });
  },

  setMarketplaceSelectedCategory: (category: string) => {
    set({ marketplaceSelectedCategory: category });
  },

  setMarketplaceSelectedPublisher: (publisher: string) => {
    set({ marketplaceSelectedPublisher: publisher });
  },

  setMarketplaceSelectedType: (type: string) => {
    set({ marketplaceSelectedType: type });
  },

  publishMarketplaceItem: (item: Omit<MarketplaceItem, "id" | "stars" | "downloads">) => {
    const newItem: MarketplaceItem = {
      ...item,
      id: `custom_${Math.random().toString(36).substring(7)}`,
      stars: Math.floor(Math.random() * 10) + 1,
      downloads: Math.floor(Math.random() * 50) + 5,
    };

    set((state: AppState) => ({
      marketplaceItems: [newItem, ...state.marketplaceItems],
    }));

    get().addToast({
      type: "success",
      title: "Published Successfully",
      message: `"${newItem.name}" is now live in the marketplace.`,
    });
  },

  cloneMarketplaceItem: async (item: MarketplaceItem, repoName: string): Promise<boolean> => {
    const activeRepo = get().currentRepository;

    // Check if repoName is the active repo
    if (activeRepo !== repoName) {
      try {
        await get().selectRepository(repoName);
      } catch (err) {
        get().addToast({
          type: "error",
          title: "Cloning Failed",
          message: `Could not open repository "${repoName}".`,
        });
        return false;
      }
    }

    try {
      // Create the file at root (parentId = null) with the content
      get().createFile(null, item.contentFilename, item.content);
      
      get().addToast({
        type: "success",
        title: "Item Cloned",
        message: `Successfully cloned "${item.name}" into "${repoName}".`,
      });

      // Switch view mode back to editor
      set({ viewMode: "editor" });
      return true;
    } catch (error) {
      get().addToast({
        type: "error",
        title: "Cloning Failed",
        message: `Failed to create file "${item.contentFilename}" in repo.`,
      });
      return false;
    }
  },
});
