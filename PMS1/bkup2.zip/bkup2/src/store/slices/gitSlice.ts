import { Commit } from "@/types";
import { FileNode } from "@/types";
import { saveFileTreeToLocal, utf8_to_b64 } from "@/lib/storeHelpers";

export interface GitSlice {
  // Git
  commits: Commit[];
  commitMessage: string;
  setCommitMessage: (message: string) => void;
  fetchCommits: () => Promise<void>;
  fetchCommitDetails: (commitId: string) => Promise<void>;
  commitSelectedFile: (message: string) => Promise<void>;
}

export const createGitSlice = (set: any, get: any): GitSlice => ({
  // Git
  commits: [],
  commitMessage: "",
  setCommitMessage: (message) => set({ commitMessage: message }),

  fetchCommits: async () => {
    const token = get().githubToken;
    const currentRepo = get().currentRepository;
    if (!token || !currentRepo) return;

    try {
      const [owner, repo] = currentRepo.split("/");
      const res = await fetch(
        `https://api.github.com/repos/${owner}/${repo}/commits?per_page=15`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            Accept: "application/vnd.github+json",
            "User-Agent": "PromptHub-PMS",
          },
        },
      );

      if (res.ok) {
        const data = await res.json();
        const formattedCommits: Commit[] = data.map(
          (c: {
            sha: string;
            commit: {
              message: string;
              author: { name: string; date: string };
              tree?: { sha: string };
            };
            author?: { avatar_url: string };
          }) => ({
            id: c.sha,
            hash: c.sha.substring(0, 7),
            message: c.commit.message,
            author: {
              name: c.commit.author.name,
              avatar: c.author?.avatar_url || "",
            },
            date: new Date(c.commit.author.date),
            additions: 1,
            deletions: 0,
            files: [
              c.commit.tree?.sha
                ? `tree: ${c.commit.tree.sha.substring(0, 7)}`
                : "unknown",
            ],
          }),
        );
        set({ commits: formattedCommits });
      }
    } catch (error) {
      console.error("Failed to fetch commits:", error);
    }
  },

  fetchCommitDetails: async (commitId) => {
    const token = get().githubToken;
    const currentRepo = get().currentRepository;
    if (!token || !currentRepo) return;

    const commit = get().commits.find((c: Commit) => c.id === commitId);
    if (
      commit &&
      commit.files.length > 0 &&
      !commit.files[0].startsWith("tree:") &&
      commit.files[0] !== "unknown"
    ) {
      return;
    }

    try {
      const [owner, repo] = currentRepo.split("/");
      const res = await fetch(
        `https://api.github.com/repos/${owner}/${repo}/commits/${commitId}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            Accept: "application/vnd.github+json",
            "User-Agent": "PromptHub-PMS",
          },
        },
      );

      if (res.ok) {
        const data = await res.json();
        const files = data.files
          ? data.files.map((f: { filename: string }) => f.filename)
          : [];
        const additions = data.stats?.additions || 0;
        const deletions = data.stats?.deletions || 0;

        set((state: any) => ({
          commits: state.commits.map((c: Commit) =>
            c.id === commitId ? { ...c, files, additions, deletions } : c,
          ),
        }));
      }
    } catch (error) {
      console.error("Failed to fetch commit details:", error);
    }
  },

  commitSelectedFile: async (message: string) => {
    const token = get().githubToken;
    const currentRepo = get().currentRepository;
    const selectedFile = get().selectedFile;
    const content = get().editorContent;

    if (!token || !currentRepo || !selectedFile) {
      throw new Error("Missing auth token, repo or selected file");
    }

    set({ syncStatus: "syncing" });
    try {
      const [owner, repo] = currentRepo.split("/");
      const cleanPath = selectedFile.path.startsWith("/")
        ? selectedFile.path.substring(1)
        : selectedFile.path;

      let sha = selectedFile.sha;
      if (!sha && selectedFile.status !== "new") {
        const checkRes = await fetch(
          `https://api.github.com/repos/${owner}/${repo}/contents/${cleanPath}`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
              Accept: "application/vnd.github+json",
              "User-Agent": "PromptHub-PMS",
            },
          },
        );
        if (checkRes.ok) {
          const checkData = await checkRes.json();
          sha = checkData.sha;
        }
      }

      const body: { message: string; content: string; sha?: string } = {
        message: message || `Update ${selectedFile.name}`,
        content: utf8_to_b64(content),
      };
      if (sha) {
        body.sha = sha;
      }

      const res = await fetch(
        `https://api.github.com/repos/${owner}/${repo}/contents/${cleanPath}`,
        {
          method: "PUT",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
            Accept: "application/vnd.github+json",
            "User-Agent": "PromptHub-PMS",
          },
          body: JSON.stringify(body),
        },
      );

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || "Failed to commit file");
      }

      const resData = await res.json();
      const newSha = resData.content.sha;

      const updateTree = (nodes: FileNode[]): FileNode[] => {
        return nodes.map((node) => {
          if (node.id === selectedFile.id) {
            return {
              ...node,
              content: content,
              sha: newSha,
              status: "synced",
              lastModified: new Date(),
            };
          }
          if (node.children) {
            return { ...node, children: updateTree(node.children) };
          }
          return node;
        });
      };

      const updatedTree = updateTree(get().fileTree);
      set({
        fileTree: updatedTree,
        selectedFile: {
          ...selectedFile,
          content: content,
          sha: newSha,
          status: "synced",
          lastModified: new Date(),
        },
        isDirty: false,
        commitMessage: "",
        syncStatus: "connected",
      });

      if (typeof window !== "undefined" && currentRepo) {
        try {
          const draftsStr = localStorage.getItem("prompthub_drafts") || "{}";
          const drafts = JSON.parse(draftsStr);
          delete drafts[`${currentRepo}:${selectedFile.path}`];
          localStorage.setItem("prompthub_drafts", JSON.stringify(drafts));
        } catch (e) {
          console.error("Failed to remove committed draft:", e);
        }
      }
      saveFileTreeToLocal(currentRepo, updatedTree);

      await get().fetchCommits();
    } catch (error) {
      console.error("Error committing file:", error);
      set({ syncStatus: "disconnected" });
      throw error;
    }
  },
});
