import { ViewMode } from "@/types";

export interface UISlice {
  // View
  viewMode: ViewMode;
  setViewMode: (mode: ViewMode) => void;

  // Sidebar
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
  sidebarWidth: number;
  setSidebarWidth: (width: number) => void;

  // Version panel
  versionPanelOpen: boolean;
  setVersionPanelOpen: (open: boolean) => void;

  // Command palette
  commandPaletteOpen: boolean;
  setCommandPaletteOpen: (open: boolean) => void;

  // Additional Modals State
  settingsModalOpen: boolean;
  setSettingsModalOpen: (open: boolean) => void;
  docsModalOpen: boolean;
  setDocsModalOpen: (open: boolean) => void;
  helpModalOpen: boolean;
  setHelpModalOpen: (open: boolean) => void;

  // PR Modal State
  createPrModalOpen: boolean;
  setCreatePrModalOpen: (open: boolean) => void;
}

export const createUISlice = (set: any): UISlice => ({
  // View
  viewMode: "editor",
  setViewMode: (mode) => set({ viewMode: mode }),

  // Sidebar
  sidebarOpen: true,
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
  sidebarWidth: 260,
  setSidebarWidth: (width) => set({ sidebarWidth: width }),

  // Version panel
  versionPanelOpen: true,
  setVersionPanelOpen: (open) => set({ versionPanelOpen: open }),

  // Command palette
  commandPaletteOpen: false,
  setCommandPaletteOpen: (open) => set({ commandPaletteOpen: open }),

  // Additional Modals State
  settingsModalOpen: false,
  setSettingsModalOpen: (open) => set({ settingsModalOpen: open }),
  docsModalOpen: false,
  setDocsModalOpen: (open) => set({ docsModalOpen: open }),
  helpModalOpen: false,
  setHelpModalOpen: (open) => set({ helpModalOpen: open }),

  // PR Modal State
  createPrModalOpen: false,
  setCreatePrModalOpen: (open) => set({ createPrModalOpen: open }),
});
