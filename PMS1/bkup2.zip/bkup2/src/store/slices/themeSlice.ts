export interface ThemeSlice {
  // Theme Management
  themeMode: "dark" | "light";
  toggleThemeMode: () => void;
}

export const createThemeSlice = (set: any, get: any): ThemeSlice => ({
  // Theme Management
  themeMode: "dark",
  toggleThemeMode: () => {
    const nextTheme = get().themeMode === "dark" ? "light" : "dark";
    if (typeof window !== "undefined") {
      document.body.classList.remove("dark", "light");
      document.body.classList.add(nextTheme);
      localStorage.setItem("prompthub_theme", nextTheme);
    }
    set({ themeMode: nextTheme });
  },
});
