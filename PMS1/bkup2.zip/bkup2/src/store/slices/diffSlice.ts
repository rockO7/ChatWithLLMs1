import { FileNode } from "@/types";
import { getMockCommitParentContent } from "@/lib/storeHelpers";
import { mockFileTree, defaultEditorContent } from "@/data/mock";

export interface DiffSlice {
  // Diff View State
  isDiffViewActive: boolean;
  diffOriginalContent: string;
  diffModifiedContent: string;
  diffFilename: string;
  diffType: "workspace" | "commit";
  diffCommitId?: string;
  openWorkspaceDiff: () => Promise<void>;
  openCommitDiff: (commitId: string, filePath: string) => Promise<void>;
  closeDiffView: () => void;
}

export const createDiffSlice = (set: any, get: any): DiffSlice => ({
  // Diff View State Implementation
  isDiffViewActive: false,
  diffOriginalContent: "",
  diffModifiedContent: "",
  diffFilename: "",
  diffType: "workspace",
  diffCommitId: undefined,

  openWorkspaceDiff: async () => {
    const file = get().selectedFile;
    if (!file) return;

    let original = "";
    const token = get().githubToken;
    const currentRepo = get().currentRepository;
    const currentBranch = get().currentBranch;

    if (token && currentRepo && file.status !== "new") {
      set({ syncStatus: "syncing" });
      try {
        const [owner, repoName] = currentRepo.split("/");
        const cleanPath = file.path.startsWith("/")
          ? file.path.substring(1)
          : file.path;
        const res = await fetch(
          `https://api.github.com/repos/${owner}/${repoName}/contents/${cleanPath}?ref=${currentBranch}`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
              Accept: "application/vnd.github+json",
              "User-Agent": "PromptHub-PMS",
            },
          },
        );
        if (res.ok) {
          const data = await res.json();
          const rawBase64 = data.content.replace(/\s/g, "");
          original = decodeURIComponent(escape(window.atob(rawBase64)));

          // Cache it in tree and selectedFile
          const updateOriginalInTree = (nodes: FileNode[]): FileNode[] => {
            return nodes.map((node) => {
              if (node.id === file.id) {
                return { ...node, originalContent: original };
              }
              if (node.children) {
                return {
                  ...node,
                  children: updateOriginalInTree(node.children),
                };
              }
              return node;
            });
          };
          set((state: any) => ({
            fileTree: updateOriginalInTree(state.fileTree),
            selectedFile:
              state.selectedFile?.id === file.id
                ? { ...state.selectedFile, originalContent: original }
                : state.selectedFile,
          }));
        }
      } catch (error) {
        console.error("Failed to fetch original content for diff:", error);
      } finally {
        set({ syncStatus: "connected" });
      }
    }

    if (!original) {
      original = file.originalContent || "";
    }

    if (!original && file.status !== "new") {
      // Look up original in mockFileTree
      const findInMock = (nodes: FileNode[]): string | null => {
        for (const node of nodes) {
          if (
            node.type === "file" &&
            (node.path === file.path || node.path === "/" + file.path)
          ) {
            return node.content || "";
          }
          if (node.children) {
            const content = findInMock(node.children);
            if (content !== null) return content;
          }
        }
        return null;
      };
      original = findInMock(mockFileTree) || "";
    }

    set({
      isDiffViewActive: true,
      diffOriginalContent: original || "",
      diffModifiedContent: get().editorContent,
      diffFilename: file.name,
      diffType: "workspace",
      diffCommitId: undefined,
    });
  },

  openCommitDiff: async (commitId: string, filePath: string) => {
    const token = get().githubToken;
    const currentRepo = get().currentRepository;

    const filename = filePath.split("/").pop() || filePath;

    const findFileContent = (nodes: FileNode[]): string => {
      for (const node of nodes) {
        if (
          node.type === "file" &&
          (node.path === filePath || node.path === "/" + filePath)
        ) {
          return node.content || "";
        }
        if (node.children) {
          const content = findFileContent(node.children);
          if (content) return content;
        }
      }
      return "";
    };

    const currentWorkspaceContent = findFileContent(get().fileTree);

    if (token && currentRepo) {
      set({ syncStatus: "syncing" });
      try {
        const [owner, repo] = currentRepo.split("/");

        const commitRes = await fetch(
          `https://api.github.com/repos/${owner}/${repo}/commits/${commitId}`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
              Accept: "application/vnd.github+json",
              "User-Agent": "PromptHub-PMS",
            },
          },
        );

        if (!commitRes.ok) throw new Error("Failed to fetch commit details");
        const commitData = await commitRes.json();
        const parentSha = commitData.parents?.[0]?.sha;

        const fileCommitRes = await fetch(
          `https://api.github.com/repos/${owner}/${repo}/contents/${filePath}?ref=${commitId}`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
              Accept: "application/vnd.github+json",
              "User-Agent": "PromptHub-PMS",
            },
          },
        );

        let commitContent = "";
        if (fileCommitRes.ok) {
          const data = await fileCommitRes.json();
          const rawBase64 = data.content.replace(/\s/g, "");
          commitContent = decodeURIComponent(escape(window.atob(rawBase64)));
        }

        let parentContent = "";
        if (parentSha) {
          const fileParentRes = await fetch(
            `https://api.github.com/repos/${owner}/${repo}/contents/${filePath}?ref=${parentSha}`,
            {
              headers: {
                Authorization: `Bearer ${token}`,
                Accept: "application/vnd.github+json",
                "User-Agent": "PromptHub-PMS",
              },
            },
          );
          if (fileParentRes.ok) {
            const data = await fileParentRes.json();
            const rawBase64 = data.content.replace(/\s/g, "");
            parentContent = decodeURIComponent(
              escape(window.atob(rawBase64)),
            );
          }
        }

        set({
          isDiffViewActive: true,
          diffOriginalContent: parentContent,
          diffModifiedContent: commitContent,
          diffFilename: filename,
          diffType: "commit",
          diffCommitId: commitId.substring(0, 7),
          syncStatus: "connected",
        });
      } catch (err) {
        console.error("Error fetching commit diff:", err);
        set({ syncStatus: "disconnected" });
        get().addToast({
          type: "error",
          title: "Diff Fetch Failed",
          message: "Could not retrieve commit content from GitHub.",
        });
      }
    } else {
      const commit = get().commits.find((c: any) => c.id === commitId);
      const commitHash = commit?.hash || commitId.substring(0, 7);
      const modifiedContent = currentWorkspaceContent || defaultEditorContent;
      const originalContent = getMockCommitParentContent(
        commitId,
        filePath,
        modifiedContent,
      );

      set({
        isDiffViewActive: true,
        diffOriginalContent: originalContent,
        diffModifiedContent: modifiedContent,
        diffFilename: filename,
        diffType: "commit",
        diffCommitId: commitHash,
      });
    }
  },

  closeDiffView: () => {
    set({ isDiffViewActive: false });
  },
});
