export interface SyncSlice {
  // Sync status
  syncStatus: "connected" | "syncing" | "disconnected";
  lastSaved: Date | null;
}

export const createSyncSlice = (set: any): SyncSlice => ({
  // Sync
  syncStatus: "connected",
  lastSaved: new Date("2026-06-05T09:15:00"),
});
