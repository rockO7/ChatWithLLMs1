import { buildFileTreeFromGitTree, saveFileTreeToLocal } from "@/lib/storeHelpers";

export interface BranchSlice {
  // Git Branch Management
  currentBranch: string;
  branches: string[];
  selectBranch: (branchName: string) => Promise<void>;
  createBranch: (branchName: string) => Promise<void>;
  fetchBranches: () => Promise<void>;
}

export const createBranchSlice = (set: any, get: any): BranchSlice => ({
  // Git Branch Management Implementation
  currentBranch: "main",
  branches: ["main"],

  fetchBranches: async () => {
    const token = get().githubToken;
    const currentRepo = get().currentRepository;
    if (!token || !currentRepo) {
      set({ branches: ["main", "dev", "feature/auth"] });
      return;
    }

    try {
      const [owner, repo] = currentRepo.split("/");
      const res = await fetch(
        `https://api.github.com/repos/${owner}/${repo}/branches?per_page=100`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            Accept: "application/vnd.github+json",
            "User-Agent": "PromptHub-PMS",
          },
        },
      );

      if (res.ok) {
        const data = await res.json();
        const branchNames = data.map((b: { name: string }) => b.name);
        set({ branches: branchNames });
      }
    } catch (error) {
      console.error("Failed to fetch branches:", error);
    }
  },

  selectBranch: async (branchName) => {
    const token = get().githubToken;
    const currentRepo = get().currentRepository;
    if (!currentRepo) return;

    set({
      currentBranch: branchName,
      syncStatus: "syncing",
      selectedFile: null,
    });

    if (!token) {
      set({ syncStatus: "connected" });
      get().initializeSelection();
      return;
    }

    try {
      const [owner, repo] = currentRepo.split("/");
      const treeRes = await fetch(
        `https://api.github.com/repos/${owner}/${repo}/git/trees/${branchName}?recursive=1`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            Accept: "application/vnd.github+json",
            "User-Agent": "PromptHub-PMS",
          },
        },
      );

      if (!treeRes.ok)
        throw new Error("Failed to fetch repository tree for branch");
      const treeData = await treeRes.json();
      const convertedTree = buildFileTreeFromGitTree(treeData.tree || []);

      set({
        fileTree: convertedTree,
        syncStatus: "connected",
      });

      saveFileTreeToLocal(currentRepo, convertedTree);
      await get().fetchCommits();
      get().initializeSelection();
    } catch (error) {
      console.error("Error selecting branch:", error);
      set({ syncStatus: "disconnected" });
    }
  },

  createBranch: async (branchName) => {
    const token = get().githubToken;
    const currentRepo = get().currentRepository;
    const currentBranch = get().currentBranch;
    if (!currentRepo) return;

    set({ syncStatus: "syncing" });

    if (!token) {
      set((state: any) => ({
        branches: [...state.branches, branchName],
        currentBranch: branchName,
        syncStatus: "connected",
      }));
      get().addToast({
        type: "success",
        title: "Branch Created",
        message: `Simulated branch '${branchName}' created successfully.`,
      });
      return;
    }

    try {
      const [owner, repo] = currentRepo.split("/");
      const refRes = await fetch(
        `https://api.github.com/repos/${owner}/${repo}/git/ref/heads/${currentBranch}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            Accept: "application/vnd.github+json",
            "User-Agent": "PromptHub-PMS",
          },
        },
      );
      if (!refRes.ok) throw new Error("Failed to get current branch SHA");
      const refData = await refRes.json();
      const sha = refData.object.sha;

      const createRefRes = await fetch(
        `https://api.github.com/repos/${owner}/${repo}/git/refs`,
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
            Accept: "application/vnd.github+json",
            "User-Agent": "PromptHub-PMS",
          },
          body: JSON.stringify({
            ref: `refs/heads/${branchName}`,
            sha: sha,
          }),
        },
      );

      if (!createRefRes.ok) {
        const errData = await createRefRes.json();
        throw new Error(
          errData.message || "Failed to create branch on GitHub",
        );
      }

      get().addToast({
        type: "success",
        title: "Branch Created",
        message: `Branch '${branchName}' created from '${currentBranch}' successfully.`,
      });

      set((state: any) => ({
        branches: [...state.branches, branchName],
      }));
      await get().selectBranch(branchName);
    } catch (error) {
      console.error("Error creating branch:", error);
      set({ syncStatus: "disconnected" });
      get().addToast({
        type: "error",
        title: "Branch Creation Failed",
        message: (error as Error).message,
      });
    }
  },
});
