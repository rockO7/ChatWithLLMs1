import { TestRun, ModelConfig } from "@/types";
import { mockModels } from "@/data/mock";

export interface TestingSlice {
  // Testing
  testRuns: TestRun[];
  models: ModelConfig[];
  toggleModel: (id: string) => void;
  isRunningTest: boolean;
  setIsRunningTest: (running: boolean) => void;
  addTestRun: (run: TestRun) => void;
  clearTestRuns: () => void;
  setTestRunRating: (id: string, rating: "up" | "down") => void;
}

export const createTestingSlice = (set: any): TestingSlice => ({
  // Testing
  testRuns: [],
  models: mockModels,
  toggleModel: (id) =>
    set((state: any) => ({
      models: state.models.map((m: ModelConfig) =>
        m.id === id ? { ...m, selected: !m.selected } : m,
      ),
    })),
  isRunningTest: false,
  setIsRunningTest: (running) => set({ isRunningTest: running }),
  addTestRun: (run) =>
    set((state: any) => ({ testRuns: [run, ...state.testRuns] })),
  clearTestRuns: () => set({ testRuns: [] }),
  setTestRunRating: (id, rating) =>
    set((state: any) => ({
      testRuns: state.testRuns.map((t: TestRun) =>
        t.id === id ? { ...t, rating } : t,
      ),
    })),
});
