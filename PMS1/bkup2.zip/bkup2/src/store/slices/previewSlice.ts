import { PreviewMode } from "@/types";

export interface PreviewSlice {
  // Preview
  previewMode: PreviewMode;
  setPreviewMode: (mode: PreviewMode) => void;
  previewPanelOpen: boolean;
  setPreviewPanelOpen: (open: boolean) => void;
}

export const createPreviewSlice = (set: any): PreviewSlice => ({
  // Preview
  previewMode: "raw",
  setPreviewMode: (mode) => set({ previewMode: mode }),
  previewPanelOpen: true,
  setPreviewPanelOpen: (open) => set({ previewPanelOpen: open }),
});
