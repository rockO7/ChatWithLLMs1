import { RepositoryData, mockRepositories } from "@/data/mock";
import { FileNode } from "@/types";
import { buildFileTreeFromGitTree, saveFileTreeToLocal } from "@/lib/storeHelpers";

export interface RepositorySlice {
  // Repository Management
  currentRepository: string | null;
  selectRepository: (repoName: string | null) => Promise<void>;
  repositories: RepositoryData[];
}

export const createRepositorySlice = (set: any, get: any): RepositorySlice => ({
  // Repository Management
  currentRepository: null,
  selectRepository: async (repoName) => {
    if (!repoName) {
      set({ currentRepository: null, selectedFile: null, fileTree: [] });
      if (typeof window !== "undefined") {
        localStorage.removeItem("prompthub_current_repository");
      }
      return;
    }

    if (typeof window !== "undefined") {
      localStorage.setItem("prompthub_current_repository", repoName);
    }

    // Check if there is a cached tree in localStorage first
    let cachedTree: FileNode[] | null = null;
    if (typeof window !== "undefined") {
      const cachedTreeStr = localStorage.getItem(
        `prompthub_file_tree:${repoName}`,
      );
      if (cachedTreeStr) {
        try {
          cachedTree = JSON.parse(cachedTreeStr);
        } catch (e) {
          console.error("Failed to parse cached file tree:", e);
        }
      }
    }

    if (!cachedTree) {
      const mockRepo = mockRepositories.find((r) => r.name === repoName);
      if (mockRepo) {
        cachedTree = mockRepo.fileTree;
      }
    }

    if (cachedTree) {
      set({
        currentRepository: repoName,
        fileTree: cachedTree,
        selectedFile: null,
      });
      get().initializeSelection();
    }

    const token = get().githubToken;
    if (!token) {
      set({ syncStatus: "connected" });
      return;
    }

    set({
      currentRepository: repoName,
      syncStatus: "syncing",
      ...(cachedTree ? {} : { selectedFile: null }),
    });
    try {
      const [owner, repo] = repoName.split("/");
      // Fetch repo info to get default branch
      const repoInfoRes = await fetch(
        `https://api.github.com/repos/${owner}/${repo}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            Accept: "application/vnd.github+json",
            "User-Agent": "PromptHub-PMS",
          },
        },
      );
      if (!repoInfoRes.ok) throw new Error("Failed to fetch repository info");
      const repoInfo = await repoInfoRes.json();
      const branch = repoInfo.default_branch || "main";

      set({ currentBranch: branch });
      await get().fetchBranches();

      // Fetch recursive git tree
      const treeRes = await fetch(
        `https://api.github.com/repos/${owner}/${repo}/git/trees/${branch}?recursive=1`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            Accept: "application/vnd.github+json",
            "User-Agent": "PromptHub-PMS",
          },
        },
      );

      if (!treeRes.ok) throw new Error("Failed to fetch repository tree");
      const treeData = await treeRes.json();

      // Convert tree data to FileNode[]
      const convertedTree = buildFileTreeFromGitTree(treeData.tree || []);

      // Apply local drafts & keep local status if modified or new
      const applyDraftsAndStatus = (nodes: FileNode[]): FileNode[] => {
        return nodes.map((node) => {
          if (typeof window !== "undefined" && node.type === "file") {
            try {
              const draftsStr =
                localStorage.getItem("prompthub_drafts") || "{}";
              const drafts = JSON.parse(draftsStr);
              const draftContent = drafts[`${repoName}:${node.path}`];
              if (draftContent !== undefined) {
                return {
                  ...node,
                  content: draftContent,
                  status: "modified",
                };
              }
            } catch (e) {
              console.error("Error applying draft:", e);
            }
          }
          if (node.children) {
            return {
              ...node,
              children: applyDraftsAndStatus(node.children),
            };
          }
          return node;
        });
      };

      const finalTree = applyDraftsAndStatus(convertedTree);

      set({
        fileTree: finalTree,
        syncStatus: "connected",
      });

      saveFileTreeToLocal(repoName, finalTree);

      // Load commits history
      await get().fetchCommits();

      // Auto-select first file if nothing selected
      if (!get().selectedFile) {
        get().initializeSelection();
      }
    } catch (error) {
      console.error("Error selecting repository:", error);
      set({
        syncStatus: "disconnected",
        ...(cachedTree ? {} : { fileTree: [] }),
      });
    }
  },
  repositories: mockRepositories,
});
