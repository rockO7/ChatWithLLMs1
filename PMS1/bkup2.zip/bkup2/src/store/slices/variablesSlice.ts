import { extractVariables } from "@/lib/utils";
import { defaultEditorContent } from "@/data/mock";

export interface VariablesSlice {
  // Variables
  variables: Record<string, string>;
  setVariable: (name: string, value: string) => void;
  detectedVariables: string[];
}

export const createVariablesSlice = (set: any): VariablesSlice => ({
  // Variables
  variables: {},
  setVariable: (name, value) =>
    set((state: any) => ({
      variables: { ...state.variables, [name]: value },
    })),
  detectedVariables: extractVariables(defaultEditorContent),
});
