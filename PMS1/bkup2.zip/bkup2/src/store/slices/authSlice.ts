import { RepositoryData, mockRepositories } from "@/data/mock";
import { deobfuscateKey } from "@/lib/storeHelpers";
import { FileNode } from "@/types";

export interface AuthSlice {
  // Authentication & Session
  githubToken: string | null;
  user: { name: string; avatar_url: string; login: string } | null;
  isAuthenticated: boolean;
  checkSession: () => Promise<void>;
  login: () => void;
  logout: () => Promise<void>;
  fetchRepositories: () => Promise<void>;
}

export const createAuthSlice = (set: any, get: any): AuthSlice => ({
  // Authentication & Session Implementation
  githubToken: null,
  user: null,
  isAuthenticated: false,

  checkSession: async () => {
    // 1. Load theme from localStorage
    if (typeof window !== "undefined") {
      const savedTheme = localStorage.getItem("prompthub_theme");
      if (savedTheme === "light" || savedTheme === "dark") {
        set({ themeMode: savedTheme as "dark" | "light" });
        document.body.classList.remove("dark", "light");
        document.body.classList.add(savedTheme);
      }
    }

    // 1b. Load editor settings from localStorage
    if (typeof window !== "undefined") {
      const savedSettings = localStorage.getItem("prompthub_editor_settings");
      if (savedSettings) {
        try {
          const parsed = JSON.parse(savedSettings);
          if (parsed.openaiKey)
            parsed.openaiKey = deobfuscateKey(parsed.openaiKey);
          if (parsed.anthropicKey)
            parsed.anthropicKey = deobfuscateKey(parsed.anthropicKey);
          set({ editorSettings: { ...get().editorSettings, ...parsed } });
        } catch (e) {
          console.error("Failed to parse editor settings:", e);
        }
      }
    }

    // 2. Load last selected repository from localStorage
    let savedRepo: string | null = null;
    if (typeof window !== "undefined") {
      savedRepo = localStorage.getItem("prompthub_current_repository");
    }

    // 3. Perform check session
    try {
      const res = await fetch("/api/auth/user");
      if (res.ok) {
        const data = await res.json();
        if (data.authenticated) {
          set({
            isAuthenticated: true,
            user: data.user,
            githubToken: data.token,
          });
          // Fetch repos
          await get().fetchRepositories();
        } else {
          set({
            isAuthenticated: false,
            user: null,
            githubToken: null,
            repositories: mockRepositories,
          });
        }
      } else {
        set({
          isAuthenticated: false,
          user: null,
          githubToken: null,
          repositories: mockRepositories,
        });
      }
    } catch (err) {
      console.error("Failed to check session:", err);
      set({
        isAuthenticated: false,
        user: null,
        githubToken: null,
        repositories: mockRepositories,
      });
    }

    // 4. Hydrate repository and select it if saved
    if (savedRepo) {
      let cachedTree: FileNode[] | null = null;
      if (typeof window !== "undefined") {
        const cachedTreeStr = localStorage.getItem(
          `prompthub_file_tree:${savedRepo}`,
        );
        if (cachedTreeStr) {
          try {
            cachedTree = JSON.parse(cachedTreeStr);
          } catch (e) {
            console.error("Failed to parse cached tree on session check:", e);
          }
        }
      }

      if (cachedTree) {
        set({ currentRepository: savedRepo, fileTree: cachedTree });
        get().initializeSelection();
      } else {
        await get().selectRepository(savedRepo);
      }
    } else {
      get().initializeSelection();
    }
  },

  login: () => {
    if (typeof window !== "undefined") {
      window.location.href = "/api/auth/login";
    }
  },

  logout: async () => {
    try {
      await fetch("/api/auth/logout");
    } catch (err) {
      console.error("Failed to call logout route:", err);
    }
    set({
      githubToken: null,
      user: null,
      isAuthenticated: false,
      currentRepository: null,
      fileTree: [],
      selectedFile: null,
      commits: [],
      repositories: mockRepositories,
    });
    if (typeof window !== "undefined") {
      window.location.href = "/";
    }
  },

  fetchRepositories: async () => {
    const token = get().githubToken;
    if (!token) return;

    try {
      const res = await fetch(
        "https://api.github.com/user/repos?sort=updated&per_page=50",
        {
          headers: {
            Authorization: `Bearer ${token}`,
            Accept: "application/vnd.github+json",
            "User-Agent": "PromptHub-PMS",
          },
        },
      );

      if (res.ok) {
        const data = await res.json();
        const { timeAgo } = await import("@/lib/utils");
        const formatted: RepositoryData[] = data.map(
          (r: {
            full_name: string;
            description?: string;
            default_branch?: string;
            updated_at: string;
            stargazers_count?: number;
          }) => ({
            name: r.full_name,
            description: r.description || "No description provided.",
            promptCount: 0,
            branch: r.default_branch || "main",
            lastModified: timeAgo(new Date(r.updated_at)),
            fileTree: [],
            stars: r.stargazers_count || 0,
          }),
        );
        set({ repositories: formatted });
      }
    } catch (error) {
      console.error("Failed to fetch user repositories:", error);
    }
  },
});
