export interface PrSlice {
  // PR Modal State
  createPrModalOpen: boolean;
  setCreatePrModalOpen: (open: boolean) => void;
  submitPullRequest: (
    title: string,
    desc: string,
    base: string,
    compare: string,
  ) => Promise<{ html_url?: string; number?: number }>;
}

export const createPrSlice = (set: any, get: any): PrSlice => ({
  // PR Modal State Implementation
  createPrModalOpen: false,
  setCreatePrModalOpen: (open) => set({ createPrModalOpen: open }),

  submitPullRequest: async (title, desc, base, compare) => {
    const token = get().githubToken;
    const currentRepo = get().currentRepository;

    if (token && currentRepo) {
      set({ syncStatus: "syncing" });
      try {
        const [owner, repo] = currentRepo.split("/");
        const res = await fetch(
          `https://api.github.com/repos/${owner}/${repo}/pulls`,
          {
            method: "POST",
            headers: {
              Authorization: `Bearer ${token}`,
              "Content-Type": "application/json",
              Accept: "application/vnd.github+json",
              "User-Agent": "PromptHub-PMS",
            },
            body: JSON.stringify({
              title,
              body: desc,
              head: compare,
              base: base,
            }),
          },
        );

        if (!res.ok) {
          const errData = await res.json();
          let errMsg = errData.message || "Failed to create PR";
          if (errData.errors && Array.isArray(errData.errors)) {
            const details = errData.errors
              .map(
                (e: { message?: string; code?: string }) =>
                  e.message || e.code,
              )
              .filter(Boolean)
              .join(", ");
            if (details) {
              errMsg = `${errMsg}: ${details}`;
            }
          }
          throw new Error(errMsg);
        }

        const prData = await res.json();
        set({ syncStatus: "connected" });
        get().addToast({
          type: "success",
          title: "PR Created Successfully",
          message: `Created pull request #${prData.number} on GitHub.`,
        });
        return { html_url: prData.html_url, number: prData.number };
      } catch (err) {
        console.error("Error creating PR:", err);
        set({ syncStatus: "disconnected" });
        get().addToast({
          type: "error",
          title: "PR Creation Failed",
          message: (err as Error).message,
        });
        throw err;
      }
    } else {
      return new Promise((resolve) => {
        setTimeout(() => {
          const prNum = Math.floor(Math.random() * 200) + 100;
          get().addToast({
            type: "success",
            title: "Mock PR Created",
            message: `Pull Request #${prNum} '${title}' simulated successfully!`,
          });
          resolve({
            html_url: `https://github.com/mock-owner/mock-repo/pull/${prNum}`,
            number: prNum,
          });
        }, 1200);
      });
    }
  },
});
