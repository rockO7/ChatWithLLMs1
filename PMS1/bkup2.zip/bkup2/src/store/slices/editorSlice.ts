import { FileNode } from "@/types";
import { saveFileTreeToLocal, obfuscateKey } from "@/lib/storeHelpers";
import { extractVariables } from "@/lib/utils";
import { defaultEditorContent } from "@/data/mock";

export interface EditorSlice {
  // Editor
  editorContent: string;
  setEditorContent: (content: string) => void;
  isDirty: boolean;
  setIsDirty: (dirty: boolean) => void;

  // Editor Settings
  editorSettings: {
    fontSize: number;
    wordWrap: "on" | "off";
    minimap: boolean;
    openaiKey: string;
    anthropicKey: string;
    commitPrefix: string;
  };
  setEditorSettings: (settings: Partial<EditorSlice["editorSettings"]>) => void;
}

export const createEditorSlice = (set: any, get: any): EditorSlice => ({
  // Editor
  editorContent: defaultEditorContent,
  setEditorContent: (content) => {
    const vars = extractVariables(content);
    const currentVars = get().variables;
    const newVars: Record<string, string> = {};
    vars.forEach((v) => {
      newVars[v] = currentVars[v] || "";
    });

    const selectedFile = get().selectedFile;
    let updatedTree = get().fileTree;
    let updatedSelectedFile = selectedFile;

    if (selectedFile) {
      updatedSelectedFile = {
        ...selectedFile,
        content: content,
        status: selectedFile.status === "new" ? "new" : "modified",
        lastModified: new Date(),
      };

      const updateContentInTree = (nodes: FileNode[]): FileNode[] => {
        return nodes.map((node) => {
          if (node.id === selectedFile.id) {
            return {
              ...node,
              content: content,
              status: node.status === "new" ? "new" : "modified",
              lastModified: new Date(),
            };
          }
          if (node.children) {
            return {
              ...node,
              children: updateContentInTree(node.children),
            };
          }
          return node;
        });
      };
      updatedTree = updateContentInTree(get().fileTree);

      // Save to drafts in localStorage
      const currentRepo = get().currentRepository;
      if (currentRepo && typeof window !== "undefined") {
        try {
          const draftsStr = localStorage.getItem("prompthub_drafts") || "{}";
          const drafts = JSON.parse(draftsStr);
          drafts[`${currentRepo}:${selectedFile.path}`] = content;
          localStorage.setItem("prompthub_drafts", JSON.stringify(drafts));
        } catch (e) {
          console.error("Failed to save draft:", e);
        }
      }
    }

    set({
      editorContent: content,
      isDirty: true,
      detectedVariables: vars,
      variables: { ...currentVars, ...newVars },
      selectedFile: updatedSelectedFile,
      fileTree: updatedTree,
    });

    saveFileTreeToLocal(get().currentRepository, updatedTree);
  },
  isDirty: false,
  setIsDirty: (dirty) => set({ isDirty: dirty }),

  // Editor Settings
  editorSettings: {
    fontSize: 13,
    wordWrap: "on",
    minimap: false,
    openaiKey: "",
    anthropicKey: "",
    commitPrefix: "feat: ",
  },
  setEditorSettings: (settings) => {
    const updated = { ...get().editorSettings, ...settings };
    set({ editorSettings: updated });
    if (typeof window !== "undefined") {
      const toSave = { ...updated };
      if (toSave.openaiKey) toSave.openaiKey = obfuscateKey(toSave.openaiKey);
      if (toSave.anthropicKey)
        toSave.anthropicKey = obfuscateKey(toSave.anthropicKey);
      localStorage.setItem(
        "prompthub_editor_settings",
        JSON.stringify(toSave),
      );
    }
  },
});
