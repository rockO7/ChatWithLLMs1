export interface ToastSlice {
  // Toasts
  toasts: Array<{
    id: string;
    type: "success" | "error" | "info";
    title: string;
    message: string;
  }>;
  addToast: (toast: {
    type: "success" | "error" | "info";
    title: string;
    message: string;
  }) => void;
  removeToast: (id: string) => void;
}

export const createToastSlice = (set: any, get: any): ToastSlice => ({
  // Toasts State Implementation
  toasts: [],
  addToast: (toast) => {
    const id = Math.random().toString(36).substring(7);
    const newToast = { ...toast, id };
    set((state: any) => ({ toasts: [...state.toasts, newToast] }));

    setTimeout(() => {
      get().removeToast(id);
    }, 4000);
  },
  removeToast: (id) => {
    set((state: any) => ({ toasts: state.toasts.filter((t: any) => t.id !== id) }));
  },
});
