import { FileNode } from "@/types";
import { saveFileTreeToLocal, utf8_to_b64 } from "@/lib/storeHelpers";
import { findParentPath } from "@/lib/utils";

export interface FileTreeSlice {
  // File tree
  fileTree: FileNode[];
  selectedFile: FileNode | null;
  expandedFolders: Set<string>;
  setSelectedFile: (file: FileNode | null) => Promise<void>;
  toggleFolder: (folderId: string) => void;
  initializeSelection: () => void;

  // Folder & File Creation
  createFile: (parentId: string | null, name: string, content?: string) => void;
  createFolder: (parentId: string | null, name: string) => void;
  resetSelectedFileChanges: () => Promise<void>;
}

export const createFileTreeSlice = (set: any, get: any): FileTreeSlice => {
  const fallbackLocalCreateFile = (parentId: string | null, name: string, content?: string) => {
    const newFile: FileNode = {
      id: Math.random().toString(36).substring(7),
      name: name,
      type: "file",
      path: parentId ? `temp_${parentId}/${name}` : `/${name}`,
      status: "new",
      extension: name.split(".").pop() || "md",
      content: content !== undefined ? content : `# ${name.split(".")[0]}\n\nNew file content template.`,
      lastModified: new Date(),
    };

    const tree = [...get().fileTree];

    if (!parentId) {
      const updatedTree = [...tree, newFile];
      set({
        fileTree: updatedTree,
        selectedFile: newFile,
        editorContent: newFile.content || "",
      });
      saveFileTreeToLocal(get().currentRepository, updatedTree);
      return;
    }

    const addNode = (nodes: FileNode[]): boolean => {
      for (const node of nodes) {
        if (node.id === parentId && node.type === "folder") {
          node.children = node.children
            ? [...node.children, newFile]
            : [newFile];
          return true;
        }
        if (node.children && addNode(node.children)) {
          return true;
        }
      }
      return false;
    };

    if (addNode(tree)) {
      set({
        fileTree: tree,
        selectedFile: newFile,
        editorContent: newFile.content || "",
      });
      saveFileTreeToLocal(get().currentRepository, tree);
    }
  };

  const fallbackLocalCreateFolder = (parentId: string | null, name: string) => {
    const newFolder: FileNode = {
      id: Math.random().toString(36).substring(7),
      name: name,
      type: "folder",
      path: parentId ? `temp_${parentId}/${name}` : `/${name}`,
      children: [],
    };

    const tree = [...get().fileTree];

    if (!parentId) {
      const updatedTree = [...tree, newFolder];
      set({ fileTree: updatedTree });
      saveFileTreeToLocal(get().currentRepository, updatedTree);
      return;
    }

    const addNode = (nodes: FileNode[]): boolean => {
      for (const node of nodes) {
        if (node.id === parentId && node.type === "folder") {
          node.children = node.children
            ? [...node.children, newFolder]
            : [newFolder];
          return true;
        }
        if (node.children && addNode(node.children)) {
          return true;
        }
      }
      return false;
    };

    if (addNode(tree)) {
      set({ fileTree: tree });
      saveFileTreeToLocal(get().currentRepository, tree);
    }
  };

  return {
    // File tree
    fileTree: [],
    selectedFile: null,
    expandedFolders: new Set(),
    setSelectedFile: async (file) => {
      if (!file) {
        set({ selectedFile: null, editorContent: "" });
        return;
      }

      if (file.type === "folder") {
        return;
      }

      const token = get().githubToken;
      const currentRepo = get().currentRepository;

      // If live repo and file content needs fetching
      if (token && currentRepo && file.status !== "new" && !file.content) {
        // Check if we have a draft first!
        let draftContent: string | undefined = undefined;
        if (typeof window !== "undefined") {
          try {
            const draftsStr = localStorage.getItem("prompthub_drafts") || "{}";
            const drafts = JSON.parse(draftsStr);
            draftContent = drafts[`${currentRepo}:${file.path}`];
          } catch (e) {
            console.error("Error reading draft:", e);
          }
        }

        if (draftContent !== undefined) {
          const { extractVariables } = await import("@/lib/utils");
          const vars = extractVariables(draftContent);
          const currentVars = get().variables;
          const newVars: Record<string, string> = {};
          vars.forEach((v: string) => {
            newVars[v] = currentVars[v] || "";
          });

          const updateContentInTree = (nodes: FileNode[]): FileNode[] => {
            return nodes.map((node) => {
              if (node.id === file.id) {
                return {
                  ...node,
                  content: draftContent,
                  status: "modified",
                };
              }
              if (node.children) {
                return {
                  ...node,
                  children: updateContentInTree(node.children),
                };
              }
              return node;
            });
          };

          const updatedTree = updateContentInTree(get().fileTree);
          set({
            fileTree: updatedTree,
            selectedFile: {
              ...file,
              content: draftContent,
              status: "modified",
            },
            editorContent: draftContent,
            isDirty: true,
            detectedVariables: vars,
            variables: { ...currentVars, ...newVars },
            syncStatus: "connected",
          });
          saveFileTreeToLocal(currentRepo, updatedTree);
          return;
        }

        set({ syncStatus: "syncing" });
        try {
          const [owner, repoName] = currentRepo.split("/");
          const cleanPath = file.path.startsWith("/")
            ? file.path.substring(1)
            : file.path;

          const res = await fetch(
            `https://api.github.com/repos/${owner}/${repoName}/contents/${cleanPath}`,
            {
              headers: {
                Authorization: `Bearer ${token}`,
                Accept: "application/vnd.github+json",
                "User-Agent": "PromptHub-PMS",
              },
            },
          );

          if (res.ok) {
            const data = await res.json();
            const rawBase64 = data.content.replace(/\s/g, "");
            const decodedContent = decodeURIComponent(
              escape(window.atob(rawBase64)),
            );

            // Update content in tree
            const updateContentInTree = (nodes: FileNode[]): FileNode[] => {
              return nodes.map((node) => {
                if (node.id === file.id) {
                  return {
                    ...node,
                    content: decodedContent,
                    originalContent: decodedContent,
                    sha: data.sha,
                    status: "synced",
                  };
                }
                if (node.children) {
                  return {
                    ...node,
                    children: updateContentInTree(node.children),
                  };
                }
                return node;
              });
            };

            const updatedTree = updateContentInTree(get().fileTree);
            const { extractVariables } = await import("@/lib/utils");
            const vars = extractVariables(decodedContent);
            const currentVars = get().variables;
            const newVars: Record<string, string> = {};
            vars.forEach((v: string) => {
              newVars[v] = currentVars[v] || "";
            });

            set({
              fileTree: updatedTree,
              selectedFile: {
                ...file,
                content: decodedContent,
                originalContent: decodedContent,
                sha: data.sha,
                status: "synced",
              },
              editorContent: decodedContent,
              isDirty: false,
              detectedVariables: vars,
              variables: { ...currentVars, ...newVars },
              syncStatus: "connected",
            });
            saveFileTreeToLocal(currentRepo, updatedTree);
            return;
          }
        } catch (error) {
          console.error("Error fetching file content:", error);
          set({ syncStatus: "disconnected" });
        }
      }

      // Fallback/standard behavior (content already present or new local file)
      let content = file.content || "";
      let originalContent = file.originalContent;
      if (!originalContent && file.status !== "new") {
        originalContent = file.content || "";
      }
      let draftContent: string | undefined = undefined;
      if (typeof window !== "undefined" && currentRepo) {
        try {
          const draftsStr = localStorage.getItem("prompthub_drafts") || "{}";
          const drafts = JSON.parse(draftsStr);
          draftContent = drafts[`${currentRepo}:${file.path}`];
        } catch (e) {
          console.error("Error reading draft:", e);
        }
      }

      if (draftContent !== undefined) {
        content = draftContent;
      }

      const { extractVariables } = await import("@/lib/utils");
      const vars = extractVariables(content);
      const currentVars = get().variables;
      const newVars: Record<string, string> = {};
      vars.forEach((v: string) => {
        newVars[v] = currentVars[v] || "";
      });

      set({
        selectedFile: {
          ...file,
          content: content,
          originalContent: originalContent,
          status:
            draftContent !== undefined ? "modified" : file.status || "synced",
        },
        editorContent: content,
        isDirty: draftContent !== undefined,
        detectedVariables: vars,
        variables: { ...currentVars, ...newVars },
      });
    },

    toggleFolder: (folderId) => {
      const expanded = new Set(get().expandedFolders);
      if (expanded.has(folderId)) {
        expanded.delete(folderId);
      } else {
        expanded.add(folderId);
      }
      set({ expandedFolders: expanded });
    },

    // Initialize with first file selected
    initializeSelection: () => {
      const tree = get().fileTree;
      const findFirstFile = (nodes: FileNode[]): FileNode | null => {
        for (const node of nodes) {
          if (node.type === "file") return node;
          if (node.children) {
            const found = findFirstFile(node.children);
            if (found) return found;
          }
        }
        return null;
      };
      const firstFile = findFirstFile(tree);
      if (firstFile) {
        get().setSelectedFile(firstFile);
      }
    },

    // Folder & File Creation
    createFile: (parentId: string | null, name: string, content?: string) => {
      const token = get().githubToken;
      const currentRepo = get().currentRepository;
      const initialContent = content !== undefined ? content : `# ${name.split(".")[0]}\n\nNew file content template.`;

      if (token && currentRepo) {
        let parentPath = "";
        if (parentId) {
          const pPath = findParentPath(get().fileTree, parentId);
          if (pPath) parentPath = pPath;
        }

        let cleanParent = parentPath.startsWith("/")
          ? parentPath.substring(1)
          : parentPath;
        if (cleanParent && !cleanParent.endsWith("/")) cleanParent += "/";
        const filePath = `${cleanParent}${name}`;

        set({ syncStatus: "syncing" });
        const [owner, repo] = currentRepo.split("/");
        fetch(
          `https://api.github.com/repos/${owner}/${repo}/contents/${filePath}`,
          {
            method: "PUT",
            headers: {
              Authorization: `Bearer ${token}`,
              "Content-Type": "application/json",
              Accept: "application/vnd.github+json",
              "User-Agent": "PromptHub-PMS",
            },
            body: JSON.stringify({
              message: `Create ${name}`,
              content: utf8_to_b64(initialContent),
            }),
          },
        )
          .then((res) => {
            if (!res.ok) throw new Error("Failed to create file on Github");
            return res.json();
          })
          .then(async (data) => {
            const newFile: FileNode = {
              id: data.content.sha || Math.random().toString(36).substring(7),
              name: name,
              type: "file",
              path: "/" + filePath,
              status: "synced",
              sha: data.content.sha,
              extension: name.split(".").pop() || "md",
              content: initialContent,
              lastModified: new Date(),
            };

            const tree = [...get().fileTree];

            if (!parentId) {
              const updatedTree = [...tree, newFile];
              set({
                fileTree: updatedTree,
                selectedFile: newFile,
                editorContent: newFile.content || "",
                syncStatus: "connected",
              });
              saveFileTreeToLocal(currentRepo, updatedTree);
            } else {
              const addNode = (nodes: FileNode[]): boolean => {
                for (const node of nodes) {
                  if (node.id === parentId && node.type === "folder") {
                    node.children = node.children
                      ? [...node.children, newFile]
                      : [newFile];
                    return true;
                  }
                  if (node.children && addNode(node.children)) {
                    return true;
                  }
                }
                return false;
              };

              if (addNode(tree)) {
                set({
                  fileTree: tree,
                  selectedFile: newFile,
                  editorContent: newFile.content || "",
                  syncStatus: "connected",
                });
                saveFileTreeToLocal(currentRepo, tree);
              }
            }
            await get().fetchCommits();
          })
          .catch((err) => {
            console.error("Error creating live file:", err);
            set({ syncStatus: "disconnected" });
            alert(
              "Failed to create file on GitHub. Creating local draft instead.",
            );
            fallbackLocalCreateFile(parentId, name, content);
          });
      } else {
        fallbackLocalCreateFile(parentId, name, content);
      }
    },

    createFolder: (parentId, name) => {
      const token = get().githubToken;
      const currentRepo = get().currentRepository;

      if (token && currentRepo) {
        let parentPath = "";
        if (parentId) {
          const pPath = findParentPath(get().fileTree, parentId);
          if (pPath) parentPath = pPath;
        }

        let cleanParent = parentPath.startsWith("/")
          ? parentPath.substring(1)
          : parentPath;
        if (cleanParent && !cleanParent.endsWith("/")) cleanParent += "/";
        const folderPath = `${cleanParent}${name}`;
        const gitkeepPath = `${folderPath}/.gitkeep`;

        set({ syncStatus: "syncing" });
        const [owner, repo] = currentRepo.split("/");
        fetch(
          `https://api.github.com/repos/${owner}/${repo}/contents/${gitkeepPath}`,
          {
            method: "PUT",
            headers: {
              Authorization: `Bearer ${token}`,
              "Content-Type": "application/json",
              Accept: "application/vnd.github+json",
              "User-Agent": "PromptHub-PMS",
            },
            body: JSON.stringify({
              message: `Create folder ${name}`,
              content: utf8_to_b64(" "),
            }),
          },
        )
          .then((res) => {
            if (!res.ok) throw new Error("Failed to create folder on Github");
            return res.json();
          })
          .then(async (data) => {
            const newFolder: FileNode = {
              id: Math.random().toString(36).substring(7),
              name: name,
              type: "folder",
              path: "/" + folderPath,
              children: [
                {
                  id:
                    data.content.sha || Math.random().toString(36).substring(7),
                  name: ".gitkeep",
                  type: "file",
                  path: "/" + gitkeepPath,
                  status: "synced",
                  sha: data.content.sha,
                  extension: "gitkeep",
                  content: " ",
                  lastModified: new Date(),
                },
              ],
            };

            const tree = [...get().fileTree];

            if (!parentId) {
              const updatedTree = [...tree, newFolder];
              set({ fileTree: updatedTree, syncStatus: "connected" });
              saveFileTreeToLocal(currentRepo, updatedTree);
            } else {
              const addNode = (nodes: FileNode[]): boolean => {
                for (const node of nodes) {
                  if (node.id === parentId && node.type === "folder") {
                    node.children = node.children
                      ? [...node.children, newFolder]
                      : [newFolder];
                    return true;
                  }
                  if (node.children && addNode(node.children)) {
                    return true;
                  }
                }
                return false;
              };

              if (addNode(tree)) {
                set({ fileTree: tree, syncStatus: "connected" });
                saveFileTreeToLocal(currentRepo, tree);
              }
            }
            await get().fetchCommits();
          })
          .catch((err) => {
            console.error("Error creating live folder:", err);
            set({ syncStatus: "disconnected" });
            alert(
              "Failed to create folder on GitHub. Creating local folder instead.",
            );
            fallbackLocalCreateFolder(parentId, name);
          });
      } else {
        fallbackLocalCreateFolder(parentId, name);
      }
    },

    resetSelectedFileChanges: async () => {
      const selectedFile = get().selectedFile;
      const currentRepo = get().currentRepository;
      if (!selectedFile || !currentRepo) return;

      if (typeof window !== "undefined") {
        try {
          const draftsStr = localStorage.getItem("prompthub_drafts") || "{}";
          const drafts = JSON.parse(draftsStr);
          delete drafts[`${currentRepo}:${selectedFile.path}`];
          localStorage.setItem("prompthub_drafts", JSON.stringify(drafts));
        } catch (e) {
          console.error("Failed to remove draft:", e);
        }
      }

      const token = get().githubToken;
      let originalContent = "";

      if (token && selectedFile.status !== "new") {
        set({ syncStatus: "syncing" });
        try {
          const [owner, repoName] = currentRepo.split("/");
          const cleanPath = selectedFile.path.startsWith("/")
            ? selectedFile.path.substring(1)
            : selectedFile.path;

          const res = await fetch(
            `https://api.github.com/repos/${owner}/${repoName}/contents/${cleanPath}`,
            {
              headers: {
                Authorization: `Bearer ${token}`,
                Accept: "application/vnd.github+json",
                "User-Agent": "PromptHub-PMS",
              },
            },
          );

          if (res.ok) {
            const data = await res.json();
            const rawBase64 = data.content.replace(/\s/g, "");
            originalContent = decodeURIComponent(
              escape(window.atob(rawBase64)),
            );
          }
        } catch (error) {
          console.error("Error reloading original content:", error);
        }
      }

      if (!originalContent) {
        const { defaultEditorContent } = await import("@/data/mock");
        originalContent = defaultEditorContent;
      }

      const updateContentInTree = (nodes: FileNode[]): FileNode[] => {
        return nodes.map((node) => {
          if (node.id === selectedFile.id) {
            return {
              ...node,
              content: originalContent,
              status: "synced",
              lastModified: new Date(),
            };
          }
          if (node.children) {
            return {
              ...node,
              children: updateContentInTree(node.children),
            };
          }
          return node;
        });
      };

      const updatedTree = updateContentInTree(get().fileTree);
      const { extractVariables } = await import("@/lib/utils");
      const vars = extractVariables(originalContent);
      const currentVars = get().variables;
      const newVars: Record<string, string> = {};
      vars.forEach((v: string) => {
        newVars[v] = currentVars[v] || "";
      });

      set({
        fileTree: updatedTree,
        selectedFile: {
          ...selectedFile,
          content: originalContent,
          status: "synced",
          lastModified: new Date(),
        },
        editorContent: originalContent,
        isDirty: false,
        detectedVariables: vars,
        variables: { ...currentVars, ...newVars },
        syncStatus: "connected",
      });

      saveFileTreeToLocal(currentRepo, updatedTree);
    },
  };
};
