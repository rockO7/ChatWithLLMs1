import { FileNode, ViewMode, PreviewMode, Commit, TestRun, ModelConfig } from "@/types";
import { RepositoryData } from "@/data/mock";
import { MarketplaceItem } from "@/types/marketplace";

export interface AppState {
  // View
  viewMode: ViewMode;
  setViewMode: (mode: ViewMode) => void;

  // Sidebar
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
  sidebarWidth: number;
  setSidebarWidth: (width: number) => void;

  // Version panel
  versionPanelOpen: boolean;
  setVersionPanelOpen: (open: boolean) => void;

  // File tree
  fileTree: FileNode[];
  selectedFile: FileNode | null;
  expandedFolders: Set<string>;
  setSelectedFile: (file: FileNode | null) => Promise<void>;
  toggleFolder: (folderId: string) => void;

  // Editor
  editorContent: string;
  setEditorContent: (content: string) => void;
  isDirty: boolean;
  setIsDirty: (dirty: boolean) => void;

  // Preview
  previewMode: PreviewMode;
  setPreviewMode: (mode: PreviewMode) => void;
  previewPanelOpen: boolean;
  setPreviewPanelOpen: (open: boolean) => void;

  // Variables
  variables: Record<string, string>;
  setVariable: (name: string, value: string) => void;
  detectedVariables: string[];

  // Git
  commits: Commit[];
  commitMessage: string;
  setCommitMessage: (message: string) => void;

  // Testing
  testRuns: TestRun[];
  models: ModelConfig[];
  toggleModel: (id: string) => void;
  isRunningTest: boolean;
  setIsRunningTest: (running: boolean) => void;
  addTestRun: (run: TestRun) => void;
  clearTestRuns: () => void;
  setTestRunRating: (id: string, rating: "up" | "down") => void;

  // Initialize
  initializeSelection: () => void;

  // Command palette
  commandPaletteOpen: boolean;
  setCommandPaletteOpen: (open: boolean) => void;

  // Sync status
  syncStatus: "connected" | "syncing" | "disconnected";
  lastSaved: Date | null;

  // Repository Management
  currentRepository: string | null;
  selectRepository: (repoName: string | null) => Promise<void>;
  repositories: RepositoryData[];

  // Theme Management
  themeMode: "dark" | "light";
  toggleThemeMode: () => void;

  // Folder & File Creation
  createFile: (parentId: string | null, name: string, content?: string) => void;
  createFolder: (parentId: string | null, name: string) => void;

  // Authentication & Session
  githubToken: string | null;
  user: { name: string; avatar_url: string; login: string } | null;
  isAuthenticated: boolean;
  checkSession: () => Promise<void>;
  login: () => void;
  logout: () => Promise<void>;
  fetchRepositories: () => Promise<void>;
  fetchCommits: () => Promise<void>;
  fetchCommitDetails: (commitId: string) => Promise<void>;
  commitSelectedFile: (message: string) => Promise<void>;

  // Diff View State
  isDiffViewActive: boolean;
  diffOriginalContent: string;
  diffModifiedContent: string;
  diffFilename: string;
  diffType: "workspace" | "commit";
  diffCommitId?: string;
  openWorkspaceDiff: () => Promise<void>;
  openCommitDiff: (commitId: string, filePath: string) => Promise<void>;
  closeDiffView: () => void;

  // Git Branch Management
  currentBranch: string;
  branches: string[];
  selectBranch: (branchName: string) => Promise<void>;
  createBranch: (branchName: string) => Promise<void>;
  fetchBranches: () => Promise<void>;

  // PR Modal State
  createPrModalOpen: boolean;
  setCreatePrModalOpen: (open: boolean) => void;

  // Editor Settings
  editorSettings: {
    fontSize: number;
    wordWrap: "on" | "off";
    minimap: boolean;
    openaiKey: string;
    anthropicKey: string;
    commitPrefix: string;
  };
  setEditorSettings: (settings: Partial<AppState["editorSettings"]>) => void;

  // Additional Modals State
  settingsModalOpen: boolean;
  setSettingsModalOpen: (open: boolean) => void;
  docsModalOpen: boolean;
  setDocsModalOpen: (open: boolean) => void;
  helpModalOpen: boolean;
  setHelpModalOpen: (open: boolean) => void;
  submitPullRequest: (
    title: string,
    desc: string,
    base: string,
    compare: string,
  ) => Promise<{ html_url?: string; number?: number }>;

  // Toasts
  toasts: Array<{
    id: string;
    type: "success" | "error" | "info";
    title: string;
    message: string;
  }>;
  addToast: (toast: {
    type: "success" | "error" | "info";
    title: string;
    message: string;
  }) => void;
  removeToast: (id: string) => void;
  resetSelectedFileChanges: () => Promise<void>;

  // Marketplace Slice
  marketplaceItems: MarketplaceItem[];
  selectedMarketplaceItem: MarketplaceItem | null;
  setSelectedMarketplaceItem: (item: MarketplaceItem | null) => void;
  publishMarketplaceItem: (item: Omit<MarketplaceItem, "id" | "stars" | "downloads">) => void;
  cloneMarketplaceItem: (item: MarketplaceItem, repoName: string) => Promise<boolean>;
  marketplaceSearchQuery: string;
  setMarketplaceSearchQuery: (query: string) => void;
  marketplaceSelectedCategory: string;
  setMarketplaceSelectedCategory: (category: string) => void;
  marketplaceSelectedPublisher: string;
  setMarketplaceSelectedPublisher: (publisher: string) => void;
  marketplaceSelectedType: string;
  setMarketplaceSelectedType: (type: string) => void;
}
