import { FileNode, Commit, TestRun, ModelConfig } from "@/types";

export interface RepositoryData {
  name: string;
  description: string;
  promptCount: number;
  branch: string;
  lastModified: string;
  fileTree: FileNode[];
  stars?: number;
}

export const mockRepositories: RepositoryData[] = [
  {
    name: "acme/prompts",
    description:
      "Production prompts for core Acme AI assistant and workflow agents.",
    promptCount: 6,
    branch: "main",
    lastModified: "2 hours ago",
    fileTree: [
      {
        id: "1",
        name: "prompts",
        type: "folder",
        path: "/prompts",
        children: [
          {
            id: "2",
            name: "system",
            type: "folder",
            path: "/prompts/system",
            children: [
              {
                id: "3",
                name: "code-review.md",
                type: "file",
                path: "/prompts/system/code-review.md",
                status: "synced",
                extension: "md",
                lastModified: new Date("2026-06-04T14:30:00"),
                content: `# Code Review Assistant\n\nYou are a senior software engineer performing a thorough code review. Your role is to analyze code written in {language} and provide constructive, actionable feedback.`,
              },
              {
                id: "4",
                name: "customer-support.md",
                type: "file",
                path: "/prompts/system/customer-support.md",
                status: "draft",
                extension: "md",
                lastModified: new Date("2026-06-05T09:15:00"),
                content: `# Customer Support Agent\n\nYou are a helpful customer support agent for {company_name}. You handle inquiries about {product_name} with empathy and precision.`,
              },
            ],
          },
        ],
      },
    ],
  },
  {
    name: "payment-gateway/prompts",
    description:
      "Prompts for processing billing inquiries, invoices, and Stripe webhook handling.",
    promptCount: 3,
    branch: "prod",
    lastModified: "1 day ago",
    fileTree: [
      {
        id: "100",
        name: "billing",
        type: "folder",
        path: "/billing",
        children: [
          {
            id: "101",
            name: "invoice-reminder.md",
            type: "file",
            path: "/billing/invoice-reminder.md",
            status: "synced",
            extension: "md",
            lastModified: new Date("2026-06-04T10:00:00"),
            content: `# Invoice Reminder Prompt\n\nDraft a polite invoice reminder email to {client_name} regarding overdue invoice #{invoice_id}.`,
          },
          {
            id: "102",
            name: "refund-assistant.md",
            type: "file",
            path: "/billing/refund-assistant.md",
            status: "modified",
            extension: "md",
            lastModified: new Date("2026-06-05T12:00:00"),
            content: `# Refund Assistant\n\nAnalyze refund request details for user {user_id} and reason {refund_reason}. Determine policy eligibility.`,
          },
        ],
      },
    ],
  },
  {
    name: "security-agent/prompts",
    description:
      "Guardrails, input sanitization prompts, and firewall audit rules.",
    promptCount: 2,
    branch: "master",
    lastModified: "3 days ago",
    fileTree: [
      {
        id: "200",
        name: "guardrails",
        type: "folder",
        path: "/guardrails",
        children: [
          {
            id: "201",
            name: "input-sanitizer.md",
            type: "file",
            path: "/guardrails/input-sanitizer.md",
            status: "synced",
            extension: "md",
            lastModified: new Date("2026-06-02T15:00:00"),
            content: `# Input Sanitizer\n\nAnalyze the following query: {user_input} for prompt injection attacks and malicious payload tokens.`,
          },
        ],
      },
    ],
  },
];

export const mockFileTree: FileNode[] = [
  {
    id: "1",
    name: "prompts",
    type: "folder",
    path: "/prompts",
    children: [
      {
        id: "2",
        name: "system",
        type: "folder",
        path: "/prompts/system",
        children: [
          {
            id: "3",
            name: "code-review.md",
            type: "file",
            path: "/prompts/system/code-review.md",
            status: "synced",
            extension: "md",
            lastModified: new Date("2026-06-04T14:30:00"),
            content: `# Code Review Assistant

You are a senior software engineer performing a thorough code review. Your role is to analyze code written in {language} and provide constructive, actionable feedback.

## Context

- **Repository**: {repo_name}
- **Author**: {author_name}
- **Branch**: {branch_name}

## Review Guidelines

1. **Correctness**: Identify bugs, logic errors, and edge cases
2. **Performance**: Flag potential performance bottlenecks
3. **Security**: Highlight security vulnerabilities
4. **Readability**: Suggest improvements for code clarity
5. **Best Practices**: Recommend idiomatic patterns for {language}

## Output Format

For each issue found, provide:

\`\`\`
[SEVERITY: Critical | Major | Minor | Suggestion]
Line: {line_number}
Issue: Brief description
Fix: Recommended solution
\`\`\`

## Additional Instructions

- Be constructive, not critical
- Acknowledge good patterns when you see them
- Prioritize issues by severity
- Maximum {max_issues} issues per review
- Focus on {review_focus} aspects primarily`,
          },
          {
            id: "4",
            name: "customer-support.md",
            type: "file",
            path: "/prompts/system/customer-support.md",
            status: "draft",
            extension: "md",
            lastModified: new Date("2026-06-05T09:15:00"),
            content: `# Customer Support Agent

You are a helpful customer support agent for {company_name}. You handle inquiries about {product_name} with empathy and precision.

## Persona

- **Tone**: {tone} (professional, friendly, or casual)
- **Language**: {language}
- **Expertise Level**: Adjust based on customer's technical proficiency

## Guidelines

1. Always greet the customer by name: {customer_name}
2. Reference their account tier: {account_tier}
3. Check for known issues in the {product_area} category
4. Provide step-by-step solutions when possible
5. Escalate to human agent if confidence is below {confidence_threshold}%

## Response Structure

- Start with acknowledgment of the issue
- Provide clear, numbered steps
- End with follow-up question or confirmation
- Include relevant documentation links from {docs_base_url}`,
          },
          {
            id: "5",
            name: "data-analyst.md",
            type: "file",
            path: "/prompts/system/data-analyst.md",
            status: "synced",
            extension: "md",
            lastModified: new Date("2026-06-03T11:00:00"),
            content: `# Data Analysis Expert

You are a data analyst specializing in {domain}. Analyze the provided dataset and generate insights.

## Parameters

- **Dataset**: {dataset_name}
- **Time Range**: {start_date} to {end_date}
- **Metrics**: {target_metrics}
- **Granularity**: {time_granularity}

## Analysis Framework

1. **Summary Statistics**: Provide key statistical measures
2. **Trend Analysis**: Identify patterns over {time_granularity} periods
3. **Anomaly Detection**: Flag unusual data points
4. **Correlations**: Find relationships between {target_metrics}
5. **Recommendations**: Actionable insights based on findings

## Output Format

Return results as {output_format} with visualizations described in markdown tables.`,
          },
        ],
      },
      {
        id: "6",
        name: "templates",
        type: "folder",
        path: "/prompts/templates",
        children: [
          {
            id: "7",
            name: "blog-writer.md",
            type: "file",
            path: "/prompts/templates/blog-writer.md",
            status: "modified",
            extension: "md",
            lastModified: new Date("2026-06-05T08:45:00"),
            content: `# Blog Post Generator

Write a {word_count}-word blog post about {topic} for {target_audience}.

## Style Guide

- **Tone**: {writing_tone}
- **Reading Level**: {reading_level}
- **SEO Keywords**: {keywords}

## Structure

1. Hook/Introduction (capture attention in first sentence)
2. Problem Statement
3. Solution/Main Content (with {num_subheadings} subheadings)
4. Practical Examples
5. Call to Action: {cta_text}

## Constraints

- Use short paragraphs (2-3 sentences max)
- Include at least {num_examples} real-world examples
- Add a meta description under 160 characters
- Internal links format: [{link_text}]({link_url})`,
          },
          {
            id: "8",
            name: "email-composer.md",
            type: "file",
            path: "/prompts/templates/email-composer.md",
            status: "synced",
            extension: "md",
            lastModified: new Date("2026-06-01T16:20:00"),
            content: `# Email Composer

Compose a {email_type} email from {sender_name} to {recipient_name}.

## Context

- **Subject**: {email_subject}
- **Purpose**: {email_purpose}
- **Urgency**: {urgency_level}
- **Previous Thread**: {has_previous_context}

## Tone & Style

- Match the formality level: {formality}
- Keep under {max_words} words
- Use {language} language

## Structure

1. Greeting appropriate for {relationship_type}
2. Context/Reference to previous communication
3. Main message body
4. Clear call to action
5. Professional sign-off`,
          },
        ],
      },
      {
        id: "9",
        name: "chains",
        type: "folder",
        path: "/prompts/chains",
        children: [
          {
            id: "10",
            name: "research-pipeline.md",
            type: "file",
            path: "/prompts/chains/research-pipeline.md",
            status: "behind",
            extension: "md",
            lastModified: new Date("2026-05-28T13:00:00"),
            content: `# Research Pipeline

## Step 1: Query Expansion
Expand the research query "{research_topic}" into {num_queries} specific sub-questions.

## Step 2: Source Analysis
For each sub-question, analyze sources from {source_types} and extract key findings.

## Step 3: Synthesis
Combine findings into a coherent {output_length} report with:
- Executive summary
- Key findings (bulleted)
- Supporting evidence
- Confidence scores per claim
- Recommended next steps

## Parameters
- **Depth**: {research_depth}
- **Recency Bias**: Prefer sources from last {recency_months} months
- **Citation Style**: {citation_format}`,
          },
        ],
      },
      {
        id: "11",
        name: "config.json",
        type: "file",
        path: "/prompts/config.json",
        status: "synced",
        extension: "json",
        lastModified: new Date("2026-06-02T10:00:00"),
        content: `{
  "version": "2.1.0",
  "defaultModel": "claude-4-sonnet",
  "maxTokens": 4096,
  "temperature": 0.7,
  "topP": 0.95,
  "variables": {
    "company_name": "Acme Corp",
    "product_name": "AcmeAI",
    "default_language": "English"
  }
}`,
      },
      {
        id: "12",
        name: "README.md",
        type: "file",
        path: "/prompts/README.md",
        status: "synced",
        extension: "md",
        lastModified: new Date("2026-06-01T09:00:00"),
        content: `# Acme Prompt Library

A curated collection of production prompts for AcmeAI.

## Structure

- \`/system\` — System prompts for AI agents
- \`/templates\` — Reusable prompt templates
- \`/chains\` — Multi-step prompt pipelines

## Usage

Each prompt uses \`{variable_name}\` syntax for dynamic values.
See \`config.json\` for default variable mappings.

## Contributing

1. Create a branch from \`main\`
2. Add or modify prompts
3. Test in the PromptHub Testing Arena
4. Submit a PR with test results attached`,
      },
    ],
  },
];

export const mockCommits: Commit[] = [
  {
    id: "c1",
    hash: "a3f8d2e",
    message: "feat: add confidence threshold to customer support prompt",
    author: {
      name: "Sarah Chen",
      avatar: "",
    },
    date: new Date("2026-06-05T09:15:00"),
    additions: 12,
    deletions: 3,
    files: ["prompts/system/customer-support.md"],
  },
  {
    id: "c2",
    hash: "b7c1e4f",
    message: "refactor: improve code review output format",
    author: {
      name: "Alex Rivera",
      avatar: "",
    },
    date: new Date("2026-06-04T14:30:00"),
    additions: 8,
    deletions: 5,
    files: ["prompts/system/code-review.md"],
  },
  {
    id: "c3",
    hash: "e2d9a1b",
    message: "feat: add SEO keywords support to blog writer",
    author: {
      name: "Sarah Chen",
      avatar: "",
    },
    date: new Date("2026-06-04T11:20:00"),
    additions: 15,
    deletions: 2,
    files: ["prompts/templates/blog-writer.md"],
  },
  {
    id: "c4",
    hash: "f4a8c3d",
    message: "fix: correct variable naming in email composer",
    author: {
      name: "Jordan Park",
      avatar: "",
    },
    date: new Date("2026-06-03T16:45:00"),
    additions: 4,
    deletions: 4,
    files: ["prompts/templates/email-composer.md"],
  },
  {
    id: "c5",
    hash: "c9e7b2a",
    message: "docs: update README with contributing guide",
    author: {
      name: "Alex Rivera",
      avatar: "",
    },
    date: new Date("2026-06-02T10:00:00"),
    additions: 20,
    deletions: 8,
    files: ["prompts/README.md", "prompts/config.json"],
  },
  {
    id: "c6",
    hash: "d1f3e5c",
    message: "feat: add research pipeline chain prompt",
    author: {
      name: "Sarah Chen",
      avatar: "",
    },
    date: new Date("2026-05-28T13:00:00"),
    additions: 32,
    deletions: 0,
    files: ["prompts/chains/research-pipeline.md"],
  },
  {
    id: "c7",
    hash: "a8b2c4d",
    message: "feat: add data analyst system prompt",
    author: {
      name: "Jordan Park",
      avatar: "",
    },
    date: new Date("2026-05-25T09:30:00"),
    additions: 28,
    deletions: 0,
    files: ["prompts/system/data-analyst.md"],
  },
  {
    id: "c8",
    hash: "e5f7a9b",
    message: "initial: project structure and base prompts",
    author: {
      name: "Alex Rivera",
      avatar: "",
    },
    date: new Date("2026-05-20T08:00:00"),
    additions: 150,
    deletions: 0,
    files: [
      "prompts/system/code-review.md",
      "prompts/templates/email-composer.md",
      "prompts/README.md",
      "prompts/config.json",
    ],
  },
];

export const mockModels: ModelConfig[] = [
  {
    id: "claude-4-sonnet",
    name: "Claude 4 Sonnet",
    provider: "Anthropic",
    icon: "✦",
    maxTokens: 8192,
    selected: true,
  },
  {
    id: "gpt-5",
    name: "GPT-5",
    provider: "OpenAI",
    icon: "◈",
    maxTokens: 8192,
    selected: false,
  },
  {
    id: "gemini-3-pro",
    name: "Gemini 3 Pro",
    provider: "Google",
    icon: "◆",
    maxTokens: 8192,
    selected: false,
  },
  {
    id: "llama-4-70b",
    name: "Llama 4 70B",
    provider: "Meta",
    icon: "▲",
    maxTokens: 4096,
    selected: false,
  },
];

export const mockTestRuns: TestRun[] = [
  {
    id: "tr1",
    model: "Claude 4 Sonnet",
    prompt: "code-review.md",
    variables: {
      language: "TypeScript",
      repo_name: "acme/frontend",
      author_name: "dev@acme.com",
      branch_name: "feat/auth-flow",
      max_issues: "10",
      review_focus: "security",
    },
    response: `## Code Review Results

### [CRITICAL] Line 47 — SQL Injection Vulnerability
**Issue**: User input is directly interpolated into the SQL query without parameterization.

\`\`\`typescript
// ❌ Current
const query = \`SELECT * FROM users WHERE id = '\${userId}'\`;

// ✅ Recommended
const query = 'SELECT * FROM users WHERE id = $1';
const result = await db.query(query, [userId]);
\`\`\`

### [MAJOR] Line 112 — Missing Error Boundary
**Issue**: The async operation lacks proper error handling, which could cause unhandled promise rejections.

**Fix**: Wrap in try-catch with appropriate error logging and user-facing error state.

### [MINOR] Line 89 — Unnecessary Re-render
**Issue**: The \`useMemo\` dependency array includes \`props.data\` which creates a new reference on each render.

**Fix**: Destructure the specific fields needed or use a deep comparison hook.

### ✅ Good Patterns Observed
- Consistent use of TypeScript strict mode
- Well-structured component hierarchy
- Proper use of React.memo for expensive components

**Overall Score**: 7/10 — Address critical security issue before merging.`,
    tokens: { input: 847, output: 623 },
    latency: 2340,
    timestamp: new Date("2026-06-05T10:30:00"),
    rating: "up",
  },
  {
    id: "tr2",
    model: "GPT-5",
    prompt: "code-review.md",
    variables: {
      language: "TypeScript",
      repo_name: "acme/frontend",
      author_name: "dev@acme.com",
      branch_name: "feat/auth-flow",
      max_issues: "10",
      review_focus: "security",
    },
    response: `# Code Review: feat/auth-flow

## Security Issues Found

**1. 🔴 Critical: Unvalidated Input (Line 47)**
The user ID parameter is not sanitized before being used in a database query. This opens the application to SQL injection attacks.

*Recommendation*: Use parameterized queries with your ORM or query builder.

**2. 🟡 Major: Missing CSRF Protection (Line 203)**
The authentication endpoint does not include CSRF token validation.

*Recommendation*: Implement CSRF middleware using the double-submit cookie pattern.

**3. 🟡 Major: Hardcoded Secret (Line 15)**
JWT secret is hardcoded in the source file rather than loaded from environment variables.

*Recommendation*: Move to \`.env\` and access via \`process.env.JWT_SECRET\`.

**4. 🟢 Minor: Console.log in Production (Lines 34, 67, 91)**
Debug logging statements should be removed or replaced with proper logging library.

## Summary
Found 2 critical/major security issues that should be addressed before merge. The overall code structure is clean and follows TypeScript best practices.`,
    tokens: { input: 847, output: 589 },
    latency: 1890,
    timestamp: new Date("2026-06-05T10:30:00"),
  },
];

export const defaultEditorContent = `# Code Review Assistant

You are a senior software engineer performing a thorough code review. Your role is to analyze code written in {language} and provide constructive, actionable feedback.

## Context

- **Repository**: {repo_name}
- **Author**: {author_name}
- **Branch**: {branch_name}

## Review Guidelines

1. **Correctness**: Identify bugs, logic errors, and edge cases
2. **Performance**: Flag potential performance bottlenecks
3. **Security**: Highlight security vulnerabilities
4. **Readability**: Suggest improvements for code clarity
5. **Best Practices**: Recommend idiomatic patterns for {language}

## Output Format

For each issue found, provide:

\`\`\`
[SEVERITY: Critical | Major | Minor | Suggestion]
Line: {line_number}
Issue: Brief description
Fix: Recommended solution
\`\`\`

## Additional Instructions

- Be constructive, not critical
- Acknowledge good patterns when you see them
- Prioritize issues by severity
- Maximum {max_issues} issues per review
- Focus on {review_focus} aspects primarily`;
