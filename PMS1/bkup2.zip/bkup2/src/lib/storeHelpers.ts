import { FileNode } from "@/types";

export function sortFileTree(nodes: FileNode[]): FileNode[] {
  nodes.sort((a, b) => {
    if (a.type !== b.type) {
      return a.type === "folder" ? -1 : 1;
    }
    return a.name.localeCompare(b.name);
  });
  nodes.forEach((node) => {
    if (node.children) {
      sortFileTree(node.children);
    }
  });
  return nodes;
}

export function buildFileTreeFromGitTree(gitTree: Array<{ path: string; type: string; sha?: string }>): FileNode[] {
  const root: FileNode[] = [];
  const pathMap: Record<string, FileNode> = {};

  gitTree.forEach((item) => {
    const parts = item.path.split("/");
    let currentLevel = root;
    let currentPath = "";

    parts.forEach((part: string, idx: number) => {
      currentPath = currentPath ? `${currentPath}/${part}` : part;
      const isLast = idx === parts.length - 1;

      let node = pathMap[currentPath];
      if (!node) {
        const type = isLast && item.type === "blob" ? "file" : "folder";
        node = {
          id: item.sha || Math.random().toString(36).substring(7),
          name: part,
          type: type,
          path: "/" + currentPath,
          status: "synced",
        };

        if (type === "file") {
          node.extension = part.split(".").pop() || "";
          node.content = "";
        } else {
          node.children = [];
        }

        pathMap[currentPath] = node;
        currentLevel.push(node);
      }

      if (node.type === "folder") {
        currentLevel = node.children || [];
      }
    });
  });

  return sortFileTree(root);
}

export function utf8_to_b64(str: string): string {
  if (typeof window !== "undefined") {
    return window.btoa(unescape(encodeURIComponent(str)));
  }
  return Buffer.from(str, "utf-8").toString("base64");
}

export function getMockCommitParentContent(commitId: string, filePath: string, currentContent: string): string {
  if (commitId === "c1" && filePath.includes("customer-support.md")) {
    return currentContent.replace(
      "5. Escalate to human agent if confidence is below {confidence_threshold}%\n",
      ""
    );
  }
  if (commitId === "c2" && filePath.includes("code-review.md")) {
    return currentContent.replace(
      "5. Best Practices: Recommend idiomatic patterns for {language}\n",
      ""
    ).replace(
      "Focus on {review_focus} aspects primarily",
      "Focus on correctness aspects primarily"
    );
  }
  if (commitId === "c3" && filePath.includes("blog-writer.md")) {
    return currentContent.replace(
      "- SEO Keywords: {keywords}\n",
      ""
    );
  }
  if (commitId === "c4" && filePath.includes("email-composer.md")) {
    return currentContent.replace(
      "has_previous_context",
      "has_prev_context"
    );
  }
  return currentContent + "\n\n// Older version restored from commit history";
}

export function saveFileTreeToLocal(repoName: string | null, tree: FileNode[]) {
  if (typeof window !== "undefined" && repoName) {
    try {
      localStorage.setItem(`prompthub_file_tree:${repoName}`, JSON.stringify(tree));
    } catch (e) {
      console.error("Failed to save file tree to localStorage:", e);
    }
  }
}

export function obfuscateKey(key: string): string {
  if (!key) return "";
  const shifted = key.split("").map((c) => String.fromCharCode(c.charCodeAt(0) ^ 42)).join("");
  if (typeof window !== "undefined") {
    return window.btoa(unescape(encodeURIComponent(shifted)));
  }
  return Buffer.from(shifted).toString("base64");
}

export function deobfuscateKey(obfuscated: string): string {
  if (!obfuscated) return "";
  try {
    let shifted = "";
    if (typeof window !== "undefined") {
      shifted = decodeURIComponent(escape(window.atob(obfuscated)));
    } else {
      shifted = Buffer.from(obfuscated, "base64").toString("utf-8");
    }
    return shifted.split("").map((c) => String.fromCharCode(c.charCodeAt(0) ^ 42)).join("");
  } catch (e) {
    console.error("Failed to deobfuscate key:", e);
    return "";
  }
}
