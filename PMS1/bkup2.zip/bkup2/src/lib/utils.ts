import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { FileNode } from "@/types";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function extractVariables(text: string): string[] {
  const regex = /\{(\w+)\}/g;
  const variables: string[] = [];
  let match;
  while ((match = regex.exec(text)) !== null) {
    if (!variables.includes(match[1])) {
      variables.push(match[1]);
    }
  }
  return variables;
}

export function renderVariablePills(text: string): string {
  return text.replace(
    /\{(\w+)\}/g,
    '<span class="variable-pill">{$1}</span>'
  );
}

export function timeAgo(date: Date | string | number | undefined | null): string {
  if (!date) return "2h ago";
  const d = typeof date === "string" || typeof date === "number" ? new Date(date) : date;
  if (isNaN(d.getTime())) return "2h ago";
  const now = new Date();
  const seconds = Math.floor((now.getTime() - d.getTime()) / 1000);

  if (seconds < 60) return "just now";
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  if (seconds < 604800) return `${Math.floor(seconds / 86400)}d ago`;
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

export function truncate(str: string, length: number): string {
  if (str.length <= length) return str;
  return str.slice(0, length) + "…";
}

export function generateId(): string {
  return Math.random().toString(36).substring(2, 9);
}

export function findFileById(nodes: FileNode[], id: string): FileNode | null {
  for (const node of nodes) {
    if (node.id === id) return node;
    if (node.children) {
      const found = findFileById(node.children, id);
      if (found) return found;
    }
  }
  return null;
}

export function findParentPath(nodes: FileNode[], parentId: string): string | null {
  for (const node of nodes) {
    if (node.id === parentId) return node.path;
    if (node.children) {
      const found = findParentPath(node.children, parentId);
      if (found) return found;
    }
  }
  return null;
}
