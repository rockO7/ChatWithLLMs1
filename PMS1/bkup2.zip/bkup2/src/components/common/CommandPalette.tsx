"use client";

import React, { useState, useEffect, useRef } from "react";
import { useAppStore } from "@/store";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";
import {
  Search,
  FileText,
  GitCommit,
  Settings,
  Beaker,
  Code2,
  CornerDownLeft,
  ArrowUp,
  ArrowDown,
  Layers,
} from "lucide-react";

const commands = [
  { id: "1", label: "Open code-review.md", category: "Files", icon: FileText, shortcut: "" },
  { id: "2", label: "Open customer-support.md", category: "Files", icon: FileText, shortcut: "" },
  { id: "3", label: "Open blog-writer.md", category: "Files", icon: FileText, shortcut: "" },
  { id: "4", label: "Open data-analyst.md", category: "Files", icon: FileText, shortcut: "" },
  { id: "5", label: "Switch to Editor", category: "Navigation", icon: Code2, shortcut: "⌘1" },
  { id: "6", label: "Switch to Testing Arena", category: "Navigation", icon: Beaker, shortcut: "⌘2" },
  { id: "9", label: "Switch to Marketplace", category: "Navigation", icon: Layers, shortcut: "⌘3" },
  { id: "7", label: "Commit to GitHub", category: "Git", icon: GitCommit, shortcut: "⌘⇧C" },
  { id: "8", label: "Open Settings", category: "General", icon: Settings, shortcut: "⌘," },
];

export function CommandPalette() {
  const {
    commandPaletteOpen,
    setCommandPaletteOpen,
    setViewMode,
    setSettingsModalOpen,
    setSelectedFile,
    fileTree,
    currentRepository,
  } = useAppStore();
  const [query, setQuery] = useState("");
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  const filtered = commands
    .filter((cmd) => !(cmd.id === "9" && currentRepository))
    .filter((cmd) =>
      cmd.label.toLowerCase().includes(query.toLowerCase())
    );

  const grouped = filtered.reduce((acc, cmd) => {
    if (!acc[cmd.category]) acc[cmd.category] = [];
    acc[cmd.category].push(cmd);
    return acc;
  }, {} as Record<string, typeof commands>);

  useEffect(() => {
    if (commandPaletteOpen) {
      const timer = setTimeout(() => {
        setQuery("");
        setSelectedIndex(0);
        inputRef.current?.focus();
      }, 50);
      return () => clearTimeout(timer);
    }
  }, [commandPaletteOpen]);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setCommandPaletteOpen(!commandPaletteOpen);
      }
      if (e.key === "Escape") {
        setCommandPaletteOpen(false);
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [commandPaletteOpen, setCommandPaletteOpen]);

  const handleExecuteCommand = (cmdId: string) => {
    setCommandPaletteOpen(false);

    if (cmdId === "5") {
      setViewMode("editor");
    } else if (cmdId === "6") {
      setViewMode("testing");
    } else if (cmdId === "9") {
      setViewMode("marketplace");
    } else if (cmdId === "8") {
      setSettingsModalOpen(true);
    } else if (["1", "2", "3", "4"].includes(cmdId)) {
      const filename = commands.find((c) => c.id === cmdId)?.label.replace("Open ", "") || "";
      const findAndSelectFile = (nodes: any[]): boolean => {
        for (const n of nodes) {
          if (n.type === "file" && n.name === filename) {
            setSelectedFile(n);
            setViewMode("editor");
            return true;
          }
          if (n.children && findAndSelectFile(n.children)) {
            return true;
          }
        }
        return false;
      };
      findAndSelectFile(fileTree);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setSelectedIndex((i) => Math.min(i + 1, filtered.length - 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setSelectedIndex((i) => Math.max(i - 1, 0));
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (filtered[selectedIndex]) {
        handleExecuteCommand(filtered[selectedIndex].id);
      } else {
        setCommandPaletteOpen(false);
      }
    }
  };

  return (
    <AnimatePresence>
      {commandPaletteOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50"
            onClick={() => setCommandPaletteOpen(false)}
          />

          {/* Palette */}
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: -10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: -10 }}
            transition={{ type: "spring", bounce: 0.15, duration: 0.3 }}
            className="fixed top-[20%] left-1/2 -translate-x-1/2 w-[540px] bg-bg-secondary border border-border rounded-xl shadow-elevated z-50 overflow-hidden"
          >
            {/* Search input */}
            <div className="flex items-center gap-2 px-4 border-b border-border">
              <Search size={15} className="text-text-muted flex-shrink-0" />
              <input
                ref={inputRef}
                value={query}
                onChange={(e) => {
                  setQuery(e.target.value);
                  setSelectedIndex(0);
                }}
                onKeyDown={handleKeyDown}
                placeholder="Search commands, files..."
                className="flex-1 h-11 bg-transparent text-[14px] text-text-primary placeholder:text-text-muted focus:outline-none focus:ring-0 focus-visible:outline-none focus-visible:ring-0"
                style={{ outline: "none", boxShadow: "none" }}
              />
              <kbd className="text-[10px] text-text-muted bg-bg-primary border border-border rounded px-1.5 py-0.5 font-mono">
                ESC
              </kbd>
            </div>

            {/* Results */}
            <div className="max-h-[320px] overflow-y-auto p-1.5">
              {Object.entries(grouped).map(([category, items]) => (
                <div key={category} className="mb-1">
                  <div className="px-2 py-1.5">
                    <span className="text-[10px] text-text-muted uppercase tracking-widest font-medium">
                      {category}
                    </span>
                  </div>
                  {items.map((cmd) => {
                    const globalIndex = filtered.indexOf(cmd);
                    const isSelected = globalIndex === selectedIndex;
                    const Icon = cmd.icon;

                    return (
                      <button
                        key={cmd.id}
                        className={cn(
                          "w-full flex items-center gap-2.5 px-2.5 py-2 rounded-md text-[13px] transition-colors duration-75",
                          isSelected
                            ? "bg-white/[0.08] text-text-primary"
                            : "text-text-secondary hover:bg-white/[0.04]"
                        )}
                        onClick={() => handleExecuteCommand(cmd.id)}
                        onMouseEnter={() => setSelectedIndex(globalIndex)}
                      >
                        <Icon size={14} className="text-text-muted flex-shrink-0" />
                        <span className="flex-1 text-left">{cmd.label}</span>
                        {cmd.shortcut && (
                          <kbd className="text-[10px] text-text-muted font-mono">
                            {cmd.shortcut}
                          </kbd>
                        )}
                        {isSelected && (
                          <CornerDownLeft
                            size={12}
                            className="text-text-muted"
                          />
                        )}
                      </button>
                    );
                  })}
                </div>
              ))}

              {filtered.length === 0 && (
                <div className="py-8 text-center">
                  <p className="text-[13px] text-text-muted">No results found</p>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="px-3 py-2 border-t border-border flex items-center gap-3 text-[10px] text-text-muted">
              <div className="flex items-center gap-1">
                <ArrowUp size={10} />
                <ArrowDown size={10} />
                <span>Navigate</span>
              </div>
              <div className="flex items-center gap-1">
                <CornerDownLeft size={10} />
                <span>Select</span>
              </div>
              <div className="flex items-center gap-1">
                <span>ESC</span>
                <span>Close</span>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
