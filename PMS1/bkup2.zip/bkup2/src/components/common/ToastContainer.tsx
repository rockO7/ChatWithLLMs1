"use client";

import React from "react";
import { useAppStore } from "@/store";
import { motion, AnimatePresence } from "framer-motion";
import { CheckCircle2, XCircle, AlertCircle, X } from "lucide-react";
import { cn } from "@/lib/utils";

export function ToastContainer() {
  const { toasts, removeToast } = useAppStore();

  return (
    <div className="fixed bottom-6 right-6 z-[9999] flex flex-col gap-2.5 max-w-sm w-full pointer-events-none">
      <AnimatePresence>
        {toasts.map((toast) => {
          const isSuccess = toast.type === "success";
          const isError = toast.type === "error";

          return (
            <motion.div
              key={toast.id}
              initial={{ opacity: 0, y: 15, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9, transition: { duration: 0.15 } }}
              layout
              className={cn(
                "pointer-events-auto flex items-start gap-3 p-3.5 rounded-xl border shadow-lg backdrop-blur-md transition-colors duration-200",
                isSuccess && "bg-emerald-950/80 border-emerald-800/60 text-emerald-100",
                isError && "bg-red-950/80 border-red-900/60 text-red-100",
                !isSuccess && !isError && "bg-zinc-900/95 border-zinc-800 text-zinc-100"
              )}
            >
              {/* Icon */}
              <div className="flex-shrink-0 mt-0.5">
                {isSuccess && <CheckCircle2 size={16} className="text-emerald-400" />}
                {isError && <XCircle size={16} className="text-red-400" />}
                {!isSuccess && !isError && <AlertCircle size={16} className="text-zinc-400" />}
              </div>

              {/* Content */}
              <div className="flex-1 min-w-0">
                <h4 className="text-[12px] font-semibold tracking-tight leading-none mb-1">
                  {toast.title}
                </h4>
                <p className={cn(
                  "text-[11px] leading-relaxed",
                  isSuccess && "text-emerald-200/90",
                  isError && "text-red-200/90",
                  !isSuccess && !isError && "text-zinc-400"
                )}>
                  {toast.message}
                </p>
              </div>

              {/* Close Button */}
              <button
                onClick={() => removeToast(toast.id)}
                className={cn(
                  "flex-shrink-0 h-4 w-4 rounded-sm flex items-center justify-center transition-colors",
                  isSuccess && "text-emerald-400/70 hover:text-emerald-100 hover:bg-emerald-900/40",
                  isError && "text-red-400/70 hover:text-red-100 hover:bg-red-900/40",
                  !isSuccess && !isError && "text-zinc-500 hover:text-zinc-200 hover:bg-zinc-800"
                )}
              >
                <X size={10} />
              </button>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
}
