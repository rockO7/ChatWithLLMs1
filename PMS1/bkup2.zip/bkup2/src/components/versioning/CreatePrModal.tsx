"use client";

import React, { useState } from "react";
import { useAppStore } from "@/store";
import { motion, AnimatePresence } from "framer-motion";
import { GitPullRequest, X, Loader2, Info } from "lucide-react";

export function CreatePrModal() {
  const {
    createPrModalOpen,
    setCreatePrModalOpen,
    submitPullRequest,
    currentRepository,
    selectedFile,
    isAuthenticated,
    currentBranch,
    branches,
  } = useAppStore();

  const filename = selectedFile?.name || "prompt.md";

  const defaultBase = branches.includes("main")
    ? "main"
    : branches.includes("master")
      ? "master"
      : branches[0] || "main";

  const [title, setTitle] = useState(`feat: update ${filename} template`);
  const [description, setDescription] = useState(`Updated instructions for ${filename} to optimize outputs.`);
  const [baseBranch, setBaseBranch] = useState(defaultBase);
  const [compareBranch, setCompareBranch] = useState(currentBranch);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!createPrModalOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !compareBranch) return;

    setIsSubmitting(true);
    try {
      await submitPullRequest(title, description, baseBranch, compareBranch);
      setCreatePrModalOpen(false);
    } catch {
      // Handled by store toasts
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[999] flex items-center justify-center">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="fixed inset-0 bg-black/60 backdrop-blur-sm"
          onClick={() => setCreatePrModalOpen(false)}
        />

        {/* Modal content */}
        <motion.div
          initial={{ opacity: 0, scale: 0.96, y: 8 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.96, y: 8 }}
          transition={{ type: "spring", duration: 0.35, bounce: 0.12 }}
          className="relative w-[500px] bg-bg-secondary border border-border rounded-xl shadow-elevated overflow-hidden z-10"
        >
          {/* Header */}
          <div className="h-12 border-b border-border flex items-center justify-between px-4">
            <div className="flex items-center gap-2 text-text-primary">
              <GitPullRequest size={15} className="text-text-secondary" />
              <span className="text-[13px] font-semibold">Create Pull Request</span>
            </div>
            <button
              onClick={() => setCreatePrModalOpen(false)}
              className="h-6 w-6 flex items-center justify-center rounded-sm text-text-muted hover:text-text-primary hover:bg-bg-hover transition-colors"
            >
              <X size={14} />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="p-4 space-y-4">
            {/* Repo Info */}
            <div className="bg-bg-elevated/50 border border-border p-2.5 rounded-lg text-[11px] flex items-center justify-between">
              <span className="text-text-muted font-medium">Repository</span>
              <span className="text-text-secondary font-mono">{currentRepository || "acme/prompts"}</span>
            </div>

            {/* Branch Selector Grid */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <label className="text-[10px] text-text-muted uppercase tracking-wider font-semibold">
                  Base Branch
                </label>
                <select
                  value={baseBranch}
                  onChange={(e) => setBaseBranch(e.target.value)}
                  className="w-full h-8 px-2.5 rounded-md bg-bg-elevated border border-border text-[11.5px] text-text-primary focus:border-border-focus focus:outline-none transition-colors select-none cursor-pointer"
                >
                  {branches.length > 0 ? (
                    branches.map((b) => (
                      <option key={b} value={b}>
                        {b}
                      </option>
                    ))
                  ) : (
                    <>
                      <option value="main">main</option>
                      <option value="prod">prod</option>
                      <option value="master">master</option>
                    </>
                  )}
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] text-text-muted uppercase tracking-wider font-semibold">
                  Compare Branch
                </label>
                <select
                  value={compareBranch}
                  onChange={(e) => setCompareBranch(e.target.value)}
                  className="w-full h-8 px-2.5 rounded-md bg-bg-elevated border border-border text-[11.5px] text-text-primary focus:border-border-focus focus:outline-none transition-colors select-none cursor-pointer"
                >
                  {branches.length > 0 ? (
                    branches.map((b) => (
                      <option key={b} value={b}>
                        {b}
                      </option>
                    ))
                  ) : (
                    <>
                      <option value="main">main</option>
                      <option value="dev">dev</option>
                      <option value="feature/auth">feature/auth</option>
                    </>
                  )}
                </select>
              </div>
            </div>

            {baseBranch === compareBranch && (
              <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/20 flex gap-2.5">
                <span className="text-[10.5px] text-red-400 leading-relaxed font-medium">
                  Base branch and compare branch cannot be the same.
                </span>
              </div>
            )}

            {/* PR Title */}
            <div className="space-y-1.5">
              <label className="text-[10px] text-text-muted uppercase tracking-wider font-semibold">
                Pull Request Title
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. feat: add safety guards"
                className="w-full h-8 px-2.5 rounded-md bg-bg-elevated border border-border text-[11.5px] text-text-primary placeholder:text-text-muted focus:border-border-focus focus:outline-none transition-colors"
              />
            </div>

            {/* Description */}
            <div className="space-y-1.5">
              <label className="text-[10px] text-text-muted uppercase tracking-wider font-semibold">
                Description
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Describe your prompt changes..."
                rows={4}
                className="w-full resize-none rounded-md bg-bg-elevated border border-border text-[11.5px] text-text-primary placeholder:text-text-muted p-2 focus:border-border-focus focus:outline-none transition-colors leading-relaxed"
              />
            </div>

            {/* GitHub Info Alert */}
            <div className="p-3 rounded-lg bg-white/[0.02] border border-border flex gap-2.5">
              <Info size={14} className="text-text-tertiary mt-0.5 flex-shrink-0" />
              <div className="text-[10.5px] text-text-secondary leading-relaxed">
                {isAuthenticated ? (
                  <span>
                    Connected to GitHub. Submitting will create an actual pull request on the repository.
                  </span>
                ) : (
                  <span>
                    Simulated mode active. Submitting will run a simulation and create a mock pull request.
                  </span>
                )}
              </div>
            </div>

            {/* Footer Buttons */}
            <div className="flex items-center justify-end gap-2.5 pt-2 border-t border-border">
              <button
                type="button"
                onClick={() => setCreatePrModalOpen(false)}
                className="h-8 px-3 rounded-lg text-[11px] font-medium text-text-secondary hover:text-text-primary border border-border hover:border-border-strong hover:bg-bg-hover transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting || baseBranch === compareBranch}
                className="h-8 px-4 rounded-lg text-[11px] font-semibold bg-white text-black hover:bg-zinc-200 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center gap-1.5 shadow-sm"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 size={12} className="animate-spin" />
                    Creating PR...
                  </>
                ) : (
                  <>
                    <GitPullRequest size={12} />
                    Create Pull Request
                  </>
                )}
              </button>
            </div>
          </form>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}