"use client";

import React, { useState } from "react";
import { useAppStore } from "@/store";
import { cn } from "@/lib/utils";
import { timeAgo } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";
import { Tooltip } from "@/components/ui/Tooltip";
import {
  GitPullRequest,
  ExternalLink,
  Diff,
  Copy,
  ArrowUpFromLine,
  FileText,
  PanelRightClose,
  RefreshCw,
  Wand2,
} from "lucide-react";

export function VersionTimeline() {
  const {
    commits,
    commitMessage,
    setCommitMessage,
    isDirty,
    versionPanelOpen,
    setVersionPanelOpen,
    commitSelectedFile,
    openWorkspaceDiff,
    openCommitDiff,
    setCreatePrModalOpen,
    fetchCommitDetails,
    selectedFile,
    editorContent,
  } = useAppStore();

  const [isCommitting, setIsCommitting] = useState(false);
  const [isGeneratingMessage, setIsGeneratingMessage] = useState(false);

  const handleGenerateCommitMessage = async () => {
    if (!selectedFile) return;
    setIsGeneratingMessage(true);
    try {
      const res = await fetch("/api/ai/commit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          original: selectedFile.originalContent || selectedFile.content || "",
          modified: editorContent,
          filename: selectedFile.name,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.commitMessage) {
          setCommitMessage(data.commitMessage);
        }
      }
    } catch (err) {
      console.error("Failed to generate commit message:", err);
    } finally {
      setIsGeneratingMessage(false);
    }
  };

  const handleCommit = async () => {
    if (!commitMessage.trim()) return;
    setIsCommitting(true);
    try {
      await commitSelectedFile(commitMessage);
    } catch (err) {
      alert("Failed to commit: " + (err as Error).message);
    } finally {
      setIsCommitting(false);
    }
  };

  const [expandedCommit, setExpandedCommit] = useState<string | null>(null);

  if (!versionPanelOpen) return null;

  return (
    <div className="h-full flex flex-col bg-bg-primary border-l border-border w-full">
      {/* Header */}
      <div className="h-10 border-b border-border flex items-center justify-between px-3 flex-shrink-0">
        <span className="text-[12px] font-medium text-text-secondary">
          Version Control
        </span>
        <Tooltip content="Close panel">
          <button
            onClick={() => setVersionPanelOpen(false)}
            className="h-6 w-6 flex items-center justify-center rounded-sm text-text-muted hover:text-text-primary hover:bg-bg-hover transition-colors"
          >
            <PanelRightClose size={13} />
          </button>
        </Tooltip>
      </div>

      {/* Commit section */}
      <div className="p-3 border-b border-border space-y-2.5">
        {/* Commit message */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <label className="text-[10px] text-text-muted uppercase tracking-widest font-medium">
              Commit Message
            </label>
            <button
              onClick={handleGenerateCommitMessage}
              disabled={isGeneratingMessage || !isDirty}
              className="text-[10px] text-emerald-400 hover:text-emerald-300 disabled:opacity-40 disabled:cursor-not-allowed transition-colors flex items-center gap-1 cursor-pointer font-medium"
              title="Generate commit message using AI"
            >
              {isGeneratingMessage ? (
                <>
                  <RefreshCw size={10} className="animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Wand2 size={10} />
                  AI Auto-Fill
                </>
              )}
            </button>
          </div>
          <textarea
            value={commitMessage}
            onChange={(e) => setCommitMessage(e.target.value)}
            placeholder="Describe your changes..."
            rows={2}
            className="w-full resize-none rounded-md bg-bg-elevated border border-border text-[12px] text-text-primary placeholder:text-text-muted p-2 focus:border-border-focus focus:outline-none transition-colors leading-relaxed"
          />
        </div>

        {/* Smart suggestions */}
        {isDirty && (
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-[10px] text-text-muted">Suggest:</span>
            {[
              "refactor: improve variable handling",
              "feat: add new system instructions",
              "fix: correct prompt formatting",
            ].map((suggestion, i) => (
              <button
                key={i}
                onClick={() => setCommitMessage(suggestion)}
                className="text-[10px] text-text-tertiary px-1.5 py-0.5 rounded-sm bg-bg-elevated border border-border hover:border-border-strong hover:text-text-secondary transition-colors truncate max-w-[200px]"
              >
                {suggestion}
              </button>
            ))}
          </div>
        )}

        {/* Commit button */}
        <button
          onClick={handleCommit}
          disabled={(!isDirty && !commitMessage) || isCommitting}
          className={cn(
            "w-full h-8 rounded-md text-[12px] font-medium transition-all duration-150",
            "flex items-center justify-center gap-1.5",
            (isDirty || commitMessage) && !isCommitting
              ? "bg-white text-black hover:bg-zinc-200 active:scale-[0.98] shadow-subtle"
              : "bg-bg-elevated text-text-muted border border-border cursor-not-allowed"
          )}
        >
          {isCommitting ? (
            <RefreshCw size={13} className="animate-spin" />
          ) : (
            <ArrowUpFromLine size={13} />
          )}
          {isCommitting ? "Committing..." : "Commit to GitHub"}
        </button>

        {/* Secondary actions */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setCreatePrModalOpen(true)}
            className="flex-1 h-7 rounded-md text-[11px] font-medium text-text-secondary bg-bg-elevated border border-border hover:border-border-strong hover:text-text-primary transition-colors flex items-center justify-center gap-1 cursor-pointer"
          >
            <GitPullRequest size={12} />
            Create PR
          </button>
          <button
            onClick={openWorkspaceDiff}
            disabled={!isDirty}
            className={cn(
              "flex-1 h-7 rounded-md text-[11px] font-medium transition-colors flex items-center justify-center gap-1",
              isDirty
                ? "text-text-secondary bg-bg-elevated border border-border hover:border-border-strong hover:text-text-primary cursor-pointer"
                : "text-text-muted bg-bg-elevated/40 border border-border/50 cursor-not-allowed"
            )}
          >
            <Diff size={12} />
            View Diff
          </button>
        </div>
      </div>

      {/* Timeline */}
      <div className="flex-1 overflow-y-auto">
        <div className="p-3">
          <div className="flex items-center justify-between mb-3">
            <span className="text-[10px] text-text-muted uppercase tracking-widest font-medium">
              History
            </span>
            <span className="text-[10px] text-text-muted">
              {commits.length} commits
            </span>
          </div>

          <div className="space-y-0.5">
            {commits.map((commit, i) => {
              const isExpanded = expandedCommit === commit.id;

              return (
                <motion.div
                  key={commit.id}
                  initial={{ opacity: 0, y: 4 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.03 }}
                >
                  <div
                    onClick={() => {
                      const nextExpanded = isExpanded ? null : commit.id;
                      setExpandedCommit(nextExpanded);
                      if (nextExpanded) {
                        fetchCommitDetails(commit.id);
                      }
                    }}
                    className={cn(
                      "w-full text-left group rounded-md transition-colors duration-100 cursor-pointer",
                      "p-2 hover:bg-bg-hover",
                      isExpanded && "bg-bg-hover"
                    )}
                  >
                    <div className="flex items-start gap-2">
                      {/* Timeline dot */}
                      <div className="mt-1 flex-shrink-0 relative">
                        <div
                          className={cn(
                            "w-2 h-2 rounded-full border",
                            i === 0
                              ? "bg-white border-white"
                              : "bg-bg-elevated border-border-strong"
                          )}
                        />
                        {i < commits.length - 1 && (
                          <div className="absolute top-3 left-1/2 -translate-x-1/2 w-px h-[calc(100%+4px)] bg-border" />
                        )}
                      </div>

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <p className="text-[12px] text-text-primary leading-snug truncate">
                          {commit.message}
                        </p>
                        <div className="flex items-center gap-2 mt-1">
                          <code className="text-[10px] font-mono text-text-muted">
                            {commit.hash}
                          </code>
                          <span className="text-[10px] text-text-muted">
                            {timeAgo(commit.date)}
                          </span>
                        </div>
                      </div>

                      {/* Stats */}
                      <div className="flex items-center gap-1 flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
                        <span className="text-[10px] text-emerald-500 font-mono">
                          +{commit.additions}
                        </span>
                        <span className="text-[10px] text-red-500 font-mono">
                          -{commit.deletions}
                        </span>
                      </div>
                    </div>

                    {/* Expanded details */}
                    <AnimatePresence>
                      {isExpanded && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: "auto", opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.15 }}
                          className="overflow-hidden"
                        >
                          <div className="mt-2 ml-4 space-y-1.5">
                            {/* Author */}
                            <div className="flex items-center gap-1.5">
                              <div className="w-4 h-4 rounded-full bg-gradient-to-br from-zinc-600 to-zinc-800 flex items-center justify-center">
                                <span className="text-[6px] font-bold text-white">
                                  {commit.author.name
                                    .split(" ")
                                    .map((n) => n[0])
                                    .join("")}
                                </span>
                              </div>
                              <span className="text-[11px] text-text-secondary">
                                {commit.author.name}
                              </span>
                            </div>

                            {/* Files */}
                            <div className="space-y-1">
                              {commit.files.map((file) => (
                                <div
                                  key={file}
                                  className="group/file flex items-center justify-between text-[10.5px] text-text-muted hover:text-text-secondary"
                                >
                                  <div className="flex items-center gap-1.5 min-w-0">
                                    <FileText size={11} className="flex-shrink-0" />
                                    <span className="font-mono truncate">{file}</span>
                                  </div>
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      openCommitDiff(commit.id, file);
                                    }}
                                    className="opacity-0 group-hover/file:opacity-100 flex items-center gap-1 px-1 py-0.5 rounded text-[9.5px] font-medium text-text-secondary hover:text-text-primary bg-bg-elevated border border-border hover:border-border-strong transition-all duration-100 cursor-pointer"
                                  >
                                    <Diff size={10} />
                                    Diff
                                  </button>
                                </div>
                              ))}
                            </div>

                            {/* Actions */}
                            <div className="flex items-center gap-1 pt-1">
                              <button className="text-[10px] text-text-muted hover:text-text-primary transition-colors flex items-center gap-1 px-1.5 py-0.5 rounded bg-bg-elevated border border-border">
                                <Copy size={9} />
                                Copy hash
                              </button>
                              <button className="text-[10px] text-text-muted hover:text-text-primary transition-colors flex items-center gap-1 px-1.5 py-0.5 rounded bg-bg-elevated border border-border">
                                <ExternalLink size={9} />
                                GitHub
                              </button>
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
