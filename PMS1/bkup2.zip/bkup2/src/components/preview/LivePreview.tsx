"use client";

import React from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { useAppStore } from "@/store";
import { VariablePill } from "@/components/ui/VariablePill";
import { EyeOff } from "lucide-react";
import { Tooltip } from "@/components/ui/Tooltip";

function processVariables(text: string): React.ReactNode[] {
  const parts = text.split(/(\{\w+\})/g);
  return parts.map((part, i) => {
    const match = part.match(/^\{(\w+)\}$/);
    if (match) {
      return <VariablePill key={i} name={match[1]} size="sm" />;
    }
    return <React.Fragment key={i}>{part}</React.Fragment>;
  });
}

function VariableAwareText({ children }: { children: string }) {
  return <>{processVariables(children)}</>;
}

export function LivePreview() {
  const { editorContent, setPreviewPanelOpen } = useAppStore();

  return (
    <div className="h-full flex flex-col bg-bg-primary border-l border-border">
      {/* Preview header */}
      <div className="h-10 border-b border-border flex items-center justify-between px-3 flex-shrink-0">
        <span className="text-[12px] font-medium text-text-secondary">
          Preview
        </span>
        <Tooltip content="Hide Preview Panel">
          <button
            onClick={() => setPreviewPanelOpen(false)}
            className="h-6 w-6 flex items-center justify-center rounded-sm text-text-muted hover:text-text-primary hover:bg-bg-hover transition-colors cursor-pointer"
          >
            <EyeOff size={13} />
          </button>
        </Tooltip>
      </div>

      {/* Preview content */}
      <div className="flex-1 overflow-y-auto">
        <div className="markdown-preview p-5">
          <ReactMarkdown
            remarkPlugins={[remarkGfm]}
            components={{
              // Custom renderers to handle variables in text
              p: ({ children }) => {
                return (
                  <p>
                    {React.Children.map(children, (child) => {
                      if (typeof child === "string") {
                        return <VariableAwareText>{child}</VariableAwareText>;
                      }
                      return child;
                    })}
                  </p>
                );
              },
              li: ({ children }) => {
                return (
                  <li>
                    {React.Children.map(children, (child) => {
                      if (typeof child === "string") {
                        return <VariableAwareText>{child}</VariableAwareText>;
                      }
                      return child;
                    })}
                  </li>
                );
              },
              strong: ({ children }) => {
                return (
                  <strong>
                    {React.Children.map(children, (child) => {
                      if (typeof child === "string") {
                        return <VariableAwareText>{child}</VariableAwareText>;
                      }
                      return child;
                    })}
                  </strong>
                );
              },
              h1: ({ children }) => (
                <h1>
                  {React.Children.map(children, (child) => {
                    if (typeof child === "string") {
                      return <VariableAwareText>{child}</VariableAwareText>;
                    }
                    return child;
                  })}
                </h1>
              ),
              h2: ({ children }) => (
                <h2>
                  {React.Children.map(children, (child) => {
                    if (typeof child === "string") {
                      return <VariableAwareText>{child}</VariableAwareText>;
                    }
                    return child;
                  })}
                </h2>
              ),
              h3: ({ children }) => (
                <h3>
                  {React.Children.map(children, (child) => {
                    if (typeof child === "string") {
                      return <VariableAwareText>{child}</VariableAwareText>;
                    }
                    return child;
                  })}
                </h3>
              ),
            }}
          >
            {editorContent}
          </ReactMarkdown>
        </div>
      </div>
    </div>
  );
}
