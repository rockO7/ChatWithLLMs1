"use client";

import React, { useState } from "react";
import { useAppStore } from "@/store";
import { motion, AnimatePresence } from "framer-motion";
import { X, Settings, BookOpen, HelpCircle, Eye, EyeOff, Check, Keyboard, LifeBuoy } from "lucide-react";

export function SettingsDocsHelpModals() {
  const {
    settingsModalOpen,
    setSettingsModalOpen,
    docsModalOpen,
    setDocsModalOpen,
    helpModalOpen,
    setHelpModalOpen,
    editorSettings,
    setEditorSettings,
    addToast,
  } = useAppStore();

  // Local settings state
  const [fontSize, setFontSize] = useState(editorSettings.fontSize);
  const [wordWrap, setWordWrap] = useState(editorSettings.wordWrap);
  const [minimap, setMinimap] = useState(editorSettings.minimap);
  const [openaiKey, setOpenaiKey] = useState(editorSettings.openaiKey);
  const [anthropicKey, setAnthropicKey] = useState(editorSettings.anthropicKey);
  const [commitPrefix, setCommitPrefix] = useState(editorSettings.commitPrefix);
  const [showOpenai, setShowOpenai] = useState(false);
  const [showAnthropic, setShowAnthropic] = useState(false);

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    setEditorSettings({
      fontSize,
      wordWrap,
      minimap,
      openaiKey,
      anthropicKey,
      commitPrefix,
    });
    setSettingsModalOpen(false);
    addToast({
      type: "success",
      title: "Settings Saved",
      message: "Editor and API configurations updated successfully.",
    });
  };

  return (
    <AnimatePresence>
      {/* 1. Settings Modal */}
      {settingsModalOpen && (
        <div className="fixed inset-0 z-[999] flex items-center justify-center">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setSettingsModalOpen(false)}
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: 8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 8 }}
            className="relative w-[480px] max-h-[85vh] overflow-y-auto bg-bg-secondary border border-border rounded-xl shadow-elevated z-10 flex flex-col"
          >
            <div className="h-12 border-b border-border flex items-center justify-between px-4 flex-shrink-0 bg-bg-primary/50">
              <div className="flex items-center gap-2 text-text-primary">
                <Settings size={15} className="text-text-secondary" />
                <span className="text-[13px] font-semibold">Preferences & Configuration</span>
              </div>
              <button
                onClick={() => setSettingsModalOpen(false)}
                className="h-6 w-6 flex items-center justify-center rounded-sm text-text-muted hover:text-text-primary hover:bg-bg-hover transition-colors"
              >
                <X size={14} />
              </button>
            </div>

            <form onSubmit={handleSaveSettings} className="p-4 space-y-4 overflow-y-auto">
              {/* Editor Preferences */}
              <div className="space-y-3">
                <h3 className="text-[11px] font-bold uppercase tracking-wider text-text-muted">Editor Preferences</h3>
                <div className="grid grid-cols-2 gap-3 bg-bg-primary/45 border border-border/80 rounded-lg p-3">
                  <div className="space-y-1">
                    <label className="text-[10px] text-text-secondary font-semibold">Font Size</label>
                    <select
                      value={fontSize}
                      onChange={(e) => setFontSize(Number(e.target.value))}
                      className="w-full h-8 px-2 bg-bg-elevated border border-border rounded text-[11.5px] text-text-primary focus:outline-none focus:border-border-focus"
                    >
                      {[12, 13, 14, 15, 16, 18].map((size) => (
                        <option key={size} value={size}>{size}px</option>
                      ))}
                    </select>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] text-text-secondary font-semibold">Word Wrap</label>
                    <select
                      value={wordWrap}
                      onChange={(e) => setWordWrap(e.target.value as "on" | "off")}
                      className="w-full h-8 px-2 bg-bg-elevated border border-border rounded text-[11.5px] text-text-primary focus:outline-none focus:border-border-focus"
                    >
                      <option value="on">Wrap lines (On)</option>
                      <option value="off">No wrap (Off)</option>
                    </select>
                  </div>
                  <div className="col-span-2 flex items-center justify-between pt-1">
                    <span className="text-[11px] text-text-secondary">Show Code Minimap</span>
                    <input
                      type="checkbox"
                      checked={minimap}
                      onChange={(e) => setMinimap(e.target.checked)}
                      className="h-4 w-4 rounded border-border text-white bg-bg-elevated focus:ring-0 focus:ring-offset-0 cursor-pointer"
                    />
                  </div>
                </div>
              </div>

              {/* Version Prefix Settings */}
              <div className="space-y-3">
                <h3 className="text-[11px] font-bold uppercase tracking-wider text-text-muted">Git Versioning</h3>
                <div className="bg-bg-primary/45 border border-border/80 rounded-lg p-3 space-y-1.5">
                  <label className="text-[10px] text-text-secondary font-semibold">Default Commit Prefix</label>
                  <input
                    type="text"
                    value={commitPrefix}
                    onChange={(e) => setCommitPrefix(e.target.value)}
                    placeholder="e.g. feat: "
                    className="w-full h-8 px-2.5 rounded bg-bg-elevated border border-border text-[11.5px] text-text-primary placeholder:text-text-muted focus:outline-none focus:border-border-focus font-mono"
                  />
                </div>
              </div>

              {/* API Credentials */}
              <div className="space-y-3">
                <h3 className="text-[11px] font-bold uppercase tracking-wider text-text-muted">LLM Provider API Credentials</h3>
                <div className="bg-bg-primary/45 border border-border/80 rounded-lg p-3 space-y-3">
                  <div className="space-y-1.5">
                    <label className="text-[10px] text-text-secondary font-semibold flex items-center justify-between">
                      <span>OpenAI API Key</span>
                      <span className="text-[9px] text-text-muted">Used for Arena execution tests</span>
                    </label>
                    <div className="relative">
                      <input
                        type={showOpenai ? "text" : "password"}
                        value={openaiKey}
                        onChange={(e) => setOpenaiKey(e.target.value)}
                        placeholder="sk-..."
                        className="w-full h-8 pl-2.5 pr-8 rounded bg-bg-elevated border border-border text-[11.5px] text-text-primary placeholder:text-text-muted focus:outline-none focus:border-border-focus font-mono"
                      />
                      <button
                        type="button"
                        onClick={() => setShowOpenai(!showOpenai)}
                        className="absolute right-2 top-1/2 -translate-y-1/2 text-text-muted hover:text-text-secondary"
                      >
                        {showOpenai ? <EyeOff size={13} /> : <Eye size={13} />}
                      </button>
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[10px] text-text-secondary font-semibold flex items-center justify-between">
                      <span>Anthropic API Key</span>
                      <span className="text-[9px] text-text-muted">Used for Arena execution tests</span>
                    </label>
                    <div className="relative">
                      <input
                        type={showAnthropic ? "text" : "password"}
                        value={anthropicKey}
                        onChange={(e) => setAnthropicKey(e.target.value)}
                        placeholder="sk-ant-..."
                        className="w-full h-8 pl-2.5 pr-8 rounded bg-bg-elevated border border-border text-[11.5px] text-text-primary placeholder:text-text-muted focus:outline-none focus:border-border-focus font-mono"
                      />
                      <button
                        type="button"
                        onClick={() => setShowAnthropic(!showAnthropic)}
                        className="absolute right-2 top-1/2 -translate-y-1/2 text-text-muted hover:text-text-secondary"
                      >
                        {showAnthropic ? <EyeOff size={13} /> : <Eye size={13} />}
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Footer */}
              <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-border flex-shrink-0">
                <button
                  type="button"
                  onClick={() => setSettingsModalOpen(false)}
                  className="h-8 px-3 rounded-lg text-[11px] font-medium text-text-secondary hover:text-text-primary border border-border hover:border-border-strong hover:bg-bg-hover transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="h-8 px-4 rounded-lg text-[11px] font-semibold bg-white text-black hover:bg-zinc-200 transition-colors flex items-center gap-1.5 shadow-sm"
                >
                  <Check size={12} />
                  Save Preferences
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}

      {/* 2. Documentation Modal */}
      {docsModalOpen && (
        <div className="fixed inset-0 z-[999] flex items-center justify-center">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setDocsModalOpen(false)}
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: 8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 8 }}
            className="relative w-[560px] max-h-[80vh] bg-bg-secondary border border-border rounded-xl shadow-elevated z-10 flex flex-col"
          >
            <div className="h-12 border-b border-border flex items-center justify-between px-4 flex-shrink-0 bg-bg-primary/50">
              <div className="flex items-center gap-2 text-text-primary">
                <BookOpen size={15} className="text-text-secondary" />
                <span className="text-[13px] font-semibold">Documentation & Help Guides</span>
              </div>
              <button
                onClick={() => setDocsModalOpen(false)}
                className="h-6 w-6 flex items-center justify-center rounded-sm text-text-muted hover:text-text-primary hover:bg-bg-hover transition-colors"
              >
                <X size={14} />
              </button>
            </div>

            <div className="p-5 space-y-4 overflow-y-auto text-text-secondary text-[12.5px] leading-relaxed">
              <section className="space-y-1.5">
                <h4 className="text-[13px] font-bold text-text-primary flex items-center gap-1.5">
                  <span className="w-1 h-3.5 rounded bg-blue-500" />
                  Prompt Variable Substitution
                </h4>
                <p>
                  To make prompts dynamic, define template variables using single braces, like so: <code>{"{variable_name}"}</code>. 
                  PromptHub automatically detects these tags and populates inputs in the <strong>Testing Arena</strong> so you can configure custom values on the fly.
                </p>
              </section>

              <section className="space-y-1.5">
                <h4 className="text-[13px] font-bold text-text-primary flex items-center gap-1.5">
                  <span className="w-1 h-3.5 rounded bg-blue-500" />
                  GitHub Repository Syncing
                </h4>
                <p>
                  Securely authorize PromptHub with your GitHub account. Select isolated repositories dedicated to prompt files. Changes can be committed directly from the **Version Control** sidebar panel.
                </p>
              </section>

              <section className="space-y-1.5">
                <h4 className="text-[13px] font-bold text-text-primary flex items-center gap-1.5">
                  <span className="w-1 h-3.5 rounded bg-blue-500" />
                  LLM Comparison & Benchmarking
                </h4>
                <p>
                  Toggle the **Testing Arena** to evaluate your prompts. Execute the prompt across multiple selected models simultaneously (e.g. Claude, GPT, Gemini). Benchmark response latencies, input/output tokens, and rate outputs to fine-tune instructions.
                </p>
              </section>

              <div className="pt-4 border-t border-border flex justify-end">
                <button
                  onClick={() => setDocsModalOpen(false)}
                  className="h-8 px-4 rounded-lg text-[11px] font-semibold bg-white text-black hover:bg-zinc-200 transition-colors shadow-sm cursor-pointer"
                >
                  Got it
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}

      {/* 3. Help Modal */}
      {helpModalOpen && (
        <div className="fixed inset-0 z-[999] flex items-center justify-center">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setHelpModalOpen(false)}
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: 8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 8 }}
            className="relative w-[480px] bg-bg-secondary border border-border rounded-xl shadow-elevated z-10 flex flex-col"
          >
            <div className="h-12 border-b border-border flex items-center justify-between px-4 flex-shrink-0 bg-bg-primary/50">
              <div className="flex items-center gap-2 text-text-primary">
                <HelpCircle size={15} className="text-text-secondary" />
                <span className="text-[13px] font-semibold">Help & Support Resources</span>
              </div>
              <button
                onClick={() => setHelpModalOpen(false)}
                className="h-6 w-6 flex items-center justify-center rounded-sm text-text-muted hover:text-text-primary hover:bg-bg-hover transition-colors"
              >
                <X size={14} />
              </button>
            </div>

            <div className="p-4 space-y-4 text-text-secondary text-[12.5px] leading-relaxed">
              {/* Keyboard shortcuts */}
              <div className="space-y-2">
                <h4 className="text-[11.5px] font-bold uppercase tracking-wider text-text-muted flex items-center gap-1">
                  <Keyboard size={12} />
                  Keyboard Shortcuts
                </h4>
                <div className="grid grid-cols-2 gap-3 bg-bg-primary/45 border border-border/80 rounded-lg p-3.5 font-mono text-[11.5px] text-text-secondary">
                  <div className="flex justify-between items-center border-b border-border/50 pb-1.5">
                    <span>Command Palette</span>
                    <kbd className="bg-bg-elevated border border-border-strong px-1.5 py-0.5 rounded text-[10px] font-bold shadow-sm">⌘K</kbd>
                  </div>
                  <div className="flex justify-between items-center border-b border-border/50 pb-1.5">
                    <span>Save Draft File</span>
                    <kbd className="bg-bg-elevated border border-border-strong px-1.5 py-0.5 rounded text-[10px] font-bold shadow-sm">⌘S</kbd>
                  </div>
                  <div className="flex justify-between items-center border-b border-border/50 pb-1.5">
                    <span>Toggle Sidebar</span>
                    <kbd className="bg-bg-elevated border border-border-strong px-1.5 py-0.5 rounded text-[10px] font-bold shadow-sm">⌘B</kbd>
                  </div>
                  <div className="flex justify-between items-center border-b border-border/50 pb-1.5">
                    <span>Suggest Inline</span>
                    <kbd className="bg-bg-elevated border border-border-strong px-1.5 py-0.5 rounded text-[10px] font-bold shadow-sm">⌘J</kbd>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Open Editor</span>
                    <kbd className="bg-bg-elevated border border-border-strong px-1.5 py-0.5 rounded text-[10px] font-bold shadow-sm">⌘1</kbd>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Open Arena</span>
                    <kbd className="bg-bg-elevated border border-border-strong px-1.5 py-0.5 rounded text-[10px] font-bold shadow-sm">⌘2</kbd>
                  </div>
                </div>
              </div>

              {/* Troubleshooting */}
              <div className="space-y-2">
                <h4 className="text-[11.5px] font-bold uppercase tracking-wider text-text-muted flex items-center gap-1">
                  <LifeBuoy size={12} />
                  Troubleshooting
                </h4>
                <div className="space-y-2 bg-bg-primary/45 border border-border/80 rounded-lg p-3 text-[11.5px]">
                  <p>
                    <strong>GitHub API Rate Limiting:</strong> If repository trees or commits fail to load, ensure your token is valid and not expired. Try logging out and reconnecting.
                  </p>
                  <p>
                    <strong>Testing Arena simulation:</strong> You must configure target variables under variables section in the configurations panel to substitute variables correctly.
                  </p>
                </div>
              </div>

              <div className="pt-2 border-t border-border flex justify-end">
                <button
                  onClick={() => setHelpModalOpen(false)}
                  className="h-8 px-4 rounded-lg text-[11px] font-semibold bg-white text-black hover:bg-zinc-200 transition-colors shadow-sm cursor-pointer"
                >
                  Dismiss
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
