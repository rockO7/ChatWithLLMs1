"use client";

import React, { useState } from "react";
import { useAppStore } from "@/store";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";
import Image from "next/image";
import {
  PanelLeftClose,
  PanelLeftOpen,
  Search,
  GitBranch,
  Keyboard,
  Beaker,
  Code2,
  Bell,
  Sun,
  Moon,
  ChevronDown,
  Layers,
} from "lucide-react";
import { Tooltip } from "@/components/ui/Tooltip";

export function TopBar() {
  const {
    viewMode,
    setViewMode,
    sidebarOpen,
    setSidebarOpen,
    setCommandPaletteOpen,
    currentRepository,
    selectRepository,
    themeMode,
    toggleThemeMode,
    isAuthenticated,
    user,
    login,
    logout,
    addToast,
    currentBranch,
    branches,
    selectBranch,
    createBranch,
  } = useAppStore();

  const [branchDropdownOpen, setBranchDropdownOpen] = useState(false);
  const [branchSearch, setBranchSearch] = useState("");

  return (
    <div className="h-14 border-b border-border flex items-center justify-between px-3 bg-bg-primary/80 backdrop-blur-md flex-shrink-0 select-none sticky top-0 z-50">
      {/* Left section */}
      <div className="flex items-center gap-1">
        {viewMode === "editor" && (
          <>
            <Tooltip content={sidebarOpen ? "Close sidebar" : "Open sidebar"}>
              <button
                onClick={() => setSidebarOpen(!sidebarOpen)}
                className="h-7 w-7 flex items-center justify-center rounded-sm text-text-tertiary hover:text-text-primary hover:bg-bg-hover transition-colors duration-150"
              >
                {sidebarOpen ? (
                  <PanelLeftClose size={15} />
                ) : (
                  <PanelLeftOpen size={15} />
                )}
              </button>
            </Tooltip>

            <div className="mx-2 h-4 w-px bg-border" />
          </>
        )}

        {/* Logo */}
        <div
          onClick={() => selectRepository(null)}
          className="flex items-center gap-2 mr-4 cursor-pointer hover:opacity-80 transition-opacity"
          title="Return to Dashboard"
        >
          <div className="h-5 w-5 bg-white rounded-[4px] flex items-center justify-center shadow-sm">
            <span className="text-[10px] font-bold text-black leading-none">P</span>
          </div>
          <span className="text-[13px] font-semibold tracking-tight text-text-primary">
            PromptHub
          </span>
        </div>

        {/* Repo indicator */}
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-bg-elevated/40 border border-border text-[12.5px] text-text-secondary relative shadow-sm">
          <button
            onClick={() => {
              selectRepository(null);
              setViewMode("editor");
            }}
            className="hover:text-text-primary transition-colors flex items-center gap-1.5 font-medium"
            title="Click to return to dashboard"
          >
            <GitBranch size={12} className="text-text-tertiary" />
            <span className="text-text-primary font-medium">{currentRepository || "PromptHub Marketplace"}</span>
          </button>

          {currentRepository && (
            <>
              <span className="text-text-muted select-none">/</span>

              {/* Branch Dropdown Toggle Button */}
              <button
                onClick={() => setBranchDropdownOpen(!branchDropdownOpen)}
                className="text-text-secondary hover:text-text-primary transition-colors font-medium flex items-center gap-0.5 cursor-pointer"
                title="Click to switch or create branches"
              >
                <span>{currentBranch}</span>
                <ChevronDown size={11} className="text-text-muted" />
              </button>

              {/* Branch Switcher Dropdown Popover */}
              {branchDropdownOpen && (
                <>
                  {/* Backdrop to close dropdown */}
                  <div className="fixed inset-0 z-40 animate-none" onClick={() => setBranchDropdownOpen(false)} />
                  <div className="absolute top-[calc(100%+6px)] left-0 w-64 bg-bg-secondary/95 backdrop-blur-lg border border-border rounded-lg shadow-2xl p-2.5 z-50 flex flex-col gap-2 animate-in fade-in slide-in-from-top-2 duration-150">
                    <div className="text-[10px] text-text-muted uppercase tracking-wider font-semibold px-1 py-0.5 select-none">
                      Switch branches / tags
                    </div>
                    <input
                      type="text"
                      autoFocus
                      value={branchSearch}
                      onChange={(e) => setBranchSearch(e.target.value)}
                      placeholder="Find or create a branch..."
                      className="w-full h-7 px-2.5 rounded bg-bg-elevated border border-border text-[11.5px] text-text-primary placeholder:text-text-muted focus:outline-none focus:border-border-focus"
                    />
                    <div className="max-h-48 overflow-y-auto space-y-0.5">
                      {branches
                        .filter((b) => b.toLowerCase().includes(branchSearch.toLowerCase()))
                        .map((branch) => (
                          <button
                            key={branch}
                            onClick={() => {
                              selectBranch(branch);
                              setBranchDropdownOpen(false);
                              setBranchSearch("");
                            }}
                            className={cn(
                              "w-full text-left px-2 py-1.5 rounded text-[11.5px] flex items-center justify-between transition-colors cursor-pointer",
                              branch === currentBranch
                                ? "bg-white/[0.06] text-text-primary font-medium"
                                : "text-text-secondary hover:bg-white/[0.04] hover:text-text-primary"
                            )}
                          >
                            <span className="truncate">{branch}</span>
                            {branch === currentBranch && <span className="text-[10px]">✓</span>}
                          </button>
                        ))}

                      {/* Create branch option if search query doesn't match any branches */}
                      {branchSearch && !branches.some((b) => b.toLowerCase() === branchSearch.toLowerCase()) && (
                        <button
                          onClick={() => {
                            createBranch(branchSearch);
                            setBranchDropdownOpen(false);
                            setBranchSearch("");
                          }}
                          className="w-full text-left px-2 py-2 rounded text-[11.5px] text-text-primary bg-white/[0.03] hover:bg-white/[0.06] border border-border hover:border-border-strong transition-colors flex flex-col gap-0.5 cursor-pointer"
                        >
                          <span className="text-[10px] text-text-muted select-none">Create branch:</span>
                          <span className="font-mono text-emerald-400 font-medium truncate">{branchSearch}</span>
                          <span className="text-[9px] text-text-muted select-none">from &apos;{currentBranch}&apos;</span>
                        </button>
                      )}
                    </div>
                  </div>
                </>
              )}
            </>
          )}
        </div>
      </div>

      {/* Center — Mode tabs */}
      <div className="flex items-center">
        <div className="flex items-center bg-bg-elevated rounded-md border border-border p-0.5">
          {currentRepository && (
            <>
              <button
                onClick={() => setViewMode("editor")}
                className={cn(
                  "relative flex items-center gap-1.5 px-3 py-1 rounded-[4px] text-[12px] font-medium transition-colors duration-150",
                  viewMode === "editor"
                    ? "text-text-primary"
                    : "text-text-tertiary hover:text-text-secondary"
                )}
              >
                {viewMode === "editor" && (
                  <motion.div
                    layoutId="viewTab"
                    className="absolute inset-0 bg-bg-hover rounded-[4px] border border-border"
                    transition={{ type: "spring", bounce: 0.15, duration: 0.4 }}
                  />
                )}
                <Code2 size={13} className="relative z-10" />
                <span className="relative z-10">Editor</span>
              </button>
              <button
                onClick={() => setViewMode("testing")}
                className={cn(
                  "relative flex items-center gap-1.5 px-3 py-1 rounded-[4px] text-[12px] font-medium transition-colors duration-150",
                  viewMode === "testing"
                    ? "text-text-primary"
                    : "text-text-tertiary hover:text-text-secondary"
                )}
              >
                {viewMode === "testing" && (
                  <motion.div
                    layoutId="viewTab"
                    className="absolute inset-0 bg-bg-hover rounded-[4px] border border-border"
                    transition={{ type: "spring", bounce: 0.15, duration: 0.4 }}
                  />
                )}
                <Beaker size={13} className="relative z-10" />
                <span className="relative z-10">Testing Arena</span>
              </button>
            </>
          )}
          {!currentRepository && (
            <button
              onClick={() => setViewMode("marketplace")}
              className={cn(
                "relative flex items-center gap-1.5 px-3 py-1 rounded-[4px] text-[12px] font-medium transition-colors duration-150",
                viewMode === "marketplace"
                  ? "text-text-primary animate-none"
                  : "text-text-tertiary hover:text-text-secondary"
              )}
            >
              {viewMode === "marketplace" && (
                <motion.div
                  layoutId="viewTab"
                  className="absolute inset-0 bg-bg-hover rounded-[4px] border border-border"
                  transition={{ type: "spring", bounce: 0.15, duration: 0.4 }}
                />
              )}
              <Layers size={13} className="relative z-10 text-emerald-400" />
              <span className="relative z-10 text-emerald-400">Marketplace</span>
            </button>
          )}
        </div>
      </div>

      {/* Right section */}
      <div className="flex items-center gap-1">
        {/* Search */}
        <Tooltip content="Search (⌘K)">
          <button
            onClick={() => setCommandPaletteOpen(true)}
            className="h-7 flex items-center gap-2 px-2 rounded-md text-text-tertiary hover:text-text-secondary bg-bg-elevated border border-border hover:border-border-strong transition-all duration-150"
          >
            <Search size={13} />
            <span className="text-[11px] text-text-muted">Search...</span>
            <kbd className="text-[10px] text-text-muted bg-bg-primary border border-border rounded px-1 py-0.5 font-mono">
              ⌘K
            </kbd>
          </button>
        </Tooltip>

        <Tooltip content="Keyboard shortcuts">
          <button className="h-7 w-7 flex items-center justify-center rounded-sm text-text-tertiary hover:text-text-primary hover:bg-bg-hover transition-colors duration-150">
            <Keyboard size={14} />
          </button>
        </Tooltip>

        <Tooltip content="Notifications">
          <button
            onClick={() => addToast({ type: "info", title: "Notifications", message: "No new notifications as of now." })}
            className="h-7 w-7 flex items-center justify-center rounded-sm text-text-tertiary hover:text-text-primary hover:bg-bg-hover transition-colors duration-150 relative"
          >
            <Bell size={14} />
          </button>
        </Tooltip>

        {/* Theme Toggle */}
        <Tooltip content={themeMode === "dark" ? "Switch to Light Mode" : "Switch to Dark Mode"}>
          <button
            onClick={toggleThemeMode}
            className="h-7 w-7 flex items-center justify-center rounded-sm text-text-tertiary hover:text-text-primary hover:bg-bg-hover transition-colors duration-150"
          >
            {themeMode === "dark" ? <Sun size={14} /> : <Moon size={14} />}
          </button>
        </Tooltip>

        <div className="mx-1 h-4 w-px bg-border" />

        {/* Live User Info / Connect button */}
        {isAuthenticated ? (
          <div className="flex items-center gap-2 border border-border bg-bg-elevated/40 pl-1.5 pr-2.5 py-1 rounded-lg shadow-sm">
            {user?.avatar_url && (
              <Image
                src={user.avatar_url}
                alt={user.name || ""}
                width={20}
                height={20}
                className="h-5 w-5 rounded-full border border-border/50"
              />
            )}
            <span className="text-[11.5px] font-semibold text-text-secondary hidden md:inline">{user?.name}</span>
            <span className="text-border-strong text-[10px] hidden md:inline select-none">·</span>
            <button
              onClick={logout}
              className="text-[11px] text-text-muted hover:text-text-primary transition-colors cursor-pointer"
            >
              Logout
            </button>
          </div>
        ) : (
          <button
            onClick={login}
            className="h-8 px-2.5 rounded-lg text-[11px] font-bold bg-white text-black hover:bg-zinc-200 transition-colors flex items-center gap-1.5 cursor-pointer shadow-subtle animate-pulse-slow"
          >
            Connect GitHub
          </button>
        )}
      </div>
    </div>
  );
}
