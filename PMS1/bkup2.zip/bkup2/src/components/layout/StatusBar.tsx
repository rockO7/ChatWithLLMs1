"use client";

import React from "react";
import { useAppStore } from "@/store";
import { timeAgo } from "@/lib/utils";
import {
  GitBranch,
  Wifi,
  WifiOff,
  Loader2,
  Check,
  AlertCircle,
} from "lucide-react";

export function StatusBar() {
  const {
    syncStatus,
    lastSaved,
    isDirty,
    editorContent,
    detectedVariables,
    currentBranch,
  } = useAppStore();

  const lines = editorContent.split("\n").length;
  const chars = editorContent.length;

  return (
    <div className="h-6 border-t border-border bg-bg-primary flex items-center justify-between px-3 text-[10px] text-text-muted select-none flex-shrink-0">
      {/* Left */}
      <div className="flex items-center gap-3">
        {/* Sync status */}
        <div className="flex items-center gap-1.5">
          {syncStatus === "connected" && (
            <>
              <Wifi size={10} className="text-emerald-500" />
              <span className="text-emerald-500/80">Connected</span>
            </>
          )}
          {syncStatus === "syncing" && (
            <>
              <Loader2 size={10} className="text-yellow-500 animate-spin" />
              <span className="text-yellow-500/80">Syncing...</span>
            </>
          )}
          {syncStatus === "disconnected" && (
            <>
              <WifiOff size={10} className="text-red-500" />
              <span className="text-red-500/80">Disconnected</span>
            </>
          )}
        </div>

        <div className="h-3 w-px bg-border" />

        {/* Branch */}
        <div className="flex items-center gap-1">
          <GitBranch size={10} />
          <span>{currentBranch}</span>
        </div>

        {/* Dirty state */}
        {isDirty && (
          <>
            <div className="h-3 w-px bg-border" />
            <div className="flex items-center gap-1 text-yellow-500/70">
              <AlertCircle size={10} />
              <span>Unsaved changes</span>
            </div>
          </>
        )}

        {!isDirty && lastSaved && (
          <>
            <div className="h-3 w-px bg-border" />
            <div className="flex items-center gap-1">
              <Check size={10} className="text-emerald-500/70" />
              <span>Saved {timeAgo(lastSaved)}</span>
            </div>
          </>
        )}
      </div>

      {/* Right */}
      <div className="flex items-center gap-3">
        {detectedVariables.length > 0 && (
          <span>
            {detectedVariables.length} variable{detectedVariables.length !== 1 ? "s" : ""}
          </span>
        )}
        <div className="h-3 w-px bg-border" />
        <span>
          {lines} lines · {chars} chars
        </span>
        <div className="h-3 w-px bg-border" />
        <span>Markdown</span>
        <div className="h-3 w-px bg-border" />
        <span>UTF-8</span>
      </div>
    </div>
  );
}