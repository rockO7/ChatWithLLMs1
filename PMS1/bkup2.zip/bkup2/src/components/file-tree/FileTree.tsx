"use client";

import React, { useState, useRef, useEffect } from "react";
import { useAppStore } from "@/store";
import { FileNode } from "@/types";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";
import {
  ChevronRight,
  ChevronDown,
  FileText,
  FolderOpen,
  Folder,
  FileJson,
  FileCode2,
  Search,
  FolderPlus,
  FilePlus,
  Settings,
  BookOpen,
  HelpCircle,
  GitBranch,
} from "lucide-react";
import { Tooltip } from "@/components/ui/Tooltip";

function FileIcon({ extension, isFolder, isOpen }: { extension?: string; isFolder?: boolean; isOpen?: boolean }) {
  if (isFolder) {
    return isOpen ? (
      <FolderOpen size={14} className="text-text-tertiary flex-shrink-0" />
    ) : (
      <Folder size={14} className="text-text-tertiary flex-shrink-0" />
    );
  }

  switch (extension) {
    case "json":
      return <FileJson size={14} className="text-yellow-500/60 flex-shrink-0" />;
    case "yaml":
    case "yml":
      return <FileCode2 size={14} className="text-purple-400/60 flex-shrink-0" />;
    default:
      return <FileText size={14} className="text-text-tertiary flex-shrink-0" />;
  }
}

function FileTreeNode({ node, depth = 0 }: { node: FileNode; depth?: number }) {
  const { selectedFile, setSelectedFile, expandedFolders, toggleFolder, createFile, createFolder } = useAppStore();
  const isFolder = node.type === "folder";
  const isOpen = expandedFolders.has(node.id);
  const isSelected = selectedFile?.id === node.id;

  const [isCreating, setIsCreating] = useState<"file" | "folder" | null>(null);
  const [newItemName, setNewItemName] = useState("");

  const handleClick = () => {
    if (isFolder) {
      toggleFolder(node.id);
    } else {
      setSelectedFile(node);
    }
  };

  const handleCreateFile = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!isOpen) {
      toggleFolder(node.id);
    }
    setIsCreating("file");
    setNewItemName("");
  };

  const handleCreateFolder = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!isOpen) {
      toggleFolder(node.id);
    }
    setIsCreating("folder");
    setNewItemName("");
  };

  const handleConfirmCreate = () => {
    if (isCreating && newItemName.trim()) {
      if (isCreating === "file") {
        createFile(node.id, newItemName.trim());
      } else {
        createFolder(node.id, newItemName.trim());
      }
    }
    setIsCreating(null);
    setNewItemName("");
  };

  const handleCancelCreate = () => {
    setIsCreating(null);
    setNewItemName("");
  };

  return (
    <div>
      <div
        onClick={handleClick}
        className={cn(
          "group w-full flex items-center gap-1.5 py-[6px] pr-2 text-[12.5px] border-l-2",
          "transition-all duration-150 cursor-pointer",
          isSelected
            ? "bg-gradient-to-r from-indigo-500/8 to-transparent text-text-primary border-indigo-500 font-medium"
            : "text-text-secondary hover:bg-white/[0.02] hover:text-text-primary border-transparent"
        )}
        style={{ paddingLeft: `${depth * 14 + 6}px` }}
      >
        {/* Chevron for folders */}
        {isFolder ? (
          <motion.div
            animate={{ rotate: isOpen ? 90 : 0 }}
            transition={{ duration: 0.15 }}
            className="flex-shrink-0"
          >
            <ChevronRight size={12} className="text-text-muted" />
          </motion.div>
        ) : (
          <span className="w-3 flex-shrink-0" />
        )}

        <FileIcon extension={node.extension} isFolder={isFolder} isOpen={isOpen} />

        <span className={cn(
          "truncate flex-1 text-left",
          isFolder && "font-medium"
        )}>
          {node.name}
        </span>

        {/* Hover Creation buttons for folders */}
        {isFolder && (
          <div className="hidden group-hover:flex items-center gap-1">
            <button
              onClick={handleCreateFile}
              className="p-0.5 rounded hover:bg-bg-active text-text-muted hover:text-text-primary transition-colors"
              title="New File"
            >
              <FilePlus size={12} />
            </button>
            <button
              onClick={handleCreateFolder}
              className="p-0.5 rounded hover:bg-bg-active text-text-muted hover:text-text-primary transition-colors"
              title="New Folder"
            >
              <FolderPlus size={12} />
            </button>
          </div>
        )}

        {/* Status indicator */}
        {node.status && !isFolder && (
          <span
            className={cn(
              "w-1.5 h-1.5 rounded-full flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity",
              node.status === "synced" && "bg-emerald-500 opacity-60",
              node.status === "draft" && "bg-yellow-500 opacity-100",
              node.status === "behind" && "bg-red-500 opacity-100",
              node.status === "modified" && "bg-amber-500 opacity-100"
            )}
          />
        )}
      </div>

      {/* Children */}
      <AnimatePresence initial={false}>
        {isFolder && isOpen && node.children && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.15, ease: "easeOut" }}
            className="overflow-hidden"
          >
            {isCreating && (
              <div
                className="flex items-center gap-1.5 py-[5px] pr-2 rounded-[4px]"
                style={{ paddingLeft: `${(depth + 1) * 14 + 8}px` }}
              >
                <span className="w-3" />
                <FileIcon extension={isCreating === "file" ? "md" : undefined} isFolder={isCreating === "folder"} isOpen={false} />
                <input
                  autoFocus
                  type="text"
                  value={newItemName}
                  onChange={(e) => setNewItemName(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      handleConfirmCreate();
                    } else if (e.key === "Escape") {
                      handleCancelCreate();
                    }
                  }}
                  onBlur={handleConfirmCreate}
                  className="flex-1 min-w-0 h-6 px-1.5 bg-bg-elevated border border-border-focus rounded text-[12px] text-text-primary focus:outline-none"
                  placeholder={isCreating === "file" ? "file.md" : "folder"}
                />
              </div>
            )}
            {node.children.map((child) => (
              <FileTreeNode key={child.id} node={child} depth={depth + 1} />
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export function FileTree() {
  const {
    fileTree,
    sidebarOpen,
    currentRepository,
    createFile,
    createFolder,
    setSettingsModalOpen,
    setDocsModalOpen,
    setHelpModalOpen,
    currentBranch,
    branches,
    selectBranch,
  } = useAppStore();
  const [searchQuery, setSearchQuery] = useState("");
  const [isCreatingRoot, setIsCreatingRoot] = useState<"file" | "folder" | null>(null);
  const [newRootItemName, setNewRootItemName] = useState("");
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  if (!sidebarOpen) return null;

  const handleCreateFileRoot = () => {
    setIsCreatingRoot("file");
    setNewRootItemName("");
  };

  const handleCreateFolderRoot = () => {
    setIsCreatingRoot("folder");
    setNewRootItemName("");
  };

  const handleConfirmCreateRoot = () => {
    if (isCreatingRoot && newRootItemName.trim()) {
      if (isCreatingRoot === "file") {
        createFile(null, newRootItemName.trim());
      } else {
        createFolder(null, newRootItemName.trim());
      }
    }
    setIsCreatingRoot(null);
    setNewRootItemName("");
  };

  const handleCancelCreateRoot = () => {
    setIsCreatingRoot(null);
    setNewRootItemName("");
  };

  return (
    <div className="h-full flex flex-col bg-bg-primary border-r border-border overflow-hidden">
      {/* Header */}
      <div className="p-3 border-b border-border space-y-2.5">
        {/* Repo info */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="h-5 w-5 rounded-full bg-gradient-to-br from-zinc-700 to-zinc-900 border border-border flex items-center justify-center">
              <span className="text-[8px] font-bold text-white">
                {(currentRepository || "A").substring(0, 1).toUpperCase()}
              </span>
            </div>
            <div className="relative" ref={dropdownRef}>
              <button
                onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                className="h-6 px-2 bg-bg-secondary hover:bg-bg-hover border border-border hover:border-border-strong rounded text-[11.5px] font-medium text-text-secondary hover:text-text-primary transition-all flex items-center gap-1.5 cursor-pointer select-none"
              >
                <GitBranch size={11} className="text-text-muted flex-shrink-0" />
                <span className="truncate max-w-[80px]">{currentBranch}</span>
                <ChevronDown size={10} className="text-text-muted opacity-80" />
              </button>

              {isDropdownOpen && (
                <div className="absolute left-0 top-full mt-1.5 w-44 bg-bg-elevated border border-border rounded-md shadow-xl py-1 z-50 animate-in fade-in duration-100">
                  <div className="px-2.5 py-1 text-[9.5px] font-bold uppercase tracking-wider text-text-muted border-b border-border/60 mb-1">
                    Switch Branch
                  </div>
                  <div className="max-h-48 overflow-y-auto">
                    {branches.map((b) => (
                      <button
                        key={b}
                        onClick={async () => {
                          await selectBranch(b);
                          setIsDropdownOpen(false);
                        }}
                        className={cn(
                          "w-full text-left px-2.5 py-1.5 text-[11.5px] transition-colors flex items-center justify-between cursor-pointer",
                          b === currentBranch
                            ? "bg-white/[0.06] text-text-primary font-medium"
                            : "text-text-secondary hover:bg-white/[0.04] hover:text-text-primary"
                        )}
                      >
                        <span className="truncate">{b}</span>
                        {b === currentBranch && (
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                        )}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
          <div className="flex items-center gap-1">
            <Tooltip content="New File at Root">
              <button
                onClick={handleCreateFileRoot}
                className="h-6 w-6 flex items-center justify-center rounded-sm text-text-muted hover:text-text-primary hover:bg-bg-hover transition-colors"
              >
                <FilePlus size={13} />
              </button>
            </Tooltip>
            <Tooltip content="New Folder at Root">
              <button
                onClick={handleCreateFolderRoot}
                className="h-6 w-6 flex items-center justify-center rounded-sm text-text-muted hover:text-text-primary hover:bg-bg-hover transition-colors"
              >
                <FolderPlus size={13} />
              </button>
            </Tooltip>
          </div>
        </div>

        {/* Search */}
        <div className="relative">
          <Search size={13} className="absolute left-2 top-1/2 -translate-y-1/2 text-text-muted" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search files..."
            className="w-full h-7 pl-7 pr-2 rounded-md bg-bg-elevated border border-border text-[12px] text-text-primary placeholder:text-text-muted focus:border-border-focus focus:outline-none transition-colors"
          />
        </div>
      </div>

      {/* Tree */}
      <div className="flex-1 overflow-y-auto py-1.5 px-1.5">
        {isCreatingRoot && (
          <div
            className="flex items-center gap-1.5 py-[5px] pr-2 rounded-[4px]"
            style={{ paddingLeft: "8px" }}
          >
            <span className="w-3" />
            <FileIcon extension={isCreatingRoot === "file" ? "md" : undefined} isFolder={isCreatingRoot === "folder"} isOpen={false} />
            <input
              autoFocus
              type="text"
              value={newRootItemName}
              onChange={(e) => setNewRootItemName(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  handleConfirmCreateRoot();
                } else if (e.key === "Escape") {
                  handleCancelCreateRoot();
                }
              }}
              onBlur={handleConfirmCreateRoot}
              className="flex-1 min-w-0 h-6 px-1.5 bg-bg-elevated border border-border-focus rounded text-[12px] text-text-primary focus:outline-none"
              placeholder={isCreatingRoot === "file" ? "file.md" : "folder"}
            />
          </div>
        )}
        {fileTree.map((node) => (
          <FileTreeNode key={node.id} node={node} />
        ))}
      </div>

      {/* Footer */}
      <div className="border-t border-border p-2 flex items-center justify-between">
        <div className="flex items-center gap-0.5">
          <Tooltip content="Settings" side="right">
            <button
              onClick={() => setSettingsModalOpen(true)}
              className="h-7 w-7 flex items-center justify-center rounded-sm text-text-muted hover:text-text-secondary hover:bg-bg-hover transition-colors"
            >
              <Settings size={14} />
            </button>
          </Tooltip>
          <Tooltip content="Documentation" side="right">
            <button
              onClick={() => setDocsModalOpen(true)}
              className="h-7 w-7 flex items-center justify-center rounded-sm text-text-muted hover:text-text-secondary hover:bg-bg-hover transition-colors"
            >
              <BookOpen size={14} />
            </button>
          </Tooltip>
          <Tooltip content="Help" side="right">
            <button
              onClick={() => setHelpModalOpen(true)}
              className="h-7 w-7 flex items-center justify-center rounded-sm text-text-muted hover:text-text-secondary hover:bg-bg-hover transition-colors"
            >
              <HelpCircle size={14} />
            </button>
          </Tooltip>
        </div>
        <div className="flex items-center gap-1 text-[10px] text-text-muted">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
          <span>12 prompts</span>
        </div>
      </div>
    </div>
  );
}
