"use client";

import React from "react";
import { cn } from "@/lib/utils";

interface VariablePillProps {
  name: string;
  className?: string;
  interactive?: boolean;
  onClick?: () => void;
  size?: "sm" | "md";
}

export function VariablePill({
  name,
  className,
  interactive = false,
  onClick,
  size = "sm",
}: VariablePillProps) {
  return (
    <span
      onClick={onClick}
      className={cn(
        "inline-flex items-center gap-1 font-mono",
        "bg-white/[0.06] border border-white/[0.1] rounded",
        "transition-all duration-150",
        size === "sm" && "px-1.5 py-[1px] text-[11px]",
        size === "md" && "px-2 py-0.5 text-xs",
        interactive && "cursor-pointer hover:bg-white/[0.1] hover:border-white/[0.15]",
        "text-zinc-300",
        className
      )}
    >
      <span className="text-zinc-500 text-[0.85em]">{"{"}</span>
      {name}
      <span className="text-zinc-500 text-[0.85em]">{"}"}</span>
    </span>
  );
}
