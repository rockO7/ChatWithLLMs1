"use client";

import React from "react";
import { cn } from "@/lib/utils";

export function Skeleton({ className }: { className?: string }) {
  return <div className={cn("skeleton", className)} />;
}

export function EditorSkeleton() {
  return (
    <div className="p-6 space-y-3 animate-fade-in">
      <Skeleton className="h-6 w-48" />
      <Skeleton className="h-4 w-full" />
      <Skeleton className="h-4 w-[90%]" />
      <Skeleton className="h-4 w-[75%]" />
      <div className="h-4" />
      <Skeleton className="h-4 w-[85%]" />
      <Skeleton className="h-4 w-full" />
      <Skeleton className="h-4 w-[60%]" />
      <div className="h-4" />
      <Skeleton className="h-4 w-[95%]" />
      <Skeleton className="h-4 w-[80%]" />
      <Skeleton className="h-4 w-[70%]" />
    </div>
  );
}

export function FileTreeSkeleton() {
  return (
    <div className="p-3 space-y-2 animate-fade-in">
      {Array.from({ length: 8 }).map((_, i) => (
        <div key={i} className="flex items-center gap-2" style={{ paddingLeft: `${(i % 3) * 16}px` }}>
          <Skeleton className="h-4 w-4 rounded-xs" />
          <Skeleton className={`h-3.5 w-${[20, 24, 28, 32, 36][i % 5]}`} />
        </div>
      ))}
    </div>
  );
}
