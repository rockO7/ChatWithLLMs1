"use client";

import React from "react";
import { cn } from "@/lib/utils";
import { FileStatus } from "@/types";

interface StatusPillProps {
  status: FileStatus;
  className?: string;
}

const statusConfig: Record<FileStatus, { label: string; dotColor: string; bgColor: string; textColor: string }> = {
  draft: {
    label: "Draft",
    dotColor: "bg-yellow-500",
    bgColor: "bg-yellow-500/10",
    textColor: "text-yellow-500",
  },
  synced: {
    label: "Synced",
    dotColor: "bg-emerald-500",
    bgColor: "bg-emerald-500/10",
    textColor: "text-emerald-500",
  },
  behind: {
    label: "Behind",
    dotColor: "bg-red-500",
    bgColor: "bg-red-500/10",
    textColor: "text-red-500",
  },
  modified: {
    label: "Modified",
    dotColor: "bg-amber-500",
    bgColor: "bg-amber-500/10",
    textColor: "text-amber-500",
  },
  new: {
    label: "New",
    dotColor: "bg-blue-400",
    bgColor: "bg-blue-400/10",
    textColor: "text-blue-400",
  },
};

export function StatusPill({ status, className }: StatusPillProps) {
  const config = statusConfig[status];

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-medium tracking-wide uppercase",
        config.bgColor,
        config.textColor,
        className
      )}
    >
      <span className={cn("w-1.5 h-1.5 rounded-full", config.dotColor)} />
      {config.label}
    </span>
  );
}
