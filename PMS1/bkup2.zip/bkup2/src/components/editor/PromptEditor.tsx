"use client";

import React, { useState } from "react";
import Editor, { DiffEditor, Monaco } from "@monaco-editor/react";
import { useAppStore } from "@/store";
import { StatusPill } from "@/components/ui/StatusPill";
import { Tooltip } from "@/components/ui/Tooltip";
import {
  RotateCcw,
  Copy,
  Clock,
  User,
  Wand2,
  Check,
  X,
  ArrowRightLeft,
} from "lucide-react";
import { timeAgo } from "@/lib/utils";

const getLanguageFromFilename = (filename: string) => {
  const ext = filename.split(".").pop()?.toLowerCase();
  switch (ext) {
    case "md":
    case "mdx":
      return "markdown";
    case "txt":
      return "plaintext";
    case "json":
      return "json";
    case "js":
      return "javascript";
    case "jsx":
      return "javascript";
    case "ts":
      return "typescript";
    case "tsx":
      return "typescript";
    case "py":
      return "python";
    case "go":
      return "go";
    case "yaml":
    case "yml":
      return "yaml";
    case "sh":
    case "bash":
      return "shell";
    case "html":
      return "html";
    case "css":
      return "css";
    case "scss":
      return "scss";
    case "sql":
      return "sql";
    case "rs":
      return "rust";
    case "java":
      return "java";
    case "cpp":
    case "cc":
    case "cxx":
      return "cpp";
    case "c":
      return "c";
    case "rb":
      return "ruby";
    case "php":
      return "php";
    case "swift":
      return "swift";
    case "kt":
      return "kotlin";
    case "xml":
      return "xml";
    case "toml":
      return "ini";
    default:
      // Don't fall back to markdown — use plaintext so you don't get
      // false-positive markdown tokenisation on non-markdown files.
      return "plaintext";
  }
};

const LANGUAGES = [
  "markdown",
  "plaintext",
  "json",
  "javascript",
  "typescript",
  "python",
  "go",
  "yaml",
  "shell",
  "html",
  "css",
  "sql",
  "rust",
  "java",
  "cpp",
  "c",
  "ruby",
  "php",
  "swift",
  "kotlin",
];

export function PromptEditor() {
  const {
    editorContent,
    setEditorContent,
    selectedFile,
    isDirty,
    setIsDirty,
    themeMode,
    isDiffViewActive,
    diffOriginalContent,
    diffModifiedContent,
    diffFilename,
    diffType,
    diffCommitId,
    closeDiffView,
    resetSelectedFileChanges,
    editorSettings,
    user,
    detectedVariables,
  } = useAppStore();

  const [copied, setCopied] = useState(false);
  const editorRef = React.useRef<any>(null);
  const providersRef = React.useRef<any[]>([]);

  React.useEffect(() => {
    return () => {
      providersRef.current.forEach((p) => p.dispose());
    };
  }, []);

  const handleTriggerSuggestion = () => {
    if (editorRef.current) {
      editorRef.current.focus();
      editorRef.current.trigger("keyboard", "editor.action.inlineSuggest.trigger", {});
    }
  };

  const handleEditorBeforeMount = (monaco: Monaco) => {
    // ─── Dark Theme ───────────────────────────────────────────────────────────
    // Token names must match Monaco's TextMate-style scope identifiers.
    monaco.editor.defineTheme("prompthub-dark", {
      base: "vs-dark",
      inherit: true,
      rules: [
        // ── Comments ──────────────────────────────────────────────────────────
        { token: "comment", foreground: "6E7681", fontStyle: "italic" },
        { token: "comment.line", foreground: "6E7681", fontStyle: "italic" },
        { token: "comment.block", foreground: "6E7681", fontStyle: "italic" },

        // ── Keywords / Control flow ───────────────────────────────────────────
        { token: "keyword", foreground: "FF7B72" },
        { token: "keyword.control", foreground: "FF7B72" },
        { token: "keyword.operator", foreground: "FF7B72" },
        { token: "keyword.other", foreground: "FF7B72" },
        { token: "storage", foreground: "FF7B72" },
        { token: "storage.type", foreground: "FF7B72" },

        // ── Strings ───────────────────────────────────────────────────────────
        { token: "string", foreground: "A5D6FF" },
        { token: "string.quoted", foreground: "A5D6FF" },
        { token: "string.template", foreground: "A5D6FF" },
        { token: "string.regexp", foreground: "79C0FF" },

        // ── Numbers ───────────────────────────────────────────────────────────
        { token: "number", foreground: "79C0FF" },
        { token: "constant.numeric", foreground: "79C0FF" },

        // ── Constants / Literals ──────────────────────────────────────────────
        { token: "constant", foreground: "79C0FF" },
        { token: "constant.language", foreground: "79C0FF" },
        { token: "constant.character", foreground: "79C0FF" },

        // ── Types / Classes ───────────────────────────────────────────────────
        { token: "type", foreground: "FFA657" },
        { token: "type.identifier", foreground: "FFA657" },
        { token: "entity.name.type", foreground: "FFA657" },
        { token: "entity.name.class", foreground: "FFA657" },
        { token: "support.class", foreground: "FFA657" },

        // ── Functions ─────────────────────────────────────────────────────────
        { token: "entity.name.function", foreground: "D2A8FF" },
        { token: "support.function", foreground: "D2A8FF" },
        { token: "meta.function-call", foreground: "D2A8FF" },

        // ── Variables ─────────────────────────────────────────────────────────
        { token: "variable", foreground: "FFA657" },
        { token: "variable.name", foreground: "FFA657" },
        { token: "variable.other", foreground: "E6EDF3" },
        { token: "variable.parameter", foreground: "FFA657" },
        { token: "variable.language", foreground: "FF7B72" },

        // ── Tags (HTML/JSX/XML) ───────────────────────────────────────────────
        { token: "tag", foreground: "7EE787" },
        { token: "entity.name.tag", foreground: "7EE787" },
        { token: "meta.tag", foreground: "7EE787" },

        // ── Attributes ────────────────────────────────────────────────────────
        { token: "attribute.name", foreground: "79C0FF" },
        { token: "entity.other.attribute-name", foreground: "79C0FF" },
        { token: "attribute.value", foreground: "A5D6FF" },

        // ── Operators & Punctuation ───────────────────────────────────────────
        { token: "keyword.operator.assignment", foreground: "FF7B72" },
        { token: "keyword.operator.arithmetic", foreground: "FF7B72" },
        { token: "keyword.operator.logical", foreground: "FF7B72" },
        { token: "punctuation", foreground: "E6EDF3" },
        { token: "delimiter", foreground: "E6EDF3" },
        { token: "delimiter.bracket", foreground: "E6EDF3" },
        { token: "delimiter.parenthesis", foreground: "E6EDF3" },

        // ── Decorators / Annotations ──────────────────────────────────────────
        { token: "meta.decorator", foreground: "D2A8FF" },
        { token: "punctuation.decorator", foreground: "D2A8FF" },

        // ── JSON ──────────────────────────────────────────────────────────────
        { token: "string.key.json", foreground: "79C0FF" },
        { token: "string.value.json", foreground: "A5D6FF" },
        { token: "number.json", foreground: "7EE787" },
        { token: "keyword.json", foreground: "FF7B72" },

        // ── Markdown ──────────────────────────────────────────────────────────
        // Monaco exposes these scopes for the built-in markdown grammar:
        { token: "markup.heading", foreground: "79C0FF", fontStyle: "bold" },
        { token: "markup.bold", foreground: "E6EDF3", fontStyle: "bold" },
        { token: "markup.italic", foreground: "E6EDF3", fontStyle: "italic" },
        { token: "markup.underline.link", foreground: "A5D6FF", fontStyle: "underline" },
        { token: "markup.inline.raw", foreground: "FFA657" },
        { token: "markup.fenced_code.block", foreground: "8B949E" },
        { token: "meta.separator", foreground: "8B949E" },
        { token: "punctuation.definition.heading", foreground: "79C0FF" },
        { token: "punctuation.definition.list", foreground: "8B949E" },

        // ── CSS ───────────────────────────────────────────────────────────────
        { token: "entity.name.selector", foreground: "7EE787" },
        { token: "support.type.property-name", foreground: "79C0FF" },
        { token: "meta.property-value", foreground: "A5D6FF" },
      ],
      colors: {
        "editor.background": "#0A0A0A",
        "editor.foreground": "#FAFAFA",
        "editorLineNumber.foreground": "#8B949E",
        "editorLineNumber.activeForeground": "#FAFAFA",
        "editor.lineHighlightBackground": "#111111",
        "editor.lineHighlightBorder": "#00000000",
        "editorCursor.foreground": "#FAFAFA",
        "editor.selectionBackground": "#FFFFFF20",
        "editor.inactiveSelectionBackground": "#FFFFFF10",
        "scrollbarSlider.background": "#27272A80",
        "scrollbarSlider.hoverBackground": "#3F3F46A0",
        "scrollbarSlider.activeBackground": "#52525B",
        // Diff editor colours
        "diffEditor.insertedTextBackground": "#7EE78720",
        "diffEditor.removedTextBackground": "#FF7B7220",
        "diffEditor.insertedLineBackground": "#7EE78710",
        "diffEditor.removedLineBackground": "#FF7B7210",
      },
    });

    // ─── Light Theme ──────────────────────────────────────────────────────────
    monaco.editor.defineTheme("prompthub-light", {
      base: "vs",
      inherit: true,
      rules: [
        // ── Comments ──────────────────────────────────────────────────────────
        { token: "comment", foreground: "6E7781", fontStyle: "italic" },
        { token: "comment.line", foreground: "6E7781", fontStyle: "italic" },
        { token: "comment.block", foreground: "6E7781", fontStyle: "italic" },

        // ── Keywords ──────────────────────────────────────────────────────────
        { token: "keyword", foreground: "CF222E" },
        { token: "keyword.control", foreground: "CF222E" },
        { token: "keyword.operator", foreground: "CF222E" },
        { token: "storage", foreground: "CF222E" },
        { token: "storage.type", foreground: "005CC5" },

        // ── Strings ───────────────────────────────────────────────────────────
        { token: "string", foreground: "0A3069" },
        { token: "string.quoted", foreground: "0A3069" },
        { token: "string.template", foreground: "0A3069" },
        { token: "string.regexp", foreground: "0550AE" },

        // ── Numbers ───────────────────────────────────────────────────────────
        { token: "number", foreground: "0550AE" },
        { token: "constant.numeric", foreground: "0550AE" },

        // ── Constants ─────────────────────────────────────────────────────────
        { token: "constant", foreground: "005CC5" },
        { token: "constant.language", foreground: "005CC5" },

        // ── Types / Classes ───────────────────────────────────────────────────
        { token: "type", foreground: "953800" },
        { token: "type.identifier", foreground: "953800" },
        { token: "entity.name.type", foreground: "953800" },
        { token: "entity.name.class", foreground: "953800" },
        { token: "support.class", foreground: "953800" },

        // ── Functions ─────────────────────────────────────────────────────────
        { token: "entity.name.function", foreground: "8250DF" },
        { token: "support.function", foreground: "8250DF" },
        { token: "meta.function-call", foreground: "8250DF" },

        // ── Variables ─────────────────────────────────────────────────────────
        { token: "variable", foreground: "953800" },
        { token: "variable.name", foreground: "953800" },
        { token: "variable.other", foreground: "24292F" },
        { token: "variable.parameter", foreground: "953800" },
        { token: "variable.language", foreground: "CF222E" },

        // ── Tags ──────────────────────────────────────────────────────────────
        { token: "tag", foreground: "116329" },
        { token: "entity.name.tag", foreground: "116329" },

        // ── Attributes ────────────────────────────────────────────────────────
        { token: "attribute.name", foreground: "0550AE" },
        { token: "entity.other.attribute-name", foreground: "0550AE" },
        { token: "attribute.value", foreground: "0A3069" },

        // ── Operators & Punctuation ───────────────────────────────────────────
        { token: "keyword.operator", foreground: "CF222E" },
        { token: "punctuation", foreground: "24292F" },
        { token: "delimiter", foreground: "24292F" },

        // ── JSON ──────────────────────────────────────────────────────────────
        { token: "string.key.json", foreground: "0550AE" },
        { token: "string.value.json", foreground: "0A3069" },
        { token: "number.json", foreground: "116329" },
        { token: "keyword.json", foreground: "CF222E" },

        // ── Markdown ──────────────────────────────────────────────────────────
        { token: "markup.heading", foreground: "0550AE", fontStyle: "bold" },
        { token: "markup.bold", foreground: "24292F", fontStyle: "bold" },
        { token: "markup.italic", foreground: "24292F", fontStyle: "italic" },
        { token: "markup.underline.link", foreground: "0A3069", fontStyle: "underline" },
        { token: "markup.inline.raw", foreground: "953800" },
        { token: "markup.fenced_code.block", foreground: "6E7781" },
        { token: "punctuation.definition.heading", foreground: "0550AE" },
        { token: "punctuation.definition.list", foreground: "6E7781" },

        // ── CSS ───────────────────────────────────────────────────────────────
        { token: "entity.name.selector", foreground: "116329" },
        { token: "support.type.property-name", foreground: "0550AE" },
        { token: "meta.property-value", foreground: "0A3069" },

        // ── Decorators ────────────────────────────────────────────────────────
        { token: "meta.decorator", foreground: "8250DF" },
        { token: "punctuation.decorator", foreground: "8250DF" },
      ],
      colors: {
        "editor.background": "#FCFCFC",
        "editor.foreground": "#121212",
        "editorLineNumber.foreground": "#57606A",
        "editorLineNumber.activeForeground": "#121212",
        "editor.lineHighlightBackground": "#F6F6F6",
        "editor.lineHighlightBorder": "#00000000",
        "editorCursor.foreground": "#121212",
        "editor.selectionBackground": "#00000015",
        "editor.inactiveSelectionBackground": "#00000008",
        "scrollbarSlider.background": "#E2E2E280",
        "scrollbarSlider.hoverBackground": "#D5D5D5A0",
        "scrollbarSlider.activeBackground": "#CCCCCC",
        // Diff editor colours
        "diffEditor.insertedTextBackground": "#11692720",
        "diffEditor.removedTextBackground": "#CF222E20",
        "diffEditor.insertedLineBackground": "#11692710",
        "diffEditor.removedLineBackground": "#CF222E10",
      },
    });
  };

  const handleEditorDidMount = (
    editor: Parameters<import("@monaco-editor/react").OnMount>[0],
    monaco: Monaco
  ) => {
    editorRef.current = editor;

    editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyS, () => {
      setIsDirty(false);
    });

    // Ctrl/Cmd + J to trigger inline suggestions
    editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyJ, () => {
      editor.trigger("keyboard", "editor.action.inlineSuggest.trigger", {});
    });

    // Clean up existing providers if any, and register for all supported languages
    providersRef.current.forEach((p) => p.dispose());
    providersRef.current = [];

    LANGUAGES.forEach((lang) => {
      try {
        const provider = monaco.languages.registerInlineCompletionsProvider(lang, {
          provideInlineCompletions: async (model: any, position: any, context: any, token: any) => {
            // Only suggest when explicitly triggered (e.g. click suggestion button or Ctrl/Cmd + J)
            if (context && context.triggerKind === 1) {
              return;
            }

            const value = model.getValue();
            const offset = model.getOffsetAt(position);
            // Get prefix (approx. last 500 characters, which is about 100 tokens)
            const prefix = value.substring(Math.max(0, offset - 500), offset);
            if (!prefix.trim()) return;

            try {
              const res = await fetch("/api/ai/suggest", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ prefix }),
              });
              if (!res.ok) return;
              if (token && token.isCancellationRequested) return;

              const data = await res.json();
              if (token && token.isCancellationRequested) return;

              if (data.suggestion) {
                return {
                  items: [
                    {
                      insertText: data.suggestion,
                      range: new monaco.Range(
                        position.lineNumber,
                        position.column,
                        position.lineNumber,
                        position.column
                      ),
                    },
                  ],
                };
              }
            } catch (err) {
              console.error(`Failed to fetch suggestion for language ${lang}:`, err);
            }
          },
          freeInlineCompletions: () => { },
        });
        providersRef.current.push(provider);

        // Register variables autocomplete provider triggered by typing '{'
        const completionProvider = monaco.languages.registerCompletionItemProvider(lang, {
          triggerCharacters: ["{"],
          provideCompletionItems: (model: any, position: any) => {
            const lineText = model.getLineContent(position.lineNumber);
            const textBeforeCursor = lineText.substring(0, position.column - 1);
            const lastOpenBrace = textBeforeCursor.lastIndexOf("{");
            const lastCloseBrace = textBeforeCursor.lastIndexOf("}");
            const hasUnclosedBrace = lastOpenBrace !== -1 && lastOpenBrace > lastCloseBrace;

            const defaultVars = ["company_name", "product_name", "customer_name", "language", "tone"];
            const uniqueVars = Array.from(new Set([...detectedVariables, ...defaultVars]));

            const suggestions = uniqueVars.map((v) => {
              const startColumn = hasUnclosedBrace ? lastOpenBrace + 2 : position.column;
              const endColumn = position.column;
              const insertText = hasUnclosedBrace ? `${v}}` : `{${v}}`;

              return {
                label: v,
                kind: monaco.languages.CompletionItemKind.Variable,
                detail: "Prompt variable template",
                insertText: insertText,
                range: new monaco.Range(
                  position.lineNumber,
                  startColumn,
                  position.lineNumber,
                  endColumn
                ),
              };
            });

            return { suggestions };
          },
        });
        providersRef.current.push(completionProvider);
      } catch (err) {
        console.error(`Error registering completion providers for language ${lang}:`, err);
      }
    });
  };

  const handleCopy = () => {
    navigator.clipboard?.writeText(editorContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const file = selectedFile;
  const filename = isDiffViewActive
    ? diffFilename
    : file?.name || "code-review.md";
  const language = getLanguageFromFilename(filename);

  if (isDiffViewActive) {
    return (
      <div className="h-full flex flex-col bg-bg-primary">
        {/* Diff Toolbar Banner */}
        <div className="h-10 border-b border-border flex items-center justify-between px-3 bg-bg-secondary/75 backdrop-blur-sm flex-shrink-0 select-none">
          <div className="flex items-center gap-2.5">
            <div className="h-5 w-5 rounded bg-bg-elevated border border-border flex items-center justify-center text-text-secondary">
              <ArrowRightLeft size={11} />
            </div>
            <span
              className="text-[13px] font-semibold text-text-primary"
              style={{ letterSpacing: "-0.01em" }}
            >
              Comparing {filename}
            </span>
            {diffType === "workspace" ? (
              <span className="text-[9.5px] px-2 py-0.5 font-bold uppercase tracking-wider text-amber-500 bg-amber-950/45 border border-amber-800/40 rounded-full">
                Unsaved Changes
              </span>
            ) : (
              <span className="text-[9.5px] px-2 py-0.5 font-bold uppercase tracking-wider text-text-secondary bg-bg-elevated border border-border rounded-full font-mono">
                Commit: {diffCommitId}
              </span>
            )}
          </div>

          <button
            onClick={closeDiffView}
            className="h-7 px-2.5 rounded-md text-[11px] font-medium text-text-secondary hover:text-text-primary bg-bg-elevated hover:bg-bg-hover border border-border hover:border-border-strong flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <X size={11} />
            Exit Diff View
          </button>
        </div>

        {/* Diff Editor Area */}
        <div className="flex-1 relative overflow-hidden bg-bg-primary">
          <DiffEditor
            height="100%"
            language={language}
            theme={themeMode === "dark" ? "prompthub-dark" : "prompthub-light"}
            beforeMount={handleEditorBeforeMount}
            original={diffOriginalContent}
            modified={diffModifiedContent}
            loading={
              <div className="h-full w-full flex items-center justify-center text-text-muted font-mono text-[12px] bg-bg-primary">
                Loading diff view...
              </div>
            }
            options={{
              renderSideBySide: true,
              readOnly: true,
              originalEditable: false,
              minimap: { enabled: editorSettings.minimap },
              fontSize: editorSettings.fontSize,
              lineHeight: 21,
              fontFamily: "var(--font-mono)",
              wordWrap: editorSettings.wordWrap,
              scrollbar: {
                vertical: "auto",
                horizontal: "auto",
                verticalScrollbarSize: 6,
                horizontalScrollbarSize: 6,
              },
              lineNumbersMinChars: 3,
              glyphMargin: false,
              folding: true,
              lineDecorationsWidth: 10,
              hideCursorInOverviewRuler: true,
              overviewRulerBorder: false,
              overviewRulerLanes: 0,
              renderLineHighlight: "all",
              domReadOnly: true,
              automaticLayout: true,
              padding: { top: 16, bottom: 16 },
            }}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col bg-bg-primary">
      {/* Editor toolbar */}
      <div className="h-10 border-b border-border flex items-center justify-between px-3 flex-shrink-0">
        <div className="flex items-center gap-2">
          <span
            className="text-[13px] font-medium text-text-primary"
            style={{ letterSpacing: "-0.01em" }}
          >
            {filename}
          </span>
          {file?.status ? (
            <StatusPill status={isDirty ? "modified" : file.status} />
          ) : (
            <StatusPill status={isDirty ? "modified" : "synced"} />
          )}
        </div>

        <div className="flex items-center gap-3">
          {/* Last modified info */}
          <div className="flex items-center gap-1.5 text-[11px] text-text-muted">
            <Clock size={11} />
            <span>{file?.lastModified ? timeAgo(file.lastModified) : "2h ago"}</span>
            <span className="text-border-strong">·</span>
            <User size={11} />
            <span>{user?.name || user?.login || "Author"}</span>
          </div>

          <div className="h-4 w-px bg-border" />

          <div className="flex items-center gap-0.5">
            <Tooltip content="AI Suggestions (⌘J)">
              <button
                onClick={handleTriggerSuggestion}
                className="h-6 w-6 flex items-center justify-center rounded-sm text-text-muted hover:text-text-primary hover:bg-bg-hover transition-colors"
              >
                <Wand2 size={13} />
              </button>
            </Tooltip>
            <Tooltip content="Copy content">
              <button
                onClick={handleCopy}
                className="h-6 w-6 flex items-center justify-center rounded-sm text-text-muted hover:text-text-primary hover:bg-bg-hover transition-colors"
              >
                {copied ? (
                  <Check size={13} className="text-emerald-500" />
                ) : (
                  <Copy size={13} />
                )}
              </button>
            </Tooltip>
            <Tooltip content="Reset changes">
              <button
                onClick={resetSelectedFileChanges}
                className="h-6 w-6 flex items-center justify-center rounded-sm text-text-muted hover:text-text-primary hover:bg-bg-hover transition-colors"
              >
                <RotateCcw size={13} />
              </button>
            </Tooltip>
          </div>
        </div>
      </div>

      {/* Editor area */}
      <div className="flex-1 relative overflow-hidden bg-bg-primary">
        <Editor
          height="100%"
          language={language}
          theme={themeMode === "dark" ? "prompthub-dark" : "prompthub-light"}
          value={editorContent}
          onChange={(val) => {
            setEditorContent(val || "");
            setIsDirty(true);
          }}
          beforeMount={handleEditorBeforeMount}
          onMount={handleEditorDidMount}
          loading={
            <div className="h-full w-full flex items-center justify-center text-text-muted font-mono text-[12px] bg-bg-primary">
              Loading editor...
            </div>
          }
          options={{
            minimap: { enabled: editorSettings.minimap },
            fontSize: editorSettings.fontSize,
            lineHeight: 21,
            fontFamily: "var(--font-mono)",
            wordWrap: editorSettings.wordWrap,
            scrollbar: {
              vertical: "auto",
              horizontal: "auto",
              verticalScrollbarSize: 6,
              horizontalScrollbarSize: 6,
            },
            lineNumbersMinChars: 3,
            glyphMargin: false,
            folding: true,
            lineDecorationsWidth: 10,
            hideCursorInOverviewRuler: true,
            overviewRulerBorder: false,
            overviewRulerLanes: 0,
            renderLineHighlight: "all",
            domReadOnly: false,
            readOnly: false,
            automaticLayout: true,
            padding: { top: 16, bottom: 16 },
          }}
        />
      </div>
    </div>
  );
}