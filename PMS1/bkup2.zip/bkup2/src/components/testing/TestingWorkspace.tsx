"use client";

import React, { useState } from "react";
import { useAppStore } from "@/store";
import { cn, findFileById } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import {
  Play,
  Columns2,
  LayoutGrid,
  ThumbsUp,
  ThumbsDown,
  Copy,
  Zap,
  Check,
  ChevronDown,
  RefreshCw,
} from "lucide-react";
import { Tooltip } from "@/components/ui/Tooltip";
import { TestRun, FileNode } from "@/types";

function ModelSelector() {
  const { models, toggleModel } = useAppStore();

  return (
    <div className="space-y-1.5">
      <label className="text-[10px] text-text-muted uppercase tracking-widest font-medium">
        Models
      </label>
      <div className="space-y-1">
        {models.map((model) => (
          <button
            key={model.id}
            onClick={() => toggleModel(model.id)}
            className={cn(
              "w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-[12px] transition-all duration-150 cursor-pointer relative overflow-hidden",
              "border",
              model.selected
                ? "bg-gradient-to-r from-indigo-500/5 to-transparent border-indigo-500/35 text-text-primary shadow-subtle shadow-indigo-500/2"
                : "bg-transparent border-border text-text-tertiary hover:border-border-strong hover:text-text-secondary"
            )}
          >
            <span className="text-[14px] leading-none text-text-secondary group-hover:text-text-primary">{model.icon}</span>
            <div className="flex-1 text-left">
              <div className="font-semibold text-[12px] tracking-tight">{model.name}</div>
              <div className="text-[9.5px] text-text-muted">{model.provider}</div>
            </div>
            {model.selected && (
              <motion.span
                layoutId={`active-model-indicator-${model.id}`}
                className="w-1.5 h-1.5 rounded-full bg-indigo-500 shadow-[0_0_8px_rgba(99,102,241,0.8)]"
              />
            )}
          </button>
        ))}
      </div>
    </div>
  );
}
function ResultCard({ run, index }: { run: TestRun; index: number }) {
  const { setTestRunRating } = useAppStore();
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard?.writeText(run.response);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const isFast = run.latency < 2000;

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.08, duration: 0.35, ease: "easeOut" }}
      className="flex flex-col bg-bg-secondary border border-border hover:border-border-strong rounded-xl overflow-hidden shadow-lg transition-all duration-200"
    >
      {/* Redesigned Card Header with Stats Dashboard */}
      <div className="p-4 border-b border-border bg-bg-primary/60 flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="h-6 w-6 rounded-md bg-white/[0.04] border border-border flex items-center justify-center text-[12px] font-bold text-text-primary">
              {run.model === "Claude 4 Sonnet" ? "✦" : "◈"}
            </span>
            <div className="flex flex-col">
              <span className="text-[13px] font-semibold text-text-primary">
                {run.model}
              </span>
              <span className="text-[10px] text-text-muted">
                {run.prompt}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className={cn(
              "px-2 py-0.5 rounded-full text-[9px] font-medium tracking-wider uppercase",
              isFast
                ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"
                : "bg-amber-500/10 text-amber-400 border border-amber-500/20"
            )}>
              {isFast ? "Fast" : "Normal"}
            </span>
          </div>
        </div>

        {/* Dynamic Metrics Row */}
        <div className="flex flex-col gap-2 bg-bg-elevated/45 border border-border/60 rounded-lg p-2.5">
          <div className="grid grid-cols-4 gap-1 text-center divide-x divide-border/60">
            <div>
              <div className="text-[8.5px] text-text-muted uppercase font-bold tracking-wide">Latency</div>
              <div className="text-[11px] font-mono text-text-secondary font-semibold mt-0.5">
                {(run.latency / 1000).toFixed(2)}s
              </div>
            </div>
            <div>
              <div className="text-[8.5px] text-text-muted uppercase font-bold tracking-wide">Output</div>
              <div className="text-[11px] font-mono text-text-secondary font-semibold mt-0.5">
                {run.tokens.output} t
              </div>
            </div>
            <div>
              <div className="text-[8.5px] text-text-muted uppercase font-bold tracking-wide">Input</div>
              <div className="text-[11px] font-mono text-text-secondary font-semibold mt-0.5">
                {run.tokens.input} t
              </div>
            </div>
            <div>
              <div className="text-[8.5px] text-text-muted uppercase font-bold tracking-wide">Est. Cost</div>
              <div className="text-[11px] font-mono text-emerald-400 font-bold mt-0.5">
                ${((run.tokens.input * 0.003 / 1000) + (run.tokens.output * 0.015 / 1000)).toFixed(5)}
              </div>
            </div>
          </div>

          {/* Latency Visual Bar */}
          <div className="h-1 w-full bg-border rounded-full overflow-hidden mt-1 relative">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${Math.min(100, (run.latency / 2500) * 100)}%` }}
              transition={{ duration: 0.5, ease: "easeOut" }}
              className={cn(
                "h-full rounded-full",
                run.latency < 1200
                  ? "bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]"
                  : run.latency < 2000
                    ? "bg-indigo-500 shadow-[0_0_8px_rgba(99,102,241,0.5)]"
                    : "bg-amber-500 shadow-[0_0_8px_rgba(245,158,11,0.5)]"
              )}
            />
          </div>
        </div>
      </div>

      {/* Response Display */}
      <div className="flex-1 p-4 overflow-y-auto max-h-[350px] min-h-[180px] bg-bg-secondary/20">
        <div className="markdown-preview text-[12.5px] leading-relaxed select-text">
          <ReactMarkdown remarkPlugins={[remarkGfm]}>{run.response}</ReactMarkdown>
        </div>
      </div>

      {/* Redesigned Card Footer with Action Tools */}
      <div className="px-4 py-3 border-t border-border bg-bg-primary/30 flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          <Tooltip content="Helpful">
            <button
              onClick={() => setTestRunRating(run.id, "up")}
              className={cn(
                "h-7 w-7 flex items-center justify-center rounded-lg transition-all active:scale-95 cursor-pointer",
                run.rating === "up"
                  ? "text-emerald-400 bg-emerald-500/10 border border-emerald-500/20"
                  : "text-text-muted hover:text-text-primary hover:bg-bg-hover border border-transparent"
              )}
            >
              <ThumbsUp size={13} />
            </button>
          </Tooltip>
          <Tooltip content="Not Helpful">
            <button
              onClick={() => setTestRunRating(run.id, "down")}
              className={cn(
                "h-7 w-7 flex items-center justify-center rounded-lg transition-all active:scale-95 cursor-pointer",
                run.rating === "down"
                  ? "text-red-400 bg-red-500/10 border border-red-500/20"
                  : "text-text-muted hover:text-text-primary hover:bg-bg-hover border border-transparent"
              )}
            >
              <ThumbsDown size={13} />
            </button>
          </Tooltip>
        </div>

        <button
          onClick={handleCopy}
          className="flex items-center gap-1.5 text-[11px] font-medium text-text-secondary hover:text-text-primary px-3 py-1 rounded-lg bg-bg-elevated border border-border hover:border-border-strong transition-all active:scale-98 cursor-pointer"
        >
          {copied ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
          <span>{copied ? "Copied" : "Copy Output"}</span>
        </button>
      </div>
    </motion.div>
  );
}

function generateSimulatedResponse(
  modelName: string,
  promptName: string,
  promptContent: string,
  vars: Record<string, string>
): string {
  let processedPrompt = promptContent;
  Object.entries(vars).forEach(([key, val]) => {
    processedPrompt = processedPrompt.replaceAll(`{${key}}`, val || `[${key}]`);
  });

  const lowerContent = promptContent.toLowerCase();

  if (lowerContent.includes("code review") || promptName.toLowerCase().includes("code-review")) {
    const lang = vars.language || "TypeScript";
    return `## Code Review (Simulated via ${modelName})

I have analyzed the provided code written in **${lang}** (Target focus: *${vars.review_focus || "General"}*).

### 🔍 Key Findings

1. **🚨 Security Concerns**
   - Direct user input values should always be parameterized or sanitized before use.
   - Limit file access rights if executing shell commands.

2. **⚡ Performance & Refactoring**
   - Ensure loops do not have nested network triggers.
   - Utilize standard async libraries to await promises concurrently when possible.

3. **📝 Style Guidelines**
   - The overall variable structure is readable, clean, and well-designed.
   - Consider writing comments to explain non-obvious configurations.

**Benchmarked Score: 9/10**`;
  }

  if (lowerContent.includes("customer support") || promptName.toLowerCase().includes("customer-support")) {
    const tone = vars.tone || "helpful";
    const company = vars.company_name || "PromptHub";
    return `## Customer Support Response (Simulated via ${modelName})

*Configuration Profile: Tone [${tone}] | Company [${company}]*

"Hello ${vars.customer_name || "Valued Customer"},

Thank you for contacting ${company} support. We appreciate you letting us know about this issue with your ${vars.product_name || "account"}.

Here are the steps to resolve this:
1. Log into your dashboard.
2. Navigate to Account settings and verify your tier (${vars.account_tier || "Standard"}).
3. Refresh the cache and try again.

If the problem persists, please reply with your screenshot so we can escalate this to tier-2 engineers."`;
  }

  return `## Simulated Response from ${modelName}

### Substituted Prompt Template:
\`\`\`markdown
${processedPrompt.substring(0, 300)}${processedPrompt.length > 300 ? "..." : ""}
\`\`\`

### Ingested Variables:
${Object.entries(vars).length > 0
      ? Object.entries(vars).map(([k, v]) => `- **${k}**: "${v || "(empty)"}"`).join("\n")
      : "*(No variables detected)*"}

This is a simulated prompt execution in the **Testing Arena**. Latency benchmarking and token usage statistics are populated below for your evaluation.`;
}

export function TestingWorkspace() {
  const {
    testRuns,
    models,
    isRunningTest,
    setIsRunningTest,
    detectedVariables,
    variables,
    setVariable,
    editorContent,
    selectedFile,
    fileTree,
    setSelectedFile,
    addTestRun,
    clearTestRuns,
  } = useAppStore();

  const [layout, setLayout] = useState<"grid" | "columns">("columns");
  const [attachedFiles, setAttachedFiles] = useState<{ id: string; name: string; size: string; type: string }[]>([]);
  const selectedModels = models.filter((m) => m.selected);

  const handleRunTest = () => {
    if (!selectedFile) {
      alert("Please select a prompt template first!");
      return;
    }
    clearTestRuns();
    setIsRunningTest(true);

    setTimeout(() => {
      selectedModels.forEach((model) => {
        const simulatedResponse = generateSimulatedResponse(
          model.name,
          selectedFile.name,
          editorContent,
          variables
        );

        const newRun = {
          id: Math.random().toString(36).substring(7),
          model: model.name,
          prompt: selectedFile.name,
          variables: { ...variables },
          response: simulatedResponse,
          tokens: {
            input: Math.floor(Math.random() * 200) + 150,
            output: Math.floor(Math.random() * 400) + 200,
          },
          latency: Math.floor(Math.random() * 1500) + 800,
          timestamp: new Date(),
        };

        addTestRun(newRun);
      });
      setIsRunningTest(false);
    }, 1200);
  };

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + " " + sizes[i];
  };

  const handleFileAttach = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return;
    const newFiles = Array.from(e.target.files).map((file) => ({
      id: Math.random().toString(36).substring(7),
      name: file.name,
      size: formatBytes(file.size),
      type: file.type || (file.name.endsWith(".pdf") ? "application/pdf" : "text/plain"),
    }));
    setAttachedFiles((prev) => [...prev, ...newFiles]);
  };

  const removeFile = (id: string) => {
    setAttachedFiles((prev) => prev.filter((file) => file.id !== id));
  };

  return (
    <div className="h-full flex bg-bg-primary overflow-hidden">
      {/* Overhauled Left Config Sidebar */}
      <div className="w-[300px] border-r border-border flex flex-col flex-shrink-0 bg-bg-secondary/20 overflow-y-auto">
        <div className="p-4 border-b border-border bg-bg-primary/40">
          <h2 className="text-[14px] font-bold text-text-primary tracking-tight">
            Test Arena Configuration
          </h2>
          <p className="text-[11px] text-text-muted mt-0.5 leading-relaxed">
            Attach context resources and select LLMs to benchmark responses.
          </p>
        </div>

        <div className="flex-1 p-4 space-y-5 overflow-y-auto">
          {/* Active Prompt Select Dropdown */}
          <div className="space-y-2">
            <label className="text-[10px] text-text-muted uppercase tracking-widest font-semibold block">
              Active Prompt Template
            </label>
            <div className="relative">
              <select
                value={selectedFile?.id || ""}
                onChange={(e) => {
                  const targetId = e.target.value;
                  const file = findFileById(fileTree, targetId);
                  if (file) setSelectedFile(file);
                }}
                className="w-full h-9 pl-3 pr-8 rounded-lg bg-bg-elevated border border-border text-[12.5px] text-text-primary focus:border-border-focus focus:outline-none transition-colors cursor-pointer appearance-none shadow-sm font-medium"
              >
                {(() => {
                  const collectFiles = (nodes: FileNode[]): FileNode[] => {
                    let files: FileNode[] = [];
                    for (const node of nodes) {
                      if (node.type === "file") {
                        const name = node.name.toLowerCase();
                        if (
                          name.endsWith(".md") ||
                          name.endsWith(".txt") ||
                          name.endsWith(".yml") ||
                          name.endsWith(".yaml")
                        ) {
                          files.push(node);
                        }
                      }
                      if (node.children) files = [...files, ...collectFiles(node.children)];
                    }
                    return files;
                  };
                  return collectFiles(fileTree).map((file) => (
                    <option key={file.id} value={file.id} className="bg-bg-elevated text-text-primary">
                      {file.name}
                    </option>
                  ));
                })()}
              </select>
              <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-text-muted">
                <ChevronDown size={14} />
              </div>
            </div>
          </div>

          {/* Prompt Variables Editing Panel */}
          {detectedVariables.length > 0 && (
            <div className="space-y-2">
              <label className="text-[10px] text-text-muted uppercase tracking-widest font-semibold block">
                Prompt Variables
              </label>
              <div className="space-y-3 bg-bg-elevated/20 border border-border/60 rounded-lg p-3">
                {detectedVariables.map((variable) => (
                  <div key={variable} className="space-y-1">
                    <label className="text-[11px] text-text-secondary font-mono flex items-center gap-0.5 select-none">
                      <span className="text-text-muted font-sans font-medium">{"{"}</span>
                      <span>{variable}</span>
                      <span className="text-text-muted font-sans font-medium">{"}"}</span>
                    </label>
                    <input
                      type="text"
                      value={variables[variable] || ""}
                      onChange={(e) => setVariable(variable, e.target.value)}
                      placeholder={`Enter value for ${variable}`}
                      className="w-full h-8 px-2.5 rounded-md bg-bg-elevated border border-border text-[12px] text-text-primary placeholder:text-text-muted/50 focus:border-border-focus focus:outline-none transition-colors"
                    />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Overhauled Context Files attachment section */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-[10px] text-text-muted uppercase tracking-widest font-semibold">
                Context & Reference Files
              </label>
              <span className="text-[9px] text-text-muted font-mono font-semibold bg-bg-elevated px-1.5 py-0.5 rounded border border-border">
                {attachedFiles.length} files
              </span>
            </div>

            <div className="space-y-2.5">
              <label className="border border-dashed border-border hover:border-border-strong rounded-lg p-2.5 flex items-center justify-center gap-2 cursor-pointer bg-bg-elevated/10 hover:bg-bg-elevated/20 transition-all duration-150">
                <input
                  type="file"
                  multiple
                  accept=".pdf,.txt,.md,.json,.yaml,.yml,.js,.ts,.tsx,.py"
                  className="hidden"
                  onChange={handleFileAttach}
                />
                <span className="text-[14px] text-text-muted">📎</span>
                <span className="text-[11.5px] font-medium text-text-secondary">Attach reference files</span>
              </label>

              {attachedFiles.length > 0 && (
                <div className="space-y-1.5 max-h-[160px] overflow-y-auto pr-1">
                  <AnimatePresence>
                    {attachedFiles.map((f) => (
                      <motion.div
                        key={f.id}
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.95 }}
                        className="flex items-center justify-between p-2 bg-bg-elevated/30 border border-border hover:border-border-strong rounded-lg group transition-colors"
                      >
                        <div className="flex items-center gap-2 min-w-0">
                          <span className="text-[14px] flex-shrink-0">
                            {f.type.includes("pdf") ? "📄" : "📝"}
                          </span>
                          <div className="flex flex-col min-w-0">
                            <span className="text-[11.5px] text-text-primary font-semibold truncate leading-tight">
                              {f.name}
                            </span>
                            <span className="text-[9px] text-text-muted font-mono leading-none">
                              {f.size}
                            </span>
                          </div>
                        </div>
                        <button
                          onClick={() => removeFile(f.id)}
                          className="h-5 w-5 rounded-md flex items-center justify-center text-text-muted hover:text-text-primary hover:bg-bg-hover transition-colors cursor-pointer"
                        >
                          ✕
                        </button>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>
              )}
            </div>
          </div>

          {/* Overhauled Model Selector */}
          <div className="pt-2">
            <ModelSelector />
          </div>
        </div>

        {/* Primary Run Test Action */}
        <div className="p-4 border-t border-border bg-bg-primary/40">
          <button
            onClick={handleRunTest}
            disabled={isRunningTest || selectedModels.length === 0}
            className={cn(
              "w-full h-10 rounded-lg text-[13px] font-bold transition-all duration-200 cursor-pointer shadow-md",
              "flex items-center justify-center gap-2",
              isRunningTest
                ? "bg-zinc-800 text-text-muted cursor-wait"
                : selectedModels.length === 0
                  ? "bg-bg-elevated text-text-muted border border-border cursor-not-allowed"
                  : "bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white active:scale-[0.98] shadow-lg shadow-indigo-600/15"
            )}
          >
            {isRunningTest ? (
              <>
                <RefreshCw size={14} className="animate-spin" />
                <span>Generating Outputs...</span>
              </>
            ) : (
              <>
                <Play size={14} fill="white" className="text-white" />
                <span>Execute Arena Test</span>
                {selectedModels.length > 0 && (
                  <span className="text-[9.5px] font-bold bg-white/15 text-white rounded-full px-2 py-0.5 border border-white/10">
                    {selectedModels.length} LLM{selectedModels.length !== 1 ? "s" : ""}
                  </span>
                )}
              </>
            )}
          </button>
          <p className="text-[10px] text-text-muted text-center mt-2 font-mono">
            Ctrl + Enter to dispatch test
          </p>
        </div>
      </div>

      {/* Redesigned main results panel area */}
      <div className="flex-1 flex flex-col overflow-hidden bg-bg-primary/20">
        <div className="h-12 border-b border-border flex items-center justify-between px-4 bg-bg-primary/40 flex-shrink-0">
          <div className="flex items-center gap-2">
            <span className="text-[13px] font-bold text-text-primary tracking-tight">
              Test Output Comparisons
            </span>
            {testRuns.length > 0 && (
              <span className="text-[10px] font-bold text-text-secondary bg-bg-elevated px-2 py-0.5 rounded-full border border-border">
                {testRuns.length} runs
              </span>
            )}
          </div>

          <div className="flex items-center bg-bg-elevated rounded-lg border border-border p-0.5">
            <button
              onClick={() => setLayout("columns")}
              className={cn(
                "h-7 w-7 flex items-center justify-center rounded-md transition-colors cursor-pointer",
                layout === "columns"
                  ? "text-text-primary bg-bg-hover border border-border/40 shadow-sm"
                  : "text-text-muted hover:text-text-primary"
              )}
            >
              <Columns2 size={14} />
            </button>
            <button
              onClick={() => setLayout("grid")}
              className={cn(
                "h-7 w-7 flex items-center justify-center rounded-md transition-colors cursor-pointer",
                layout === "grid"
                  ? "text-text-primary bg-bg-hover border border-border/40 shadow-sm"
                  : "text-text-muted hover:text-text-primary"
              )}
            >
              <LayoutGrid size={14} />
            </button>
          </div>
        </div>

        {/* Dynamic results scroll viewport */}
        <div className="flex-1 p-6 overflow-y-auto">
          {testRuns.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center">
              <div className="w-14 h-14 rounded-2xl bg-bg-elevated border border-border flex items-center justify-center mb-4 shadow-md">
                <Zap size={24} className="text-text-muted" />
              </div>
              <h3 className="text-[14px] font-semibold text-text-primary mb-1">
                No benchmarking outputs
              </h3>
              <p className="text-[12px] text-text-muted max-w-[260px] leading-relaxed">
                Configure your context assets, pick targets in LLM config, and run a test simulation.
              </p>
            </div>
          ) : (
            <div
              className={cn(
                "gap-4",
                layout === "columns"
                  ? "flex flex-row overflow-x-auto h-full items-start"
                  : "grid grid-cols-1 md:grid-cols-2"
              )}
            >
              {testRuns.map((run, i) => (
                <div key={run.id} className={layout === "columns" ? "flex-1 min-w-[320px] max-w-[450px]" : ""}>
                  <ResultCard run={run} index={i} />
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
