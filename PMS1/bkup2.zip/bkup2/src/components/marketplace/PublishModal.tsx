"use client";

import React, { useState } from "react";
import { useAppStore } from "@/store";
import { X, Send, AlertTriangle } from "lucide-react";
import { mockCategories } from "@/data/marketplaceMock";
import { MarketplaceItemType } from "@/types/marketplace";

interface PublishModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function PublishModal({ isOpen, onClose }: PublishModalProps) {
  const { publishMarketplaceItem, user } = useAppStore();

  const [name, setName] = useState("");
  const [type, setType] = useState<MarketplaceItemType>("skill");
  const [publisher, setPublisher] = useState(user?.login || "anonymous");
  const [category, setCategory] = useState("development");
  const [shortDesc, setShortDesc] = useState("");
  const [longDesc, setLongDesc] = useState("");
  const [highlight, setHighlight] = useState("");
  const [whenToUseStr, setWhenToUseStr] = useState("");
  const [filename, setFilename] = useState("");
  const [content, setContent] = useState("");

  const [error, setError] = useState("");

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!name.trim()) return setError("Item name is required.");
    if (!shortDesc.trim()) return setError("Short description is required.");
    if (!longDesc.trim()) return setError("Detailed description is required.");
    if (!filename.trim()) return setError("File name is required (e.g. skill.md).");
    if (!content.trim()) return setError("Content is required.");

    const whenToUse = whenToUseStr
      .split("\n")
      .map((line) => line.trim())
      .filter((line) => line.length > 0);

    publishMarketplaceItem({
      name: name.trim().toLowerCase().replace(/\s+/g, "-"),
      type,
      publisher: publisher.trim() || "anonymous",
      isOfficial: false,
      category,
      shortDescription: shortDesc.trim(),
      longDescription: longDesc.trim(),
      whatItDoes: longDesc.trim(),
      whatItDoesHighlight: highlight.trim() || undefined,
      whenToUse: whenToUse.length > 0 ? whenToUse : ["General purpose implementation"],
      content: content,
      contentFilename: filename.trim().replace(/\s+/g, "_"),
    });

    onClose();
  };

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 animate-fade-in"
        onClick={onClose}
      />

      {/* Modal Container */}
      <div className="fixed top-[10%] left-1/2 -translate-x-1/2 w-[600px] bg-bg-secondary border border-border rounded-xl shadow-elevated z-50 overflow-hidden animate-scale-in">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-border">
          <div>
            <h3 className="text-[14px] font-bold text-text-primary">Contribute to Marketplace</h3>
            <p className="text-[11px] text-text-muted">Publish your Prompt, Skill, Agent or Instructions</p>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-sm text-text-muted hover:text-text-primary hover:bg-bg-hover transition-colors"
          >
            <X size={15} />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-5 overflow-y-auto max-h-[70vh] space-y-4">
          {error && (
            <div className="p-3 bg-red-950/40 border border-red-900/40 rounded-lg flex items-start gap-2 text-red-400 text-[11.5px]">
              <AlertTriangle size={14} className="mt-0.5 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="grid grid-cols-2 gap-4">
            {/* Name */}
            <div className="space-y-1">
              <label className="text-[11px] font-semibold text-text-secondary uppercase tracking-wider">Item Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. agents-sdk"
                className="w-full h-8 px-3 rounded bg-bg-elevated border border-border text-[12px] text-text-primary placeholder:text-text-muted focus:outline-none focus:border-border-focus transition-colors"
              />
            </div>

            {/* Type */}
            <div className="space-y-1">
              <label className="text-[11px] font-semibold text-text-secondary uppercase tracking-wider">Type</label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value as MarketplaceItemType)}
                className="w-full h-8 px-2 rounded bg-bg-elevated border border-border text-[12px] text-text-primary focus:outline-none focus:border-border-focus transition-colors"
              >
                <option value="agent">Agent</option>
                <option value="skill">Skill</option>
                <option value="instruction">Instruction</option>
                <option value="prompt">Prompt</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            {/* Publisher */}
            <div className="space-y-1">
              <label className="text-[11px] font-semibold text-text-secondary uppercase tracking-wider">Publisher</label>
              <input
                type="text"
                value={publisher}
                onChange={(e) => setPublisher(e.target.value)}
                placeholder="e.g. cloudflare"
                className="w-full h-8 px-3 rounded bg-bg-elevated border border-border text-[12px] text-text-primary placeholder:text-text-muted focus:outline-none focus:border-border-focus transition-colors"
              />
            </div>

            {/* Category */}
            <div className="space-y-1">
              <label className="text-[11px] font-semibold text-text-secondary uppercase tracking-wider">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full h-8 px-2 rounded bg-bg-elevated border border-border text-[12px] text-text-primary focus:outline-none focus:border-border-focus transition-colors animate-none"
              >
                {mockCategories.filter(c => c.id !== "all").map((cat) => (
                  <option key={cat.id} value={cat.id}>
                    {cat.displayName}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Short Description */}
          <div className="space-y-1">
            <label className="text-[11px] font-semibold text-text-secondary uppercase tracking-wider">Short Description</label>
            <input
              type="text"
              value={shortDesc}
              onChange={(e) => setShortDesc(e.target.value)}
              placeholder="A one-sentence summary of what this does"
              className="w-full h-8 px-3 rounded bg-bg-elevated border border-border text-[12px] text-text-primary placeholder:text-text-muted focus:outline-none focus:border-border-focus transition-colors"
            />
          </div>

          {/* Detailed Description */}
          <div className="space-y-1">
            <label className="text-[11px] font-semibold text-text-secondary uppercase tracking-wider">Detailed Description</label>
            <textarea
              value={longDesc}
              onChange={(e) => setLongDesc(e.target.value)}
              rows={3}
              placeholder="Describe the capabilities, features, and detailed behavior of this item..."
              className="w-full p-2.5 rounded bg-bg-elevated border border-border text-[12px] text-text-primary placeholder:text-text-muted focus:outline-none focus:border-border-focus transition-colors resize-none"
            />
          </div>

          {/* Highlight Box text */}
          <div className="space-y-1">
            <label className="text-[11px] font-semibold text-text-secondary uppercase tracking-wider">Highlight Box (Optional)</label>
            <input
              type="text"
              value={highlight}
              onChange={(e) => setHighlight(e.target.value)}
              placeholder="Crucial takeaway or runtime highlight (rendered in green)"
              className="w-full h-8 px-3 rounded bg-bg-elevated border border-border text-[12px] text-text-primary placeholder:text-text-muted focus:outline-none focus:border-border-focus transition-colors"
            />
          </div>

          {/* When to Use Checklist */}
          <div className="space-y-1">
            <label className="text-[11px] font-semibold text-text-secondary uppercase tracking-wider">
              When to Use (one scenario per line)
            </label>
            <textarea
              value={whenToUseStr}
              onChange={(e) => setWhenToUseStr(e.target.value)}
              rows={3}
              placeholder="e.g. Automating code reviews for security vulnerabilities&#10;Mentoring junior devs with formatting guidelines"
              className="w-full p-2.5 rounded bg-bg-elevated border border-border text-[12px] text-text-primary placeholder:text-text-muted focus:outline-none focus:border-border-focus transition-colors resize-none"
            />
          </div>

          <div className="border-t border-border pt-4 grid grid-cols-1 gap-4">
            {/* File Name */}
            <div className="space-y-1">
              <label className="text-[11px] font-semibold text-text-secondary uppercase tracking-wider">File Name</label>
              <input
                type="text"
                value={filename}
                onChange={(e) => setFilename(e.target.value)}
                placeholder="e.g. agents-sdk.md"
                className="w-full h-8 px-3 rounded bg-bg-elevated border border-border text-[12px] text-text-primary placeholder:text-text-muted focus:outline-none focus:border-border-focus transition-colors"
              />
            </div>

            {/* Code Content */}
            <div className="space-y-1">
              <label className="text-[11px] font-semibold text-text-secondary uppercase tracking-wider">Content / Prompt Code</label>
              <textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                rows={6}
                placeholder="# File Title&#10;&#10;Explain instructions or copy paste prompt contents here..."
                className="w-full p-2.5 rounded bg-bg-elevated border border-border font-mono text-[12px] text-text-primary placeholder:text-text-muted focus:outline-none focus:border-border-focus transition-colors resize-none"
              />
            </div>
          </div>
        </form>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-border bg-bg-tertiary/60 flex justify-end gap-2">
          <button
            type="button"
            onClick={onClose}
            className="h-8 px-4 rounded-lg text-[11px] font-medium border border-border hover:border-border-strong text-text-secondary hover:text-text-primary bg-bg-elevated/20 hover:bg-bg-hover transition-colors cursor-pointer"
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            className="h-8 px-4 rounded-lg text-[11px] font-bold bg-white text-black hover:bg-zinc-200 transition-colors flex items-center gap-1.5 cursor-pointer shadow-subtle"
          >
            <Send size={11} />
            Publish Item
          </button>
        </div>
      </div>
    </>
  );
}
