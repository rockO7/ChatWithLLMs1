"use client";

import React, { useState } from "react";
import { useAppStore } from "@/store";
import { MarketplaceItem } from "@/types/marketplace";
import { 
  ChevronLeft, 
  Check, 
  Copy, 
  Download, 
  ChevronDown, 
  ChevronUp, 
  ShieldAlert, 
  ExternalLink,
  Info
} from "lucide-react";
import { CloneDialog } from "./CloneDialog";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { cn } from "@/lib/utils";

interface MarketplaceDetailProps {
  item: MarketplaceItem;
}

export function MarketplaceDetail({ item }: MarketplaceDetailProps) {
  const { 
    setSelectedMarketplaceItem, 
    setMarketplaceSelectedPublisher, 
    currentRepository,
    cloneMarketplaceItem,
    themeMode
  } = useAppStore();

  const [copied, setCopied] = useState(false);
  const [accordionOpen, setAccordionOpen] = useState(true);
  const [cloneDialogOpen, setCloneDialogOpen] = useState(false);

  const handleCopy = (e: React.MouseEvent) => {
    e.stopPropagation(); // Stop accordion from toggling
    navigator.clipboard?.writeText(item.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleBackToPublisher = () => {
    setMarketplaceSelectedPublisher(item.publisher);
    setSelectedMarketplaceItem(null);
  };

  const handleCloneClick = () => {
    if (currentRepository) {
      // Direct clone to active repository
      cloneMarketplaceItem(item, currentRepository);
    } else {
      // Need to select a repository first
      setCloneDialogOpen(true);
    }
  };

  const handleSelectRepoToClone = (repoName: string) => {
    cloneMarketplaceItem(item, repoName);
    setCloneDialogOpen(false);
  };

  const getTypeName = (type: string) => {
    switch(type) {
      case "agent": return "Agent";
      case "skill": return "Skill";
      case "instruction": return "Instruction";
      case "prompt": return "Prompt";
      default: return type;
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 select-text">
      {/* Back link */}
      <button
        onClick={() => setSelectedMarketplaceItem(null)}
        className="flex items-center gap-1.5 text-[12px] font-medium text-text-muted hover:text-text-primary transition-colors mb-6 group cursor-pointer"
      >
        <ChevronLeft size={14} className="group-hover:-translate-x-0.5 transition-transform" />
        <span>Back to marketplace</span>
      </button>

      {/* Header Info */}
      <div className="flex items-start justify-between gap-6 mb-6">
        <div className="space-y-2.5">
          <div className="flex items-center gap-2">
            <h1 className="text-3xl font-extrabold text-text-primary tracking-heading">
              {item.name}
            </h1>
            {item.isOfficial && (
              <span className={cn(
                "text-[10px] font-bold px-2 py-0.5 rounded-full border",
                themeMode === "light"
                  ? "bg-transparent border-emerald-600/35 text-emerald-700"
                  : "bg-emerald-950/50 border-emerald-500/30 text-emerald-400"
              )}>
                official
              </span>
            )}
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-bg-hover border border-border text-text-secondary">
              {item.category}
            </span>
          </div>

          <p className="text-[14.5px] text-text-secondary leading-relaxed max-w-2xl">
            {item.longDescription}
          </p>

          <div className="flex items-center gap-2.5 pt-1">
            <div className="h-5 w-5 rounded-full bg-bg-hover border border-border flex items-center justify-center font-bold text-[9px] text-text-primary uppercase">
              {item.publisher.substring(0, 2)}
            </div>
            <span className="text-[12px] font-bold text-text-primary capitalize">
              {item.publisher}
            </span>
            <button
              onClick={handleBackToPublisher}
              className="text-[12px] font-medium text-emerald-400 hover:text-emerald-300 transition-colors flex items-center gap-0.5 cursor-pointer ml-1"
            >
              <span>View all {item.publisher} items</span>
              <span className="text-[10px]">→</span>
            </button>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col gap-2 flex-shrink-0">
          <button
            onClick={handleCloneClick}
            className="h-9 px-4 rounded-lg text-[12px] font-bold bg-white text-black hover:bg-zinc-200 transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-subtle"
          >
            <Download size={13} />
            Clone to Repo
          </button>
          
          <button
            onClick={handleCopy}
            className="h-9 px-4 rounded-lg text-[12px] font-medium border border-border hover:border-border-strong text-text-secondary hover:text-text-primary bg-bg-elevated/20 hover:bg-bg-hover transition-colors flex items-center justify-center gap-2 cursor-pointer"
          >
            {copied ? (
              <>
                <Check size={13} className="text-emerald-500" />
                <span>Copied Code</span>
              </>
            ) : (
              <>
                <Copy size={13} />
                <span>Copy Prompt</span>
              </>
            )}
          </button>
        </div>
      </div>

      <div className="border-t border-border/80 my-8" />

      {/* Main Detail Grid */}
      <div className="space-y-8">
        {/* What This Skill Does */}
        <div className="space-y-4">
          <h2 className="text-[15px] font-bold text-text-primary tracking-tight">
            What This {getTypeName(item.type)} Does
          </h2>
          <p className="text-[13px] text-text-secondary leading-relaxed">
            {item.whatItDoes}
          </p>

          {/* Highlight Banner */}
          {item.whatItDoesHighlight && (
            <div className={cn(
              "p-3.5 border rounded-lg flex gap-3 text-[12px] leading-relaxed",
              themeMode === "light"
                ? "bg-transparent border-emerald-600/35 text-emerald-700 font-medium"
                : "bg-emerald-950/20 border-emerald-500/25 text-emerald-400/90 shadow-glow"
            )}>
              <Info size={14} className={cn("mt-0.5 flex-shrink-0", themeMode === "light" ? "text-emerald-700" : "text-emerald-400")} />
              <span>{item.whatItDoesHighlight}</span>
            </div>
          )}
        </div>

        {/* When to use it */}
        <div className="space-y-3.5">
          <h2 className="text-[11px] font-bold text-text-muted uppercase tracking-wider">
            WHEN TO USE IT
          </h2>
          <ul className="space-y-2.5">
            {item.whenToUse.map((bullet, idx) => (
              <li key={idx} className="flex items-start gap-2.5 text-[13px] text-text-secondary">
                <Check size={14} className="text-emerald-500 flex-shrink-0 mt-0.5" />
                <span>{bullet}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Show code file Accordion */}
        <div className="border border-border rounded-lg overflow-hidden bg-bg-primary/40">
          <div
            onClick={() => setAccordionOpen(!accordionOpen)}
            className="w-full flex items-center justify-between px-4 py-3 bg-bg-secondary/60 hover:bg-bg-hover/40 transition-colors border-b border-border/50 text-left select-none cursor-pointer"
          >
            <div className="flex items-center gap-2">
              {accordionOpen ? <ChevronUp size={14} className="text-text-muted" /> : <ChevronDown size={14} className="text-text-muted" />}
              <span className="text-[12px] font-bold text-text-primary">
                Show {item.contentFilename} file
              </span>
            </div>

            <button
              onClick={handleCopy}
              className="h-6 px-2.5 rounded text-[10.5px] font-medium border border-border bg-bg-elevated hover:bg-bg-hover hover:border-border-strong text-text-secondary hover:text-text-primary transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              {copied ? <Check size={11} className="text-emerald-500" /> : <Copy size={11} />}
              <span>{copied ? "Copied" : "Copy"}</span>
            </button>
          </div>

          {accordionOpen && (
            <div className="p-4 bg-bg-secondary/20 overflow-x-auto border-t border-border/10">
              {item.contentFilename.endsWith(".md") ? (
                <div className="markdown-preview select-text">
                  <ReactMarkdown remarkPlugins={[remarkGfm]}>{item.content}</ReactMarkdown>
                </div>
              ) : (
                <pre className="font-mono text-[12px] text-text-secondary leading-relaxed whitespace-pre font-medium">
                  <code>{item.content}</code>
                </pre>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Repo selection dialog for cloning */}
      <CloneDialog 
        isOpen={cloneDialogOpen} 
        onClose={() => setCloneDialogOpen(false)} 
        onSelectRepo={handleSelectRepoToClone} 
      />
    </div>
  );
}
