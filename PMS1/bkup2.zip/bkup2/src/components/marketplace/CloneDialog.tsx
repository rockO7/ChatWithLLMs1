"use client";

import React from "react";
import { useAppStore } from "@/store";
import { X, GitFork, ChevronRight } from "lucide-react";

interface CloneDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectRepo: (repoName: string) => void;
}

export function CloneDialog({ isOpen, onClose, onSelectRepo }: CloneDialogProps) {
  const { repositories } = useAppStore();

  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 animate-fade-in"
        onClick={onClose}
      />
      
      {/* Dialog container */}
      <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[440px] bg-bg-secondary border border-border rounded-xl shadow-elevated z-50 overflow-hidden animate-scale-in">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-border">
          <div>
            <h3 className="text-[14px] font-bold text-text-primary">Select Repository</h3>
            <p className="text-[11px] text-text-muted">Choose which repository to clone this item into</p>
          </div>
          <button 
            onClick={onClose}
            className="p-1 rounded-sm text-text-muted hover:text-text-primary hover:bg-bg-hover transition-colors"
          >
            <X size={15} />
          </button>
        </div>

        {/* Content */}
        <div className="max-h-[300px] overflow-y-auto p-2 space-y-1">
          {repositories.map((repo) => (
            <button
              key={repo.name}
              onClick={() => onSelectRepo(repo.name)}
              className="w-full text-left p-2.5 rounded-lg border border-border bg-bg-primary/50 hover:bg-bg-hover hover:border-border-strong transition-all flex items-start gap-3 group cursor-pointer"
            >
              <div className="p-2 rounded bg-bg-elevated border border-border group-hover:border-white/10 text-text-secondary group-hover:text-text-primary transition-colors mt-0.5">
                <GitFork size={14} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-[12.5px] font-semibold text-text-primary flex items-center justify-between">
                  <span className="truncate">{repo.name}</span>
                  <ChevronRight size={12} className="text-text-muted opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
                <p className="text-[11px] text-text-secondary truncate mt-0.5">
                  {repo.description}
                </p>
                <div className="flex items-center gap-2 mt-2 text-[10px] text-text-muted font-mono">
                  <span>{repo.promptCount} items</span>
                  <span>·</span>
                  <span>{repo.branch}</span>
                </div>
              </div>
            </button>
          ))}
        </div>

        {/* Footer */}
        <div className="px-4 py-3 border-t border-border bg-bg-tertiary/60 flex justify-end">
          <button
            onClick={onClose}
            className="h-8 px-4 rounded-lg text-[11px] font-medium border border-border hover:border-border-strong text-text-secondary hover:text-text-primary bg-bg-elevated/20 hover:bg-bg-hover transition-colors cursor-pointer"
          >
            Cancel
          </button>
        </div>
      </div>
    </>
  );
}
