"use client";

import React, { useState } from "react";
import { useAppStore } from "@/store";
import { Search, Plus, Star, Award, BookOpen, Layers, X, GitFork } from "lucide-react";
import { mockCategories, mockPublishers } from "@/data/marketplaceMock";
import { MarketplaceDetail } from "./MarketplaceDetail";
import { PublishModal } from "./PublishModal";
import { cn } from "@/lib/utils";

export function MarketplacePage() {
  const {
    marketplaceItems,
    selectedMarketplaceItem,
    setSelectedMarketplaceItem,
    marketplaceSearchQuery,
    setMarketplaceSearchQuery,
    marketplaceSelectedCategory,
    setMarketplaceSelectedCategory,
    marketplaceSelectedPublisher,
    setMarketplaceSelectedPublisher,
    marketplaceSelectedType,
    setMarketplaceSelectedType,
    setViewMode,
    currentRepository,
    themeMode
  } = useAppStore();

  const [publishModalOpen, setPublishModalOpen] = useState(false);

  // Filter items based on selected parameters
  const filteredItems = marketplaceItems.filter((item) => {
    // Search query match
    if (
      marketplaceSearchQuery.trim() !== "" &&
      !item.name.toLowerCase().includes(marketplaceSearchQuery.toLowerCase()) &&
      !item.shortDescription.toLowerCase().includes(marketplaceSearchQuery.toLowerCase()) &&
      !item.publisher.toLowerCase().includes(marketplaceSearchQuery.toLowerCase())
    ) {
      return false;
    }

    // Category match
    if (
      marketplaceSelectedCategory !== "all" &&
      item.category !== marketplaceSelectedCategory
    ) {
      return false;
    }

    // Publisher match
    if (
      marketplaceSelectedPublisher !== "all" &&
      item.publisher !== marketplaceSelectedPublisher
    ) {
      return false;
    }

    // Type match
    if (
      marketplaceSelectedType !== "all" &&
      item.type !== marketplaceSelectedType
    ) {
      return false;
    }

    return true;
  });

  // Calculate counts for categories dynamically (based on other active filters)
  const getCategoryCount = (categoryName: string) => {
    return marketplaceItems.filter((item) => {
      // Publisher match
      if (
        marketplaceSelectedPublisher !== "all" &&
        item.publisher !== marketplaceSelectedPublisher
      ) {
        return false;
      }
      // Type match
      if (
        marketplaceSelectedType !== "all" &&
        item.type !== marketplaceSelectedType
      ) {
        return false;
      }
      // Search match
      if (
        marketplaceSearchQuery.trim() !== "" &&
        !item.name.toLowerCase().includes(marketplaceSearchQuery.toLowerCase()) &&
        !item.shortDescription.toLowerCase().includes(marketplaceSearchQuery.toLowerCase())
      ) {
        return false;
      }
      // Category match
      if (categoryName !== "all" && item.category !== categoryName) {
        return false;
      }
      return true;
    }).length;
  };

  // Calculate publisher list dynamically with counts
  const getPublisherCount = (pubName: string) => {
    return marketplaceItems.filter((item) => {
      if (item.publisher !== pubName) return false;
      if (marketplaceSelectedCategory !== "all" && item.category !== marketplaceSelectedCategory) return false;
      if (marketplaceSelectedType !== "all" && item.type !== marketplaceSelectedType) return false;
      return true;
    }).length;
  };

  const handleClearFilters = () => {
    setMarketplaceSearchQuery("");
    setMarketplaceSelectedCategory("all");
    setMarketplaceSelectedPublisher("all");
    setMarketplaceSelectedType("all");
  };

  const hasActiveFilters =
    marketplaceSearchQuery !== "" ||
    marketplaceSelectedCategory !== "all" ||
    marketplaceSelectedPublisher !== "all" ||
    marketplaceSelectedType !== "all";

  // Detailed view
  if (selectedMarketplaceItem) {
    return (
      <div className="flex-1 overflow-y-auto bg-bg-primary h-full">
        <MarketplaceDetail item={selectedMarketplaceItem} />
      </div>
    );
  }

  return (
    <div className="flex-1 flex overflow-hidden h-full bg-bg-primary select-none">
      {/* Publishers Sidebar */}
      <div className="w-56 border-r border-border bg-bg-primary/50 flex flex-col flex-shrink-0 h-full p-4 overflow-y-auto">
        <div className="flex items-center justify-between mb-4">
          <span className="text-[11px] font-bold text-text-primary uppercase tracking-widest">
            Publishers
          </span>
          {marketplaceSelectedPublisher !== "all" && (
            <button
              onClick={() => setMarketplaceSelectedPublisher("all")}
              className="text-[10px] text-emerald-400 hover:text-emerald-300 font-medium cursor-pointer"
            >
              Clear
            </button>
          )}
        </div>

        <div className="space-y-0.5">
          <button
            onClick={() => setMarketplaceSelectedPublisher("all")}
            className={cn(
              "w-full text-left px-2.5 py-1.5 rounded text-[12.5px] transition-all flex items-center justify-between cursor-pointer",
              marketplaceSelectedPublisher === "all"
                ? "bg-white/[0.06] text-text-primary font-semibold"
                : "text-text-secondary hover:bg-white/[0.03] hover:text-text-primary"
            )}
          >
            <span>all publishers</span>
            <span className="text-[10px] text-text-muted font-mono">
              {marketplaceItems.length}
            </span>
          </button>

          {mockPublishers
            .filter((pub) => getPublisherCount(pub.name) > 0)
            .map((pub) => {
              const count = getPublisherCount(pub.name);
              return (
                <button
                  key={pub.name}
                  onClick={() => setMarketplaceSelectedPublisher(pub.name)}
                  className={cn(
                    "w-full text-left px-2.5 py-1.5 rounded text-[12.5px] transition-all flex items-center justify-between cursor-pointer group",
                    marketplaceSelectedPublisher === pub.name
                      ? "bg-white/[0.06] text-text-primary font-semibold"
                      : "text-text-secondary hover:bg-white/[0.03] hover:text-text-primary"
                  )}
                >
                  <div className="flex items-center gap-2 truncate">
                    <div className="h-4 w-4 rounded bg-bg-elevated border border-border flex items-center justify-center text-[8px] font-bold uppercase text-text-muted group-hover:text-text-primary transition-colors">
                      {pub.name.substring(0, 2)}
                    </div>
                    <span className="truncate">{pub.name}</span>
                  </div>
                  <span className="text-[10px] text-text-muted font-mono group-hover:text-text-secondary transition-colors">
                    {count}
                  </span>
                </button>
              );
            })}
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col overflow-hidden h-full">
        {/* Category Navbar Counts */}
        <div className="border-b border-border flex items-center justify-between px-6 py-2.5 bg-bg-secondary/20 flex-shrink-0">
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
            {mockCategories.map((cat) => {
              const count = getCategoryCount(cat.name);
              const isActive = marketplaceSelectedCategory === cat.name;

              // Hide empty categories unless they are currently active
              if (count === 0 && !isActive) return null;

              return (
                <button
                  key={cat.id}
                  onClick={() => setMarketplaceSelectedCategory(cat.name)}
                  className={cn(
                    "px-3 py-1 text-[12px] font-medium rounded-full flex items-center gap-1.5 transition-all flex-shrink-0 cursor-pointer select-none",
                    isActive
                      ? "bg-white text-black font-semibold shadow-subtle"
                      : "text-text-secondary hover:text-text-primary bg-bg-elevated/30 hover:bg-bg-elevated/60 border border-border/60 hover:border-border"
                  )}
                >
                  <span>{cat.name}</span>
                  <span
                    className={cn(
                      "text-[10px] font-mono",
                      isActive ? "text-zinc-600" : "text-text-muted"
                    )}
                  >
                    {count}
                  </span>
                </button>
              );
            })}
          </div>

          <div className="flex items-center gap-2 flex-shrink-0 ml-4">
            {currentRepository && (
              <span className={cn(
                "text-[10.5px] px-2 py-0.5 rounded border font-mono",
                themeMode === "light"
                  ? "bg-transparent border-emerald-600/35 text-emerald-700"
                  : "border-emerald-950 bg-emerald-950/20 text-emerald-400"
              )}>
                Repo: {currentRepository.split("/").pop()}
              </span>
            )}
            <button
              onClick={() => setPublishModalOpen(true)}
              className="h-7 px-3 bg-white text-black hover:bg-zinc-200 text-[11px] font-bold rounded-lg transition-colors flex items-center gap-1 cursor-pointer shadow-subtle"
            >
              <Plus size={12} />
              Publish
            </button>
          </div>
        </div>

        {/* Filter / Search Row */}
        <div className="px-6 py-3 border-b border-border bg-bg-primary flex flex-wrap items-center justify-between gap-4 flex-shrink-0">
          {/* Search bar */}
          <div className="relative w-80">
            <Search
              size={13}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted"
            />
            <input
              type="text"
              value={marketplaceSearchQuery}
              onChange={(e) => setMarketplaceSearchQuery(e.target.value)}
              placeholder="Search all skills, prompts..."
              className="w-full h-8 pl-9 pr-8 rounded-lg bg-bg-elevated border border-border text-[12px] text-text-primary placeholder:text-text-muted focus:outline-none focus:border-border-focus transition-colors"
            />
            {marketplaceSearchQuery && (
              <button
                onClick={() => setMarketplaceSearchQuery("")}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 p-0.5 rounded hover:bg-bg-hover text-text-muted hover:text-text-primary cursor-pointer"
              >
                <X size={10} />
              </button>
            )}
          </div>

          {/* Type filters tabs */}
          <div className="flex items-center gap-1 bg-bg-elevated/60 border border-border p-0.5 rounded-lg text-[11.5px]">
            {["all", "agent", "skill", "instruction", "prompt"].map((type) => (
              <button
                key={type}
                onClick={() => setMarketplaceSelectedType(type)}
                className={cn(
                  "px-2.5 py-1 rounded-[5px] font-semibold transition-all cursor-pointer select-none capitalize",
                  marketplaceSelectedType === type
                    ? "bg-bg-hover border border-border-strong text-text-primary"
                    : "text-text-muted hover:text-text-secondary"
                )}
              >
                {type === "all" ? "All Types" : type + "s"}
              </button>
            ))}
          </div>
        </div>

        {/* List of items */}
        <div className="flex-1 overflow-y-auto px-6 py-4 select-text">
          {filteredItems.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredItems.map((item) => (
                <div
                  key={item.id}
                  onClick={() => setSelectedMarketplaceItem(item)}
                  className="group p-5 bg-bg-secondary/35 border border-border hover:border-indigo-500/35 hover:bg-bg-secondary/60 rounded-xl transition-all duration-300 flex flex-col justify-between cursor-pointer hover:shadow-lg shadow-black/10 hover:-translate-y-0.5 relative overflow-hidden"
                >
                  {/* Subtle hover gradient light */}
                  <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  
                  <div className="space-y-2 relative z-10">
                    <div className="flex items-start justify-between gap-3">
                      <h3 className="text-[14px] font-bold text-text-primary group-hover:text-indigo-400 transition-colors tracking-tight">
                        {item.name}
                      </h3>
                      {item.isOfficial && (
                        <span className={cn(
                          "text-[8.5px] font-bold px-1.5 py-0.2 rounded-full border flex-shrink-0 select-none",
                          themeMode === "light"
                            ? "bg-transparent border-emerald-600/35 text-emerald-700"
                            : "border-emerald-500/25 bg-emerald-950/20 text-emerald-400"
                        )}>
                          Official
                        </span>
                      )}
                    </div>
                    <p className="text-[12.5px] text-text-secondary leading-relaxed line-clamp-2">
                      {item.shortDescription}
                    </p>
                  </div>

                  <div className="pt-4 mt-4 border-t border-border/40 flex items-center justify-between text-[11px] text-text-muted relative z-10">
                    <span className="font-mono text-[10px]">
                      by <span className="font-semibold text-text-secondary">{item.publisher}</span>
                    </span>
                    <div className="flex items-center gap-2.5">
                      {item.stars && (
                        <span className="flex items-center gap-1 font-mono text-text-secondary">
                          <Star size={11} className="text-yellow-500/60 fill-yellow-500/10" />
                          {item.stars}
                        </span>
                      )}
                      <span className="text-[9px] font-bold uppercase tracking-wider text-text-muted bg-bg-elevated px-2 py-0.5 rounded border border-border">
                        {item.type}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="py-20 text-center space-y-3">
              <Layers size={32} className="mx-auto text-text-muted/60" />
              <h3 className="text-[14px] font-semibold text-text-secondary">
                No items found
              </h3>
              <p className="text-[12px] text-text-muted max-w-sm mx-auto">
                No items match your selected filters. Try broadening your query or clearing filters.
              </p>
              {hasActiveFilters && (
                <button
                  onClick={handleClearFilters}
                  className="mt-2 h-7 px-3 border border-border hover:border-border-strong bg-bg-elevated/20 text-text-secondary hover:text-text-primary text-[11px] font-semibold rounded-lg transition-colors cursor-pointer"
                >
                  Clear All Filters
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Publish Modal Form */}
      <PublishModal
        isOpen={publishModalOpen}
        onClose={() => setPublishModalOpen(false)}
      />
    </div>
  );
}
